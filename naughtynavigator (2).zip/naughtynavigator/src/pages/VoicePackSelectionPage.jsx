import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Volume2 } from 'lucide-react';
import { playTapSound } from '../lib/soundEffects';
import { speakComment } from '../components/navigation/SeductiveComments';
import { trackEvent } from '../lib/pushNotifications';

const VOICE_PACKS = [
  {
    id: 'sultry',
    name: 'Sultry Seduction',
    subtitle: 'Flirty & Seductive',
    icon: '💋',
    accent: '#FF1493',
    glow: 'rgba(255,20,147,0.6)',
    bg: 'rgba(255,20,147,0.1)',
    preview: "Mmm… keep your eyes on the road, gorgeous. I'll handle the rest. Let me whisper every turn right into your ear.",
    premium: false,
    selected: true,
  },
  {
    id: 'sassy',
    name: 'Sassy Mistress',
    subtitle: 'Bold & Dominant',
    icon: '🎤',
    accent: '#C400FF',
    glow: 'rgba(196,0,255,0.6)',
    bg: 'rgba(196,0,255,0.1)',
    preview: "Alright, listen up. Route calculated. I'm in charge now — keep up.",
    premium: true,
    selected: false,
  },
  {
    id: 'playful',
    name: 'Playful Tease',
    subtitle: 'Sweet & Fun',
    icon: '😈',
    accent: '#FF6EB3',
    glow: 'rgba(255,110,179,0.6)',
    bg: 'rgba(255,110,179,0.1)',
    preview: "Omg we're going on a TRIP?! I'm SO ready, let's GOOO! 🎀",
    premium: true,
    selected: false,
  },
  {
    id: 'diva',
    name: 'Dangerous Diva',
    subtitle: 'Edgy & Wild',
    icon: '👑',
    accent: '#FFD700',
    glow: 'rgba(255,215,0,0.6)',
    bg: 'rgba(255,215,0,0.1)',
    preview: "Chaotic, confident, and absolutely fearless. Let's make this interesting.",
    premium: true,
    selected: false,
  },
];

export default function VoicePackSelectionPage({ onBack, onUpgrade }) {
  const [selected, setSelected] = useState('sultry');
  const [previewing, setPreviewing] = useState(null);
  const [playing, setPlaying] = useState(false);
  const isPremium = localStorage.getItem('nn_premium') === 'true';

  const selectedVoice = VOICE_PACKS.find(v => v.id === selected) || VOICE_PACKS[0];

  const handleSelect = (voice) => {
    if (voice.premium && !isPremium) {
      playTapSound();
      onUpgrade?.();
      return;
    }
    playTapSound();
    setSelected(voice.id);
    localStorage.setItem('nn_voice', voice.id);
    trackEvent('voice_pack_selected', { voice: voice.id });
  };

  const handlePreview = (voice, e) => {
    e.stopPropagation();
    if (voice.premium && !isPremium) return;
    playTapSound();
    setPreviewing(voice.id);
    speakComment(voice.preview, voice.id);
    setTimeout(() => setPreviewing(null), 3000);
  };

  const handlePlayVoice = () => {
    playTapSound();
    setPlaying(true);
    speakComment(selectedVoice.preview, selectedVoice.id);
    setTimeout(() => setPlaying(false), 3000);
  };

  const handleConfirm = () => {
    playTapSound();
    onBack?.();
  };

  return (
    <div
      className="flex flex-col h-full overflow-y-auto relative"
      style={{ background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' }}
    >
      {/* Animated particle background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {Array.from({ length: 30 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute rounded-full"
            style={{
              width: Math.random() * 3 + 1,
              height: Math.random() * 3 + 1,
              background: Math.random() > 0.5 ? '#FF1493' : '#C400FF',
              left: Math.random() * 100 + '%',
              top: Math.random() * 100 + '%',
              opacity: Math.random() * 0.6 + 0.2,
            }}
            animate={{
              y: [0, -30, 0],
              x: [0, Math.random() * 20 - 10, 0],
              opacity: [0.2, 0.8, 0.2],
            }}
            transition={{
              duration: Math.random() * 4 + 3,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      {/* Radial glow overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at 50% 0%, rgba(255,20,147,0.15) 0%, transparent 60%)',
        }}
      />

      <div className="relative z-10 flex flex-col gap-6 px-5 py-6 pb-10">
        {/* Header */}
        <div className="flex items-start gap-3">
          <motion.button
            onClick={onBack}
            className="h-10 w-10 rounded-2xl flex items-center justify-center text-lg font-bold shrink-0"
            style={{
              background: 'rgba(196,0,255,0.15)',
              border: '1.5px solid rgba(255,20,147,0.4)',
              color: '#FF1493',
              boxShadow: '0 0 12px rgba(255,20,147,0.3)',
            }}
            whileTap={{ scale: 0.95 }}
          >
            ‹
          </motion.button>
          <div className="flex-1 text-center pr-10">
            <motion.h1
              className="text-2xl font-black"
              style={{
                background: 'linear-gradient(135deg, #FF1493 0%, #FF69B4 50%, #C400FF 100%)',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                textShadow: '0 0 30px rgba(255,20,147,0.6)',
                filter: 'drop-shadow(0 0 20px rgba(255,20,147,0.4))',
              }}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
            >
              Pick Your Voice Pack
            </motion.h1>
            <motion.p
              className="text-sm italic mt-1"
              style={{ color: '#D9A6FF' }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 }}
            >
              Who will guide you tonight?
            </motion.p>
          </div>
        </div>

        {/* Divider */}
        <div
          style={{
            height: 1,
            background: 'linear-gradient(90deg, transparent, rgba(255,20,147,0.4), transparent)',
          }}
        />

        {/* Voice cards */}
        <div className="flex flex-col gap-4">
          {VOICE_PACKS.map((voice, i) => {
            const isActive = selected === voice.id;
            const isLocked = voice.premium && !isPremium;
            const isPlaying = previewing === voice.id;

            return (
              <motion.button
                key={voice.id}
                onClick={() => handleSelect(voice)}
                className="relative w-full rounded-2xl overflow-hidden text-left transition-all group"
                style={{
                  background: isActive ? voice.bg : 'rgba(255,255,255,0.03)',
                  border: isActive ? `1.5px solid ${voice.accent}` : '1px solid rgba(255,255,255,0.1)',
                  boxShadow: isActive ? `0 0 24px ${voice.glow}` : 'none',
                  opacity: isLocked ? 0.6 : 1,
                }}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: isLocked ? 0.6 : 1, x: 0 }}
                transition={{ delay: i * 0.08 }}
                whileTap={{ scale: isLocked ? 1 : 0.98 }}
              >
                {/* Animated glow for active */}
                {isActive && (
                  <motion.div
                    className="absolute inset-0 rounded-2xl pointer-events-none"
                    animate={{
                      boxShadow: [
                        `inset 0 0 20px ${voice.glow.replace('0.6', '0.2')}`,
                        `inset 0 0 40px ${voice.glow.replace('0.6', '0.4')}`,
                        `inset 0 0 20px ${voice.glow.replace('0.6', '0.2')}`,
                      ],
                    }}
                    transition={{ duration: 2, repeat: Infinity }}
                  />
                )}

                <div className="flex items-center gap-4 px-5 py-4 relative z-10">
                  {/* Icon with glow */}
                  <div className="relative shrink-0">
                    <div
                      className="absolute inset-0 rounded-full blur-md"
                      style={{
                        background: voice.accent,
                        opacity: isActive ? 0.4 : 0,
                        width: 64,
                        height: 64,
                        transition: 'opacity 0.3s',
                      }}
                    />
                    <motion.div
                      className="relative h-16 w-16 rounded-full flex items-center justify-center text-3xl"
                      style={{
                        background: voice.bg,
                        border: `2px solid ${voice.accent}`,
                        boxShadow: isActive ? `0 0 16px ${voice.glow}` : 'none',
                      }}
                      animate={isPlaying ? { scale: [1, 1.2, 1], rotate: [-5, 5, -5, 0] } : {}}
                      transition={{ duration: 0.5, repeat: isPlaying ? Infinity : 0 }}
                    >
                      {voice.icon}
                    </motion.div>
                  </div>

                  {/* Text content */}
                  <div className="flex-1 min-w-0">
                    <p
                      className="text-base font-bold"
                      style={{ color: isActive ? '#FFFFFF' : '#E8CCFF' }}
                    >
                      {voice.name}
                    </p>
                    <p
                      className="text-xs mt-0.5"
                      style={{ color: isActive ? voice.accent + 'dd' : 'rgba(217,166,255,0.5)' }}
                    >
                      {voice.subtitle}
                    </p>
                  </div>

                  {/* Select button or lock */}
                  {isLocked ? (
                    <div className="flex items-center gap-1.5 shrink-0">
                      <Lock className="w-4 h-4" style={{ color: '#FFD700' }} />
                      <span
                        className="text-[10px] font-bold px-3 py-1.5 rounded-lg"
                        style={{
                          background: 'rgba(255,215,0,0.15)',
                          border: '1px solid rgba(255,215,0,0.4)',
                          color: '#FFD700',
                        }}
                      >
                        Premium
                      </span>
                    </div>
                  ) : (
                    <motion.button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleSelect(voice);
                      }}
                      className="shrink-0 font-bold text-xs px-4 py-2 rounded-lg uppercase tracking-wide"
                      style={{
                        background: isActive ? voice.accent : 'rgba(255,255,255,0.08)',
                        color: isActive ? '#000' : voice.accent,
                        border: `1px solid ${voice.accent}`,
                        boxShadow: isActive ? `0 0 12px ${voice.glow}` : 'none',
                      }}
                      whileTap={{ scale: 0.95 }}
                    >
                      {isActive ? '✓ Selected' : 'Select'}
                    </motion.button>
                  )}
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* Large banner card */}
        <motion.div
          className="relative w-full rounded-2xl overflow-hidden mt-4 h-40"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          style={{
            background: `linear-gradient(135deg, ${selectedVoice.accent}22 0%, ${selectedVoice.accent}11 100%)`,
            border: `1px solid ${selectedVoice.accent}44`,
            boxShadow: `0 0 24px ${selectedVoice.glow}`,
          }}
        >
          {/* Neon route visualization */}
          <svg
            className="absolute inset-0 w-full h-full opacity-30"
            viewBox="0 0 400 300"
            preserveAspectRatio="xMidYMid slice"
          >
            <defs>
              <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor={selectedVoice.accent} stopOpacity="0.6" />
                <stop offset="100%" stopColor="#FF1493" stopOpacity="0.2" />
              </linearGradient>
            </defs>
            <path
              d="M 50,250 Q 150,200 250,150 T 400,80"
              stroke="url(#routeGradient)"
              strokeWidth="4"
              fill="none"
              strokeLinecap="round"
            />
            <circle cx="380" cy="70" r="8" fill={selectedVoice.accent} opacity="0.8" />
          </svg>

          {/* Content overlay */}
          <div className="relative z-10 flex items-center justify-between h-full px-5 py-4">
            <div className="flex-1">
              <p className="text-xs font-semibold uppercase tracking-widest" style={{ color: selectedVoice.accent }}>
                Now Featuring
              </p>
              <p className="text-sm mt-1 font-bold" style={{ color: '#E8CCFF' }}>
                {selectedVoice.name}
              </p>
            </div>
            <motion.button
              onClick={handlePlayVoice}
              className="h-14 w-14 rounded-full flex items-center justify-center text-2xl shrink-0 relative"
              style={{
                background: selectedVoice.bg,
                border: `2px solid ${selectedVoice.accent}`,
                boxShadow: playing ? `0 0 20px ${selectedVoice.glow}` : 'none',
              }}
              animate={playing ? { scale: [1, 1.1, 1] } : {}}
              transition={{ duration: 0.5, repeat: playing ? Infinity : 0 }}
              whileTap={{ scale: 0.95 }}
            >
              🎤
            </motion.button>
          </div>
        </motion.div>

        {/* Premium upsell */}
        {!isPremium && (
          <motion.button
            onClick={onUpgrade}
            className="w-full rounded-2xl px-5 py-4 flex items-center gap-3 relative overflow-hidden"
            style={{
              background: 'linear-gradient(135deg, rgba(255,20,147,0.2) 0%, rgba(196,0,255,0.2) 100%)',
              border: '1.5px solid rgba(255,20,147,0.5)',
              boxShadow: '0 0 20px rgba(255,20,147,0.3)',
            }}
            whileTap={{ scale: 0.98 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
          >
            <span className="text-2xl">💋</span>
            <div className="flex-1 text-left">
              <p className="text-sm font-bold" style={{ color: '#FF1493' }}>
                Set {selectedVoice.name}
              </p>
              <p className="text-xs mt-0.5" style={{ color: 'rgba(255,20,147,0.7)' }}>
                Access premium voice packs and more!
              </p>
            </div>
            <motion.div
              animate={{ x: [0, 4, 0] }}
              transition={{ duration: 1.5, repeat: Infinity }}
              className="text-lg"
            >
              →
            </motion.div>
          </motion.button>
        )}

        {/* Confirm button */}
        {isPremium && (
          <motion.button
            onClick={handleConfirm}
            className="w-full rounded-2xl px-5 py-4 font-bold text-white text-base tracking-wide"
            style={{
              background: `linear-gradient(135deg, ${selectedVoice.accent} 0%, ${selectedVoice.accent}dd 100%)`,
              boxShadow: `0 0 28px ${selectedVoice.glow}`,
            }}
            animate={{
              boxShadow: [
                `0 0 20px ${selectedVoice.glow}`,
                `0 0 40px ${selectedVoice.glow}`,
                `0 0 20px ${selectedVoice.glow}`,
              ],
            }}
            transition={{ duration: 2, repeat: Infinity }}
            whileTap={{ scale: 0.97 }}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6 }}
          >
            💋 Set {selectedVoice.name}
          </motion.button>
        )}
      </div>
    </div>
  );
}