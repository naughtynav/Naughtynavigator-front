import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Play, Check } from 'lucide-react';
import { speakComment } from '../components/navigation/SeductiveComments';
import { playTapSound, playUnlockSound } from '../lib/soundEffects';
import { trackEvent } from '../lib/pushNotifications';

const VOICES = [
  {
    id: 'velvet',
    name: 'Sultry Seduction',
    icon: '💋',
    description: 'Smooth, slow, seductive. Every word melts.',
    accent: '#FF00E6',
    glow: 'rgba(255,0,230,0.55)',
    bg: 'rgba(255,0,230,0.1)',
    premium: false,
    preview: "Mmm… close your eyes for just a second. Breathe. Now follow my voice, gorgeous.",
  },
  {
    id: 'bosslady',
    name: 'Boss Lady',
    icon: '👑',
    description: 'Confident, commanding, sharp. She runs the route.',
    accent: '#C400FF',
    glow: 'rgba(196,0,255,0.55)',
    bg: 'rgba(196,0,255,0.1)',
    premium: true,
    preview: "Alright, listen up. Route calculated. I'm in charge now — keep up.",
  },
  {
    id: 'mischief',
    name: 'Smooth Operator',
    icon: '😎',
    description: 'Cool, confident, charming. Always has a slick line ready.',
    accent: '#00C8FF',
    glow: 'rgba(0,200,255,0.55)',
    bg: 'rgba(0,200,255,0.1)',
    premium: false,
    preview: "Navigation activated. Chaos level: moderate. Let's seeeee where this goes!",
  },
  {
    id: 'princess',
    name: 'Playful Princess',
    icon: '🎀',
    description: 'Cute, flirty, teasing. The sweetest co-pilot.',
    accent: '#FF6EB3',
    glow: 'rgba(255,110,179,0.55)',
    bg: 'rgba(255,110,179,0.1)',
    premium: true,
    preview: "Omg we're going on a TRIP?! I'm SO ready, let's GOOO! 🎀",
  },
  {
    id: 'softie',
    name: 'Sweetheart Softie',
    icon: '🌸',
    description: 'Warm, gentle, comforting. A voice like a hug.',
    accent: '#D9A6FF',
    glow: 'rgba(217,166,255,0.55)',
    bg: 'rgba(217,166,255,0.1)',
    premium: true,
    preview: "Hey, I'm so glad you're here. Let's find our way together, nice and easy.",
  },
];

export default function VoicePackScreen({ onBack, onUpgrade }) {
  const [selected, setSelected] = useState(() => localStorage.getItem('nn_voice') || 'velvet');
  const [previewing, setPreviewing] = useState(null);
  const isPremium = localStorage.getItem('nn_premium') === 'true';

  const selectedVoice = VOICES.find(v => v.id === selected) || VOICES[0];

  const handleSelect = (voice) => {
    if (voice.premium && !isPremium) {
      playTapSound();
      onUpgrade?.();
      return;
    }
    playTapSound();
    setSelected(voice.id);
    localStorage.setItem('nn_voice', voice.id);
    trackEvent('voice_selected', { voice: voice.id });
  };

  const handlePreview = (voice, e) => {
    e.stopPropagation();
    if (voice.premium && !isPremium) {
      onUpgrade?.();
      return;
    }
    playTapSound();
    setPreviewing(voice.id);
    speakComment(voice.preview, voice.id);
    setTimeout(() => setPreviewing(null), 3000);
  };

  const handleConfirm = () => {
    playTapSound();
    onBack?.();
  };

  return (
    <div
      className="flex flex-col h-full overflow-y-auto"
      style={{ background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' }}
    >
      {/* Ambient glow */}
      <div
        className="pointer-events-none fixed inset-0 z-0"
        style={{
          background: `radial-gradient(ellipse at 50% 0%, ${selectedVoice.glow.replace('0.55', '0.12')} 0%, transparent 55%)`,
          transition: 'background 0.5s ease',
        }}
      />

      <div className="relative z-10 flex flex-col gap-5 px-5 py-6 pb-10">

        {/* Header */}
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="h-9 w-9 rounded-2xl flex items-center justify-center text-lg font-bold shrink-0"
            style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
          >
            ‹
          </button>
          <div className="flex-1 text-center pr-9">
            <h1
              className="text-xl font-extrabold"
              style={{ color: '#FFFFFF', textShadow: `0 0 20px ${selectedVoice.glow}`, transition: 'text-shadow 0.4s ease' }}
            >
              Choose Your Voice
            </h1>
            <p className="text-xs mt-0.5" style={{ color: 'rgba(217,166,255,0.55)' }}>
              Pick who guides you…
            </p>
          </div>
        </div>

        {/* Voice Cards */}
        <div className="flex flex-col gap-3">
          {VOICES.map((voice, i) => {
            const active = selected === voice.id;
            const locked = voice.premium && !isPremium;
            const isPlaying = previewing === voice.id;

            return (
              <motion.button
                key={voice.id}
                onClick={() => handleSelect(voice)}
                className={`w-full flex items-center gap-4 px-4 rounded-3xl text-left relative overflow-hidden ${locked ? 'pt-8 pb-8' : 'pt-4 pb-4'}`}
                style={{
                  background: active ? voice.bg : 'rgba(255,255,255,0.04)',
                  border: active ? `1.5px solid ${voice.accent}` : '1px solid rgba(255,255,255,0.08)',
                  boxShadow: active ? `0 0 24px ${voice.glow}` : 'none',
                }}
                animate={active ? {
                  boxShadow: [
                    `0 0 16px ${voice.glow.replace('0.55', '0.35')}`,
                    `0 0 32px ${voice.glow}`,
                    `0 0 16px ${voice.glow.replace('0.55', '0.35')}`,
                  ]
                } : {}}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                whileTap={{ scale: 0.98 }}
                initial={{ opacity: 0, y: 14 }}
              >
                {/* Icon */}
                <motion.div
                  className="h-12 w-12 rounded-2xl flex items-center justify-center text-2xl shrink-0"
                  style={{
                    background: active ? voice.bg : 'rgba(255,255,255,0.06)',
                    border: `1px solid ${active ? voice.accent + '66' : 'rgba(255,255,255,0.08)'}`,
                    filter: active ? `drop-shadow(0 0 8px ${voice.accent})` : 'none',
                  }}
                  animate={isPlaying ? { scale: [1, 1.15, 1], rotate: [-4, 4, -4, 0] } : {}}
                  transition={{ duration: 0.4, repeat: isPlaying ? Infinity : 0 }}
                >
                  {voice.icon}
                </motion.div>

                {/* Text */}
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold" style={{ color: active ? '#fff' : '#e4e4e7' }}>
                    {voice.name}
                  </p>
                  <p className="text-[11px] mt-0.5 leading-relaxed" style={{ color: active ? voice.accent + 'cc' : 'rgba(161,161,170,0.7)' }}>
                    {voice.description}
                  </p>
                </div>

                {/* Lock overlay */}
                {locked && (
                  <div className="absolute inset-0 rounded-3xl pointer-events-none"
                    style={{ background: 'rgba(10,0,20,0.4)' }} />
                )}
                {/* Lock icon top-right */}
                {locked && (
                  <div className="absolute top-2 right-2 z-10">
                    <div className="h-6 w-6 rounded-full flex items-center justify-center"
                      style={{ background: 'rgba(196,0,255,0.25)', border: '1px solid #C400FF', boxShadow: '0 0 8px rgba(196,0,255,0.7)' }}>
                      <Lock className="w-3 h-3" style={{ color: '#FFD700' }} />
                    </div>
                  </div>
                )}
                {/* Tooltip bottom */}
                {locked && (
                  <div className="absolute bottom-2 left-0 right-0 flex justify-center z-10">
                    <span className="text-[8px] font-bold px-2 py-0.5 rounded-full"
                      style={{ background: 'rgba(196,0,255,0.3)', color: '#FFD700', border: '1px solid rgba(255,215,0,0.4)', letterSpacing: '0.05em' }}>
                      Unlock with Premium
                    </span>
                  </div>
                )}
                {/* Right actions */}
                <div className="flex flex-col items-end gap-1.5 shrink-0">
                  {!locked && active && (
                    <div className="flex items-center justify-center h-6 w-6 rounded-full"
                      style={{ background: voice.accent + '33', border: `1px solid ${voice.accent}` }}>
                      <Check className="w-3 h-3" style={{ color: voice.accent }} />
                    </div>
                  )}

                  {/* Preview button */}
                  <motion.button
                    onClick={(e) => handlePreview(voice, e)}
                    className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-[10px] font-semibold transition-all"
                    style={{
                      background: isPlaying ? voice.accent + '33' : 'rgba(255,255,255,0.07)',
                      color: isPlaying ? voice.accent : '#71717a',
                      border: isPlaying ? `1px solid ${voice.accent}55` : '1px solid rgba(255,255,255,0.08)',
                    }}
                    whileTap={{ scale: 0.95 }}
                  >
                    <Play className="w-2.5 h-2.5" />
                    {isPlaying ? 'Playing…' : 'Preview'}
                  </motion.button>
                </div>
              </motion.button>
            );
          })}
        </div>

        {/* Active preview banner */}
        <AnimatePresence>
          {previewing && (() => {
            const v = VOICES.find(x => x.id === previewing);
            return v ? (
              <motion.div
                key={previewing}
                className="rounded-2xl px-4 py-3"
                style={{ background: v.bg, border: `1px solid ${v.accent}44` }}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.3 }}
              >
                <p className="text-[10px] font-semibold uppercase tracking-widest mb-1"
                  style={{ color: v.accent }}>🔊 Now Playing — {v.name}</p>
                <p className="text-xs italic leading-relaxed" style={{ color: '#E8CCFF' }}>
                  "{v.preview}"
                </p>
              </motion.div>
            ) : null;
          })()}
        </AnimatePresence>

        {/* Premium upsell */}
        {!isPremium && (
          <motion.button
            onClick={onUpgrade}
            className="w-full rounded-2xl px-4 py-3 flex items-center gap-3"
            style={{ background: 'rgba(196,0,255,0.08)', border: '1px solid rgba(196,0,255,0.25)' }}
            whileTap={{ scale: 0.99 }}
          >
            <span className="text-xl">👑</span>
            <div className="flex-1 text-left">
              <p className="text-xs font-bold" style={{ color: '#E8CCFF' }}>Unlock All Voice Packs</p>
              <p className="text-[10px]" style={{ color: 'rgba(196,0,255,0.55)' }}>Get Premium to access every voice</p>
            </div>
            <span className="text-[10px] font-bold px-2 py-1 rounded-full"
              style={{ background: 'rgba(196,0,255,0.25)', color: '#C400FF', border: '1px solid rgba(196,0,255,0.4)' }}>
              Upgrade →
            </span>
          </motion.button>
        )}

        {/* Confirm */}
        <motion.button
          onClick={handleConfirm}
          className="w-full rounded-2xl text-white font-bold text-base tracking-wide"
          style={{
            height: 52,
            background: `linear-gradient(135deg, ${selectedVoice.accent} 0%, ${selectedVoice.accent}cc 100%)`,
            boxShadow: `0 0 24px ${selectedVoice.glow}`,
          }}
          animate={{ boxShadow: [`0 0 16px ${selectedVoice.glow.replace('0.55','0.35')}`, `0 0 32px ${selectedVoice.glow}`, `0 0 16px ${selectedVoice.glow.replace('0.55','0.35')}`] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          whileTap={{ scale: 0.97 }}
        >
          {selectedVoice.icon} Set {selectedVoice.name}
        </motion.button>

      </div>
    </div>
  );
}