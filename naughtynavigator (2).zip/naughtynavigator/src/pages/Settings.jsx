import React, { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { StackNavigator, useStack } from '../lib/StackNavigator';
import usePullToRefresh from '../lib/usePullToRefresh';
import { base44 } from '@/api/base44Client';
import { motion } from 'framer-motion';
import {
  Trash2, AlertTriangle, MapPin, ChevronRight,
  MessageCircleWarning, Mic, Smile, Map, Shield, FileText, HeadphonesIcon, Info,
  Bell, BellOff,
} from 'lucide-react';
import AboutPage from '../components/navigation/AboutPage';
import PrivacyPolicyContent from '../components/navigation/PrivacyPolicyContent';
import TermsOfServiceContent from '../components/navigation/TermsOfServiceContent';
import ContactSupportContent from '../components/navigation/ContactSupportContent';
import RefundPolicyContent from '../components/navigation/RefundPolicyContent';
import EULAContent from '../components/navigation/EULAContent';
import CommunityGuidelinesContent from '../components/navigation/CommunityGuidelinesContent';
import LocationPermission from '../components/navigation/LocationPermission';
import ErrorStatements from '../components/navigation/ErrorStatements';
import { playTapSound } from '../lib/soundEffects';
import { requestNotificationPermission, getNotificationPermission } from '../lib/pushNotifications';
import VoiceSettingsPage from './settings/VoiceSettingsPage';
import MoodSettingsPage from './settings/MoodSettingsPage';
import MapThemeSettingsPage from './settings/MapThemeSettingsPage';


// ─── Display data (labels only, used for current-value subtitles) ─────────────

const VOICES = [
  { id: 'velvet',   emoji: '🌹', label: 'Velvet Seductress' },
  { id: 'bosslady', emoji: '👠', label: 'Boss Lady' },
  { id: 'princess', emoji: '🎀', label: 'Playful Princess' },
  { id: 'softie',   emoji: '🌸', label: 'Sweetheart Softie' },
  { id: 'mischief', emoji: '😈', label: 'Mischief Mode' },
];

const MOODS = [
  { id: 'naughty',  emoji: '😈', label: 'Naughty' },
  { id: 'chill',    emoji: '😌', label: 'Chill' },
  { id: 'savage',   emoji: '🔥', label: 'Savage' },
  { id: 'romantic', emoji: '💖', label: 'Romantic' },
];

const MAP_THEMES = [
  { id: 'neon',     emoji: '🟣', label: 'Neon Purple' },
  { id: 'dark',     emoji: '⚫', label: 'Dark Mode' },
  { id: 'standard', emoji: '🗺️', label: 'Standard' },
];

// ─── Shared UI helpers ────────────────────────────────────────────────────────

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

function SubPageShell({ title, children }) {
  const { pop } = useStack();
  return (
    <div className="h-full flex flex-col" style={PAGE_BG}>
      <div className="shrink-0 flex items-center gap-3 px-6 py-4" style={{ borderBottom: '1px solid rgba(196,0,255,0.15)' }}>
        <button
          onClick={pop}
          className="h-9 w-9 rounded-2xl flex items-center justify-center text-lg font-bold"
          style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
        >
          ‹
        </button>
        <span className="text-base font-bold" style={{ color: '#E8CCFF' }}>{title}</span>
      </div>
      <div className="flex-1 overflow-hidden">{children}</div>
    </div>
  );
}

function SettingsRow({ icon, iconBg, iconColor, label, desc, onClick, right, danger }) {
  return (
    <motion.button
      onClick={onClick}
      className="w-full flex items-center gap-4 px-5 py-4 text-left transition-all"
      style={{ background: 'transparent' }}
      whileTap={{ scale: 0.99 }}
    >
      <div
        className="h-10 w-10 rounded-2xl flex items-center justify-center shrink-0"
        style={{ background: iconBg, border: `1px solid ${iconColor}33` }}
      >
        {React.cloneElement(icon, { className: 'w-4 h-4', style: { color: iconColor } })}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-semibold" style={{ color: danger ? '#f87171' : '#EDD9FF' }}>{label}</p>
        {desc && <p className="text-[11px] mt-0.5" style={{ color: 'rgba(217,166,255,0.45)' }}>{desc}</p>}
      </div>
      {right ?? <ChevronRight className="w-4 h-4 shrink-0" style={{ color: 'rgba(196,0,255,0.4)' }} />}
    </motion.button>
  );
}

function SettingsCard({ children }) {
  return (
    <div
      className="rounded-2xl overflow-hidden"
      style={{
        background: 'rgba(255,255,255,0.04)',
        border: '1px solid rgba(196,0,255,0.13)',
        backdropFilter: 'blur(12px)',
      }}
    >
      {React.Children.map(children, (child, i) => (
        <div key={i} style={i > 0 ? { borderTop: '1px solid rgba(196,0,255,0.08)' } : {}}>
          {child}
        </div>
      ))}
    </div>
  );
}

function SectionLabel({ children }) {
  return (
    <p className="text-[10px] font-bold uppercase tracking-widest px-1 mb-2" style={{ color: 'rgba(196,0,255,0.55)', letterSpacing: '0.14em' }}>
      {children}
    </p>
  );
}

// ─── Main Settings screen ─────────────────────────────────────────────────────

function SettingsMain() {
  const { push } = useStack();
  const navigate = useNavigate();
  const [showConfirm, setShowConfirm] = useState(false);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleted, setDeleted] = useState(false);
  const [notifPermission, setNotifPermission] = useState(getNotificationPermission());

  const refresh = useCallback(async () => {}, []);

  const { scrollRef, pullY, refreshing } = usePullToRefresh(refresh);

  const handleToggleNotifications = async () => {
    playTapSound();
    if (notifPermission === 'granted') { setNotifPermission('denied'); return; }
    const granted = await requestNotificationPermission();
    setNotifPermission(granted ? 'granted' : 'denied');
  };

  const handleDeleteAccount = async () => {
    setIsDeleting(true);
    try {
      const user = await base44.auth.me();
      await base44.entities.User.delete(user.id);
      setDeleted(true);
      setTimeout(() => base44.auth.logout(), 2000);
    } catch {
      setIsDeleting(false);
    }
  };

  if (deleted) return (
    <div className="min-h-full bg-zinc-950 flex items-center justify-center px-6">
      <div className="text-center space-y-3"><div className="text-4xl">👋</div><p className="text-zinc-300 text-sm">Account deleted. Goodbye!</p></div>
    </div>
  );

  const currentVoice  = VOICES.find(v => v.id === (localStorage.getItem('nn_voice') || 'velvet'));
  const currentMood   = MOODS.find(m => m.id === (localStorage.getItem('nn_mood') || 'naughty'));
  const currentTheme  = MAP_THEMES.find(t => t.id === (localStorage.getItem('nn_map_theme') || 'neon'));
  const notifOn       = notifPermission === 'granted';

  // Inline sub-page wrappers for content-only pages
  const LocationPage    = () => <SubPageShell title="Location Permissions"><LocationPermission onGranted={() => push(SettingsMain)} /></SubPageShell>;
  const ErrorsPage      = () => <SubPageShell title="Error Statements"><ErrorStatements /></SubPageShell>;
  const AboutPageWrapped= () => <SubPageShell title="App Info"><AboutPage /></SubPageShell>;
  const PrivacyPage     = () => <SubPageShell title="Privacy Policy"><PrivacyPolicyContent /></SubPageShell>;
  const TermsPage       = () => <SubPageShell title="Terms of Service"><TermsOfServiceContent /></SubPageShell>;
  const SupportPage     = () => <SubPageShell title="Contact Support"><ContactSupportContent /></SubPageShell>;
  const RefundPage      = () => <SubPageShell title="Refund Policy"><RefundPolicyContent /></SubPageShell>;
  const EulaPage        = () => <SubPageShell title="End‑User License Agreement"><EULAContent /></SubPageShell>;
  const CommunityPage   = () => <SubPageShell title="Community Guidelines"><CommunityGuidelinesContent /></SubPageShell>;

  return (
    <div ref={scrollRef} className="h-full overflow-y-auto" style={PAGE_BG}>
      {/* Ambient glow */}
      <div className="pointer-events-none fixed inset-0 z-0" style={{
        background: 'radial-gradient(ellipse at 50% 0%, rgba(196,0,255,0.18) 0%, transparent 60%)',
      }} />

      {/* Pull indicator */}
      {(pullY > 0 || refreshing) && (
        <div className="flex justify-center" style={{ height: pullY || (refreshing ? 48 : 0), overflow: 'hidden', transition: 'height 0.2s' }}>
          <span style={{ fontSize: 20, paddingTop: 12 }}>{refreshing ? '🔄' : '↓'}</span>
        </div>
      )}

      <div className="relative z-10 px-6 py-8 space-y-7 pb-12">

        {/* Header */}
        <div>
          <h1 className="font-bold" style={{ fontSize: 32, color: '#C400FF', textShadow: '0 0 18px rgba(196,0,255,0.6)', lineHeight: 1.1 }}>
            Settings
          </h1>
          <p className="text-xs mt-1" style={{ color: 'rgba(217,166,255,0.5)' }}>Customize your ride</p>
        </div>

        {/* Notifications */}
        <div className="space-y-2">
          <SectionLabel>Notifications</SectionLabel>
          <SettingsCard>
            <SettingsRow
              icon={notifOn ? <Bell /> : <BellOff />}
              iconBg="rgba(196,0,255,0.15)"
              iconColor="#C400FF"
              label="Push Notifications"
              desc={notifOn ? 'Playful reminders enabled' : 'Tap to enable reminders'}
              onClick={handleToggleNotifications}
              right={
                <div className="w-11 h-6 rounded-full shrink-0 relative transition-all duration-300"
                  style={{
                    background: notifOn ? '#C400FF' : 'rgba(255,255,255,0.1)',
                    boxShadow: notifOn ? '0 0 14px rgba(196,0,255,0.7)' : 'none',
                  }}>
                  <motion.div
                    animate={{ left: notifOn ? 22 : 4 }}
                    transition={{ duration: 0.2 }}
                    className="absolute top-1 w-4 h-4 rounded-full bg-white"
                    style={{ boxShadow: notifOn ? '0 0 6px rgba(196,0,255,0.8)' : 'none' }}
                  />
                </div>
              }
            />
          </SettingsCard>
        </div>

        {/* Privacy & Legal */}
        <div className="space-y-2">
          <SectionLabel>Privacy & Legal</SectionLabel>
          <SettingsCard>
            <SettingsRow icon={<Shield />}          iconBg="rgba(96,165,250,0.12)"  iconColor="#60a5fa" label="Privacy Policy"         desc="How we handle your data"                onClick={() => push(PrivacyPage)} />
            <SettingsRow icon={<FileText />}         iconBg="rgba(96,165,250,0.12)"  iconColor="#60a5fa" label="Terms of Service"        desc="Rules of the road"                      onClick={() => push(TermsPage)} />
            <SettingsRow icon={<FileText />}         iconBg="rgba(96,165,250,0.12)"  iconColor="#60a5fa" label="Refund Policy"           desc="Purchases & refund info"                onClick={() => push(RefundPage)} />
            <SettingsRow icon={<FileText />}         iconBg="rgba(96,165,250,0.12)"  iconColor="#60a5fa" label="EULA"                    desc="End‑User License Agreement"             onClick={() => push(EulaPage)} />
            <SettingsRow icon={<FileText />}         iconBg="rgba(96,165,250,0.12)"  iconColor="#60a5fa" label="Community Guidelines"    desc="Standards for a fun, safe experience"  onClick={() => push(CommunityPage)} />
            <SettingsRow icon={<HeadphonesIcon />}   iconBg="rgba(255,110,179,0.12)" iconColor="#FF6EB3" label="Contact Support"         desc="We're here for you, gorgeous"           onClick={() => push(SupportPage)} />
            <SettingsRow icon={<MapPin />}            iconBg="rgba(196,0,255,0.12)"  iconColor="#C400FF" label="Location Access"         desc="Manage location permissions"            onClick={() => push(LocationPage)} />
            <SettingsRow icon={<MessageCircleWarning />} iconBg="rgba(255,77,255,0.12)" iconColor="#FF4DFF" label="Error Statements"     desc="Playful lines for GPS & route errors"   onClick={() => push(ErrorsPage)} />
          </SettingsCard>
        </div>

        {/* About */}
        <div className="space-y-2">
          <SectionLabel>About Naughty Navigator</SectionLabel>
          <SettingsCard>
            <SettingsRow
              icon={<Info />}
              iconBg="rgba(217,166,255,0.12)"
              iconColor="#D9A6FF"
              label="About Naughty Navigator"
              desc="Version 1.0.0 · App info & brand"
              onClick={() => push(AboutPageWrapped)}
            />
            <SettingsRow
              icon={<Trash2 />}
              iconBg="rgba(239,68,68,0.10)"
              iconColor="#f87171"
              label="Delete Account"
              desc="Permanently remove your account"
              onClick={() => setShowConfirm(true)}
              danger
              right={<ChevronRight className="w-4 h-4 shrink-0 text-red-900" />}
            />
          </SettingsCard>
        </div>

        {/* Footer */}
        <div className="pt-2 text-center space-y-1">
          <p className="text-xs font-medium" style={{ color: '#D9A6FF', opacity: 0.6 }}>Version 1.0.0</p>
          <p className="text-[10px] italic" style={{ color: 'rgba(217,166,255,0.3)' }}>
            "Let me show you what I can really do…"
          </p>
        </div>

      </div>

      {/* Delete confirm modal */}
      {showConfirm && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center px-4"
          style={{ background: 'rgba(0,0,0,0.8)', backdropFilter: 'blur(8px)', paddingBottom: 'max(1.5rem, var(--safe-area-inset-bottom))' }}
        >
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            className="w-full max-w-sm p-6 rounded-3xl space-y-5"
            style={{ background: 'linear-gradient(135deg, #1A0028 0%, #0D0018 100%)', border: '1px solid rgba(196,0,255,0.25)' }}
          >
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-2xl bg-red-500/10 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-red-400" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-white">Delete Account?</h3>
                <p className="text-[11px] mt-0.5" style={{ color: 'rgba(217,166,255,0.5)' }}>This action cannot be undone.</p>
              </div>
            </div>
            <p className="text-xs leading-relaxed" style={{ color: 'rgba(217,166,255,0.6)' }}>
              All your data, preferences, and history will be permanently deleted.
            </p>
            <div className="flex flex-col gap-2">
              <button
                onClick={handleDeleteAccount}
                disabled={isDeleting}
                className="w-full h-12 rounded-2xl bg-red-600 hover:bg-red-500 disabled:opacity-50 text-white text-sm font-semibold transition-colors"
              >
                {isDeleting ? 'Deleting...' : 'Yes, delete my account'}
              </button>
              <button
                onClick={() => setShowConfirm(false)}
                disabled={isDeleting}
                className="w-full h-12 rounded-2xl text-sm font-semibold transition-colors"
                style={{ background: 'rgba(255,255,255,0.06)', color: '#D9A6FF', border: '1px solid rgba(196,0,255,0.2)' }}
              >
                Cancel
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}

// ─── Root export ──────────────────────────────────────────────────────────────

export default function Settings() {
  return <StackNavigator initialScreen={SettingsMain} />;
}