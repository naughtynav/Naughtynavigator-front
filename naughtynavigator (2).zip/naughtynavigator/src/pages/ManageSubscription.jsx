import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

const PLANS = [
  { id: 'trial',        label: '14-Day Trial',  price: '$4.99',  period: '',       color: '#C400FF' },
  { id: 'monthly',      label: 'Monthly',        price: '$9.99',  period: '/mo',    color: '#FF6EB3' },
  { id: 'monthly_plus', label: 'Monthly Plus',   price: '$14.99', period: '/mo',    color: '#FF6EB3', tag: '🎨 All Themes' },
  { id: 'yearly',       label: 'Yearly',         price: '$29.99', period: '/yr',    color: '#FFD700', tag: 'Best Deal' },
];

export default function ManageSubscription({ onBack }) {
  const [currentPlan]   = useState('yearly');   // In production, fetch from Stripe/user record
  const [showCancel, setShowCancel]   = useState(false);
  const [cancelDone, setCancelDone]   = useState(false);
  const [showChange, setShowChange]   = useState(false);
  const [selectedPlan, setSelectedPlan] = useState(currentPlan);
  const [changeDone, setChangeDone]   = useState(false);

  const activePlan = PLANS.find(p => p.id === currentPlan);

  // Billing info (mocked — replace with real Stripe data)
  const billingInfo = {
    nextBillingDate: 'April 29, 2026',
    amount: activePlan?.price,
    period: activePlan?.period,
    status: 'Active',
    memberSince: 'March 2025',
  };

  if (cancelDone) return <CancelConfirmed onBack={onBack} />;

  return (
    <div className="h-full flex flex-col overflow-hidden" style={PAGE_BG}>
      {/* Ambient */}
      <div className="pointer-events-none absolute inset-0 z-0" style={{
        background: 'radial-gradient(ellipse at 50% 10%, rgba(196,0,255,0.2) 0%, transparent 60%)',
      }} />

      {/* Header */}
      <div className="shrink-0 relative z-10 flex items-center gap-3 px-6 py-4" style={{ borderBottom: '1px solid rgba(196,0,255,0.15)' }}>
        <button
          onClick={onBack}
          className="h-9 w-9 rounded-2xl flex items-center justify-center text-lg font-bold"
          style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
        >
          ‹
        </button>
        <h1 className="font-bold" style={{ fontSize: 22, color: '#C400FF', textShadow: '0 0 14px rgba(196,0,255,0.7)' }}>
          Manage Subscription
        </h1>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto relative z-10 px-6 py-7 space-y-5 pb-12">

        {/* Current Plan Card */}
        <motion.div
          className="rounded-3xl p-6"
          style={{
            background: 'linear-gradient(135deg, rgba(196,0,255,0.18) 0%, rgba(196,0,255,0.06) 100%)',
            border: '1.5px solid rgba(196,0,255,0.5)',
            boxShadow: '0 0 32px rgba(196,0,255,0.2)',
          }}
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <div className="flex items-start justify-between mb-4">
            <div>
              <p className="text-xs font-bold uppercase tracking-widest mb-1" style={{ color: 'rgba(196,0,255,0.7)' }}>Current Plan</p>
              <p className="text-xl font-bold" style={{ color: '#FFFFFF' }}>{activePlan?.label}</p>
            </div>
            <motion.div
              className="px-3 py-1 rounded-full text-xs font-bold"
              style={{ background: 'rgba(0,220,130,0.15)', border: '1px solid rgba(0,220,130,0.5)', color: '#4DFFB4' }}
              animate={{ boxShadow: ['0 0 6px rgba(0,220,130,0.2)', '0 0 18px rgba(0,220,130,0.6)', '0 0 6px rgba(0,220,130,0.2)'] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            >
              ● {billingInfo.status}
            </motion.div>
          </div>

          <div className="space-y-2.5">
            <Row label="Price" value={`${billingInfo.amount}${billingInfo.period}`} />
            <Row label="Next Billing" value={billingInfo.nextBillingDate} />
            <Row label="Member Since" value={billingInfo.memberSince} />
          </div>
        </motion.div>

        {/* Change Plan */}
        <SectionLabel text="✦ Change Plan" />
        <AnimatePresence>
          {changeDone ? (
            <motion.div
              key="done"
              className="rounded-2xl px-5 py-4 flex items-center gap-3"
              style={{ background: 'rgba(0,200,100,0.1)', border: '1px solid rgba(0,200,100,0.4)' }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
            >
              <span style={{ fontSize: 22 }}>✅</span>
              <p className="text-sm font-semibold" style={{ color: '#4DFFB4' }}>Plan change requested! Changes take effect at your next billing cycle.</p>
            </motion.div>
          ) : showChange ? (
            <motion.div key="picker" className="space-y-3" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
              {PLANS.filter(p => p.id !== currentPlan).map((plan) => (
                <motion.button
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id)}
                  className="w-full flex items-center gap-4 rounded-2xl px-5 py-4"
                  style={{
                    background: selectedPlan === plan.id ? `rgba(196,0,255,0.15)` : 'rgba(255,255,255,0.04)',
                    border: selectedPlan === plan.id ? '1.5px solid rgba(196,0,255,0.7)' : '1px solid rgba(196,0,255,0.18)',
                    boxShadow: selectedPlan === plan.id ? '0 0 18px rgba(196,0,255,0.3)' : 'none',
                  }}
                  whileTap={{ scale: 0.98 }}
                >
                  <div style={{
                    width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                    border: selectedPlan === plan.id ? `2.5px solid ${plan.color}` : '2px solid rgba(196,0,255,0.35)',
                    background: selectedPlan === plan.id ? plan.color : 'transparent',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                  }}>
                    {selectedPlan === plan.id && <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff' }} />}
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-bold" style={{ color: '#FFFFFF' }}>{plan.label}</p>
                    {plan.tag && <p className="text-xs mt-0.5" style={{ color: 'rgba(217,166,255,0.6)' }}>{plan.tag}</p>}
                  </div>
                  <p className="text-base font-bold shrink-0" style={{ color: plan.color }}>{plan.price}{plan.period}</p>
                </motion.button>
              ))}
              <div className="flex gap-3 pt-1">
                <button
                  onClick={() => setShowChange(false)}
                  className="flex-1 h-12 rounded-2xl text-sm font-semibold"
                  style={{ background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(196,0,255,0.2)', color: '#D9A6FF' }}
                >
                  Cancel
                </button>
                <motion.button
                  onClick={() => setChangeDone(true)}
                  className="flex-1 h-12 rounded-2xl text-sm font-bold text-white"
                  style={{ background: '#C400FF' }}
                  whileTap={{ scale: 0.97 }}
                >
                  Confirm Change
                </motion.button>
              </div>
            </motion.div>
          ) : (
            <motion.button
              key="btn"
              onClick={() => setShowChange(true)}
              className="w-full h-14 rounded-2xl text-sm font-semibold flex items-center justify-center gap-2"
              style={{
                background: 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(196,0,255,0.3)',
                color: '#D9A6FF',
              }}
              whileTap={{ scale: 0.98 }}
            >
              🔀 Switch Plan
            </motion.button>
          )}
        </AnimatePresence>

        {/* Billing History */}
        <SectionLabel text="✦ Billing History" />
        <div className="rounded-2xl overflow-hidden" style={{ border: '1px solid rgba(196,0,255,0.15)' }}>
          {[
            { date: 'Mar 29, 2026', amount: '$29.99', status: 'Paid' },
            { date: 'Mar 29, 2025', amount: '$29.99', status: 'Paid' },
          ].map((item, i, arr) => (
            <div key={i} className="flex items-center justify-between px-5 py-3.5"
              style={{
                background: i % 2 === 0 ? 'rgba(255,255,255,0.04)' : 'rgba(255,255,255,0.02)',
                borderBottom: i < arr.length - 1 ? '1px solid rgba(196,0,255,0.1)' : 'none',
              }}>
              <div>
                <p className="text-sm font-medium" style={{ color: '#EDD9FF' }}>{item.date}</p>
                <p className="text-xs" style={{ color: 'rgba(217,166,255,0.45)' }}>Yearly Plan</p>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold" style={{ color: '#FFFFFF' }}>{item.amount}</p>
                <p className="text-xs font-semibold" style={{ color: '#4DFFB4' }}>{item.status}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Cancel Subscription */}
        <SectionLabel text="✦ Cancel" />
        <AnimatePresence>
          {showCancel ? (
            <motion.div
              key="confirm"
              className="rounded-2xl p-5 space-y-4"
              style={{ background: 'rgba(255,60,60,0.08)', border: '1px solid rgba(255,60,60,0.35)' }}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
            >
              <p className="text-sm font-bold" style={{ color: '#FF8080' }}>Are you sure you want to cancel?</p>
              <p className="text-xs leading-relaxed" style={{ color: 'rgba(255,128,128,0.7)' }}>
                You'll keep access until <strong style={{ color: '#FF8080' }}>{billingInfo.nextBillingDate}</strong>. After that, all premium features will be disabled.
              </p>
              <div className="flex gap-3">
                <button
                  onClick={() => setShowCancel(false)}
                  className="flex-1 h-12 rounded-2xl text-sm font-semibold"
                  style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
                >
                  Keep Premium
                </button>
                <button
                  onClick={() => setCancelDone(true)}
                  className="flex-1 h-12 rounded-2xl text-sm font-bold"
                  style={{ background: 'rgba(255,60,60,0.25)', border: '1px solid rgba(255,60,60,0.5)', color: '#FF8080' }}
                >
                  Yes, Cancel
                </button>
              </div>
            </motion.div>
          ) : (
            <motion.button
              key="cancel-btn"
              onClick={() => setShowCancel(true)}
              className="w-full h-12 rounded-2xl text-sm font-semibold flex items-center justify-center gap-2"
              style={{
                background: 'rgba(255,60,60,0.08)',
                border: '1px solid rgba(255,60,60,0.3)',
                color: '#FF8080',
              }}
              whileTap={{ scale: 0.98 }}
            >
              Cancel Subscription
            </motion.button>
          )}
        </AnimatePresence>

        <p className="text-center text-xs pb-2" style={{ color: 'rgba(217,166,255,0.35)' }}>
          Questions? Contact support@naughtynavigator.app
        </p>
      </div>
    </div>
  );
}

function Row({ label, value }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-xs" style={{ color: 'rgba(217,166,255,0.5)' }}>{label}</span>
      <span className="text-sm font-semibold" style={{ color: '#EDD9FF' }}>{value}</span>
    </div>
  );
}

function SectionLabel({ text }) {
  return (
    <p className="text-[10px] font-bold uppercase tracking-widest px-1" style={{ color: 'rgba(196,0,255,0.55)' }}>
      {text}
    </p>
  );
}

function CancelConfirmed({ onBack }) {
  return (
    <div className="h-full flex flex-col items-center justify-center px-8 text-center" style={PAGE_BG}>
      <motion.div initial={{ opacity: 0, scale: 0.8 }} animate={{ opacity: 1, scale: 1 }} transition={{ duration: 0.4 }}>
        <span style={{ fontSize: 60, filter: 'drop-shadow(0 0 12px rgba(255,100,100,0.6))' }}>💔</span>
        <h2 className="mt-5 text-xl font-bold" style={{ color: '#FFFFFF' }}>Subscription Cancelled</h2>
        <p className="mt-3 text-sm leading-relaxed" style={{ color: 'rgba(217,166,255,0.65)', maxWidth: 260, margin: '12px auto 0' }}>
          We're sad to see you go. You'll have access until your billing period ends.
        </p>
        <motion.button
          onClick={onBack}
          className="mt-8 w-full h-14 rounded-3xl font-bold text-white text-base"
          style={{ background: 'linear-gradient(135deg, #C400FF, #FF00E6)', boxShadow: '0 0 28px rgba(196,0,255,0.6)' }}
          whileTap={{ scale: 0.97 }}
        >
          Back to Settings
        </motion.button>
      </motion.div>
    </div>
  );
}