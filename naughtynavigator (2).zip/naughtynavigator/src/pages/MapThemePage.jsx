import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { playTapSound } from '../lib/soundEffects';

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

const MAP_THEMES = [
  { id: 'neon',     emoji: '🟣', label: 'Neon Purple', desc: 'Cyber-seductive glow',  accent: '#C400FF', premium: true },
  { id: 'dark',     emoji: '⚫', label: 'Dark Mode',   desc: 'Sleek and minimal',      accent: '#71717a', premium: false },
  { id: 'standard', emoji: '🗺️', label: 'Standard',   desc: 'Classic map look',       accent: '#D9A6FF', premium: false },
];

function MapPreview({ themeId }) {
  const isNeon = themeId === 'neon';
  const isDark = themeId === 'dark';
  const roadColor = isNeon ? '#D9A6FF' : isDark ? '#555' : '#94a3b8';
  const routeColor = isNeon ? '#FF4DFF' : isDark ? '#ec4899' : '#f472b6';
  const bgColor = isNeon ? '#0D0015' : isDark ? '#1c1c1e' : '#e8e8e0';
  const glow = isNeon ? 'drop-shadow(0 0 5px #FF4DFF)' : 'none';

  return (
    <div className="rounded-2xl overflow-hidden mb-6" style={{
      border: isNeon ? '1px solid rgba(196,0,255,0.4)' : '1px solid rgba(255,255,255,0.08)',
      boxShadow: isNeon ? '0 0 20px rgba(196,0,255,0.2)' : 'none',
    }}>
      <svg width="100%" viewBox="0 0 280 110" style={{ background: bgColor, display: 'block' }}>
        <line x1="0" y1="55" x2="280" y2="55" stroke={roadColor} strokeWidth="2" />
        <line x1="140" y1="0" x2="140" y2="110" stroke={roadColor} strokeWidth="1.5" />
        <polyline points="20,90 70,60 130,55 180,45 260,20" fill="none" stroke={routeColor} strokeWidth="3" strokeLinecap="round" style={{ filter: glow }} />
        {isNeon && <>
          <circle cx="70" cy="60" r="4" fill="#FF4DFF" style={{ filter: 'drop-shadow(0 0 4px #FF4DFF)' }} />
          <circle cx="180" cy="45" r="4" fill="#FF4DFF" style={{ filter: 'drop-shadow(0 0 4px #FF4DFF)' }} />
        </>}
        <circle cx="260" cy="20" r="5" fill={routeColor} style={{ filter: glow }} />
      </svg>
    </div>
  );
}

function PremiumGate({ onUpgrade, onBack }) {
  return (
    <div className="h-full flex flex-col items-center justify-center px-8 text-center" style={{ background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' }}>
      <div className="pointer-events-none absolute inset-0" style={{ background: 'radial-gradient(ellipse at 50% 30%, rgba(196,0,255,0.25) 0%, transparent 65%)' }} />
      <div className="relative z-10 flex flex-col items-center gap-5 max-w-xs">
        <motion.div animate={{ scale: [1, 1.12, 1] }} transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}>
          <span style={{ fontSize: 64, filter: 'drop-shadow(0 0 18px rgba(196,0,255,0.9))' }}>👑</span>
        </motion.div>
        <h2 className="text-2xl font-bold" style={{ color: '#FFFFFF' }}>Premium Feature</h2>
        <p className="text-sm leading-relaxed" style={{ color: 'rgba(217,166,255,0.7)' }}>
          Map Themes are exclusive to Premium members. Unlock neon glows, dark mode, and all future visual styles.
        </p>
        <motion.button
          onClick={onUpgrade}
          className="w-full h-14 rounded-3xl font-bold text-white text-base"
          style={{ background: 'linear-gradient(135deg, #C400FF, #FF00E6)' }}
          animate={{ boxShadow: ['0 0 20px rgba(196,0,255,0.5)', '0 0 44px rgba(196,0,255,1)', '0 0 20px rgba(196,0,255,0.5)'] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          whileTap={{ scale: 0.97 }}
        >
          ✨ Unlock Premium
        </motion.button>
        <button onClick={onBack} className="text-sm" style={{ color: 'rgba(217,166,255,0.45)' }}>← Go Back</button>
      </div>
    </div>
  );
}

export default function MapThemePage() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState(() => localStorage.getItem('nn_map_theme') || 'neon');
  const isPremium = localStorage.getItem('nn_premium') === 'true';

  if (!isPremium) return <PremiumGate onUpgrade={() => navigate('/upgrade')} onBack={() => navigate('/')} />;

  const handleSelect = (t) => {
    if (t.premium && !isPremium) return;
    playTapSound();
    setSelected(t.id);
    localStorage.setItem('nn_map_theme', t.id);
  };

  return (
    <div className="h-full flex flex-col" style={PAGE_BG}>
      {/* Header */}
      <div className="shrink-0 flex items-center gap-3 px-6 py-4" style={{ borderBottom: '1px solid rgba(196,0,255,0.15)' }}>
        <button
          onClick={() => navigate('/')}
          className="h-9 w-9 rounded-2xl flex items-center justify-center"
          style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-lg font-bold" style={{ color: '#E8CCFF' }}>Map Themes</h1>
          <p className="text-[11px]" style={{ color: 'rgba(217,166,255,0.45)' }}>Pick the vibe for your map</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        <MapPreview themeId={selected} />

        <div className="space-y-3">
          {MAP_THEMES.map((t) => {
            const active = selected === t.id;
            const locked = t.premium && !isPremium;
            return (
              <motion.button
                key={t.id}
                onClick={() => handleSelect(t)}
                className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-left"
                style={{
                  background: active ? `${t.accent}18` : 'rgba(255,255,255,0.04)',
                  border: active ? `1.5px solid ${t.accent}` : '1px solid rgba(255,255,255,0.08)',
                  boxShadow: active ? `0 0 16px ${t.accent}33` : 'none',
                  opacity: locked ? 0.65 : 1,
                }}
                animate={active ? { boxShadow: [`0 0 12px ${t.accent}22`, `0 0 24px ${t.accent}55`, `0 0 12px ${t.accent}22`] } : {}}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                whileTap={{ scale: locked ? 1 : 0.98 }}
              >
                <span className="text-2xl">{t.emoji}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold" style={{ color: active ? '#fff' : '#a1a1aa' }}>{t.label}</p>
                  <p className="text-[11px] mt-0.5" style={{ color: 'rgba(217,166,255,0.35)' }}>{t.desc}</p>
                </div>
                {locked && (
                  <div className="flex items-center gap-1 shrink-0">
                    <Lock className="w-3.5 h-3.5" style={{ color: '#C400FF' }} />
                    <span className="text-[10px] font-bold" style={{ color: '#C400FF' }}>Premium</span>
                  </div>
                )}
                {active && !locked && (
                  <span className="text-xs font-bold px-2 py-0.5 rounded-full shrink-0" style={{ background: t.accent + '33', color: t.accent }}>
                    Active
                  </span>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    </div>
  );
}