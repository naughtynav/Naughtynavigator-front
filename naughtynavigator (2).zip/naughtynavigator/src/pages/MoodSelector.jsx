import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock } from 'lucide-react';
import { playTapSound } from '../lib/soundEffects';
import { trackEvent } from '../lib/pushNotifications';

const MOODS = [
  {
    id: 'naughty',
    emoji: '😈',
    label: 'Naughty',
    accent: '#FF00E6',
    glow: 'rgba(255,0,230,0.5)',
    bg: 'rgba(255,0,230,0.1)',
    preview: "Oh, we're going naughty today? I thought you'd never ask…",
    premium: false,
  },
  {
    id: 'chill',
    emoji: '😎',
    label: 'Chill',
    accent: '#00C8FF',
    glow: 'rgba(0,200,255,0.5)',
    bg: 'rgba(0,200,255,0.1)',
    preview: "Easy, breezy, no rush. Just vibes and open roads.",
    premium: false,
  },
  {
    id: 'savage',
    emoji: '🔥',
    label: 'Savage',
    accent: '#FF2222',
    glow: 'rgba(255,34,34,0.5)',
    bg: 'rgba(255,34,34,0.1)',
    preview: "Savage mode activated. I'll match your energy. Let's GO.",
    premium: false,
  },
  {
    id: 'romantic',
    emoji: '💖',
    label: 'Romantic',
    accent: '#FF6EB3',
    glow: 'rgba(255,110,179,0.5)',
    bg: 'rgba(255,110,179,0.1)',
    preview: "Someone's got plans tonight… every mile will feel special.",
    premium: false,
  },
  {
    id: 'sweet',
    emoji: '😊',
    label: 'Sweet',
    accent: '#FFD700',
    glow: 'rgba(255,215,0,0.5)',
    bg: 'rgba(255,215,0,0.1)',
    preview: "Aww, you picked sweet. I'll be the kindest co-pilot ever.",
    premium: true,
  },
  {
    id: 'mysterious',
    emoji: '🌙',
    label: 'Mysterious',
    accent: '#A855F7',
    glow: 'rgba(168,85,247,0.5)',
    bg: 'rgba(168,85,247,0.1)',
    preview: "Shhh… follow the shadows. I know all the secret routes.",
    premium: true,
  },
];

const INTENSITY_LABELS = ['Soft', 'Medium', 'Spicy', 'Extra', 'Max'];

export default function MoodSelector({ onBack, onUpgrade, onSelectVoice }) {
  const [selected, setSelected] = useState(() => localStorage.getItem('nn_mood') || 'naughty');
  const [intensity, setIntensity] = useState(() => parseInt(localStorage.getItem('nn_mood_intensity') || '2'));
  const [previewVisible, setPreviewVisible] = useState(true);
  const isPremium = localStorage.getItem('nn_premium') === 'true';

  const selectedMood = MOODS.find(m => m.id === selected) || MOODS[0];

  const handleSelect = (mood) => {
    if (mood.premium && !isPremium) { playTapSound(); onUpgrade?.(mood.id); return; }
    playTapSound();
    setSelected(mood.id);
    localStorage.setItem('nn_mood', mood.id);
    trackEvent('mood_changed', { to: mood.id, intensity });
    setPreviewVisible(false);
    setTimeout(() => setPreviewVisible(true), 50);
  };

  const handleIntensityChange = (val) => {
    setIntensity(val);
    localStorage.setItem('nn_mood_intensity', String(val));
  };

  const handleConfirm = () => {
    playTapSound();
    onSelectVoice?.();
  };

  return (
    <div
      className="flex flex-col h-full overflow-y-auto"
      style={{ background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' }}
    >
      {/* Ambient glow */}
      <div
        className="pointer-events-none fixed inset-0 z-0"
        style={{ background: `radial-gradient(ellipse at 50% 0%, ${selectedMood.glow.replace('0.5', '0.12')} 0%, transparent 55%)`, transition: 'background 0.6s ease' }}
      />

      <div className="relative z-10 flex flex-col gap-6 px-5 py-6 pb-10">

        {/* Header */}
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="h-9 w-9 rounded-2xl flex items-center justify-center text-lg font-bold shrink-0"
            style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
          >
            ‹
          </button>
          <div className="flex-1 text-center pr-9">
            <h1
              className="text-xl font-extrabold"
              style={{ color: '#FFFFFF', textShadow: `0 0 20px ${selectedMood.glow}`, transition: 'text-shadow 0.4s ease' }}
            >
              Choose Your Mood
            </h1>
            <p className="text-xs mt-0.5" style={{ color: 'rgba(217,166,255,0.55)' }}>
              Tell me how you're feeling…
            </p>
          </div>
        </div>

        {/* Mood Grid */}
        <div className="grid grid-cols-2 gap-3">
          {MOODS.map((mood, i) => {
            const active = selected === mood.id;
            const locked = mood.premium && !isPremium;
            return (
              <motion.button
                key={mood.id}
                onClick={() => handleSelect(mood)}
                className="relative flex flex-col items-center justify-center gap-2 py-6 rounded-3xl overflow-hidden text-center"
                style={{
                  background: active ? mood.bg : 'rgba(255,255,255,0.04)',
                  border: active ? `1.5px solid ${mood.accent}` : '1px solid rgba(255,255,255,0.08)',
                  boxShadow: active ? `0 0 24px ${mood.glow}` : 'none',
                  opacity: locked ? 0.55 : 1,
                }}
                animate={active ? { boxShadow: [`0 0 16px ${mood.glow.replace('0.5','0.4')}`, `0 0 32px ${mood.glow}`, `0 0 16px ${mood.glow.replace('0.5','0.4')}`] } : {}}
                transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
                whileTap={{ scale: locked ? 1 : 0.95 }}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: locked ? 0.55 : 1, y: 0, ...(active ? {} : {}) }}
                // framer-motion animate override for glow
              >
                <motion.span
                  className="text-3xl"
                  style={{ filter: active ? `drop-shadow(0 0 10px ${mood.accent})` : 'none' }}
                  animate={active ? { scale: [1, 1.15, 1] } : { scale: 1 }}
                  transition={{ duration: 1.5, repeat: active ? Infinity : 0, ease: 'easeInOut' }}
                >
                  {mood.emoji}
                </motion.span>
                <p className="text-sm font-bold" style={{ color: active ? '#fff' : '#a1a1aa' }}>
                  {mood.label}
                </p>
                {active && (
                  <span
                    className="absolute top-2 right-2 text-[9px] font-bold px-1.5 py-0.5 rounded-full"
                    style={{ background: mood.accent + '33', color: mood.accent, border: `1px solid ${mood.accent}55` }}
                  >
                    ✓
                  </span>
                )}
                {/* Semi-transparent overlay */}
                {locked && (
                  <div className="absolute inset-0 rounded-3xl pointer-events-none"
                    style={{ background: 'rgba(10,0,20,0.45)' }} />
                )}
                {/* Lock icon top-right */}
                {locked && (
                  <div
                    className="absolute top-2 right-2 flex flex-col items-center gap-0.5 z-10"
                  >
                    <div className="h-6 w-6 rounded-full flex items-center justify-center"
                      style={{ background: 'rgba(196,0,255,0.25)', border: '1px solid #C400FF', boxShadow: '0 0 8px rgba(196,0,255,0.7)' }}>
                      <Lock className="w-3 h-3" style={{ color: '#FFD700' }} />
                    </div>
                  </div>
                )}
                {/* Tooltip label at bottom */}
                {locked && (
                  <div className="absolute bottom-2 left-0 right-0 flex justify-center z-10">
                    <span className="text-[8px] font-bold px-2 py-0.5 rounded-full"
                      style={{ background: 'rgba(196,0,255,0.3)', color: '#FFD700', border: '1px solid rgba(255,215,0,0.4)', letterSpacing: '0.05em' }}>
                      Unlock with Premium
                    </span>
                  </div>
                )}
              </motion.button>
            );
          })}
        </div>

        {/* Preview Line */}
        <AnimatePresence mode="wait">
          {previewVisible && (
            <motion.div
              key={selected}
              className="rounded-2xl px-4 py-4"
              style={{
                background: selectedMood.bg,
                border: `1px solid ${selectedMood.accent}44`,
                boxShadow: `0 0 16px ${selectedMood.glow.replace('0.5', '0.1')}`,
              }}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3 }}
            >
              <p className="text-[10px] font-semibold uppercase tracking-widest mb-2"
                style={{ color: selectedMood.accent }}>
                ✦ Preview — How I'll talk to you
              </p>
              <p className="text-sm italic leading-relaxed" style={{ color: '#E8CCFF' }}>
                "{selectedMood.preview}"
              </p>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Intensity Slider */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold uppercase tracking-widest" style={{ color: 'rgba(196,0,255,0.6)' }}>
              Intensity
            </p>
            <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
              style={{ background: selectedMood.bg, color: selectedMood.accent, border: `1px solid ${selectedMood.accent}44` }}>
              {INTENSITY_LABELS[intensity]}
            </span>
          </div>
          <div className="relative">
            <input
              type="range"
              min={0}
              max={4}
              value={intensity}
              onChange={(e) => handleIntensityChange(parseInt(e.target.value))}
              className="w-full h-2 rounded-full appearance-none cursor-pointer"
              style={{
                background: `linear-gradient(to right, ${selectedMood.accent} 0%, ${selectedMood.accent} ${(intensity / 4) * 100}%, rgba(255,255,255,0.1) ${(intensity / 4) * 100}%, rgba(255,255,255,0.1) 100%)`,
                accentColor: selectedMood.accent,
              }}
            />
            <div className="flex justify-between mt-1.5">
              {INTENSITY_LABELS.map((l) => (
                <span key={l} className="text-[9px]" style={{ color: 'rgba(217,166,255,0.3)' }}>{l}</span>
              ))}
            </div>
          </div>
        </div>

        {/* Confirm Button */}
        <motion.button
          onClick={handleConfirm}
          className="w-full h-13 rounded-2xl text-white font-bold text-base tracking-wide"
          style={{
            height: 52,
            background: `linear-gradient(135deg, ${selectedMood.accent} 0%, ${selectedMood.accent}cc 100%)`,
            boxShadow: `0 0 24px ${selectedMood.glow}`,
          }}
          animate={{ boxShadow: [`0 0 16px ${selectedMood.glow.replace('0.5','0.4')}`, `0 0 32px ${selectedMood.glow}`, `0 0 16px ${selectedMood.glow.replace('0.5','0.4')}`] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          whileTap={{ scale: 0.97 }}
        >
          💋 Set Sultry Seduction
        </motion.button>

        {!isPremium && (
          <div className="rounded-2xl px-4 py-3 text-center"
            style={{ background: 'rgba(196,0,255,0.07)', border: '1px solid rgba(196,0,255,0.2)' }}>
            <p className="text-xs italic" style={{ color: '#9B60CC' }}>
              🔒 Unlock Sweet & Mysterious moods with Premium 👑
            </p>
          </div>
        )}
      </div>
    </div>
  );
}