import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Mic, Smile, Navigation as NavIcon, Square, Zap } from 'lucide-react';
import MoodSelector from './MoodSelector';
import VoicePackSelectionPage from './VoicePackSelectionPage';
import NavigationMap from '../components/navigation/NavigationMap';
import DestinationInput from '../components/navigation/DestinationInput';
import SimulatedRoute from '../components/navigation/SimulatedRoute';
import { playTapSound } from '../lib/soundEffects';
import { getLine, speak, cancelSpeech } from '../lib/voiceSystem';
import VoiceCommentBar from '../components/navigation/VoiceCommentBar';

const PAGE_BG = 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)';

export default function Navigation({ selectedVoice, onVoiceChange, isPremium, onUpgrade }) {
  const [view, setView] = useState('map'); // map | mood | voice
  const [destination, setDestination] = useState(null);
  const [isNavigating, setIsNavigating] = useState(false);

  const [routeData, setRouteData] = useState(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [userLocation, setUserLocation] = useState(null);
  const [neonMode, setNeonMode] = useState(() => localStorage.getItem('nn_map_theme') === 'neon');
  const [destinationInput, setDestinationInput] = useState('');
  const [currentComment, setCurrentComment] = useState('');
  const [isMuted, setIsMuted] = useState(false);
  const isMutedRef = useRef(false);
  const stepTimerRef = useRef(null);

  // Keep ref in sync so interval callbacks always read latest mute state
  useEffect(() => { isMutedRef.current = isMuted; }, [isMuted]);

  const activeVoice = localStorage.getItem('nn_voice') || selectedVoice || 'velvet';

  const sayLine = (type) => {
    const line = getLine(activeVoice, type);
    setCurrentComment(line);
    if (!isMutedRef.current) speak(line, activeVoice);
  };

  // Get user location on mount
  useEffect(() => {
    navigator.geolocation?.getCurrentPosition(
      (pos) => setUserLocation([pos.coords.latitude, pos.coords.longitude]),
      () => setUserLocation([40.7128, -74.0060]) // fallback NYC
    );
  }, []);

  // Pre-load voices on mount (Chrome Android requires this)
  useEffect(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.getVoices();
      window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.getVoices(); // warm the list
      };
    }
  }, []);

  const handleStartNavigation = (dest) => {
    // Clear any existing interval first
    if (stepTimerRef.current) clearInterval(stepTimerRef.current);

    playTapSound();
    setDestination(dest);
    setIsNavigating(true);
    setCurrentStep(0);
    sayLine('start');

    setRouteData({
      destination: dest,
      steps: [
        { instruction: 'Head north on Main St', distance: '0.3 mi', maneuver: 'straight' },
        { instruction: 'Turn right onto Oak Ave', distance: '0.5 mi', maneuver: 'turn-right' },
        { instruction: 'Turn left onto Broadway', distance: '1.2 mi', maneuver: 'turn-left' },
        { instruction: 'Continue straight on Highway 1', distance: '2.1 mi', maneuver: 'straight' },
        { instruction: 'Arrive at destination', distance: '', maneuver: 'arrive' },
      ],
      totalDistance: '4.1 mi',
      totalDuration: '12 min',
    });

    const stepTypes = ['straight', 'turnRight', 'turnLeft', 'straight'];
    let step = 0;
    stepTimerRef.current = setInterval(() => {
      step += 1;
      setCurrentStep(step);
      if (step < 4) sayLine(stepTypes[step - 1]);

      if (step >= 4) {
        clearInterval(stepTimerRef.current);
        stepTimerRef.current = null;

        try {
          const trips = JSON.parse(localStorage.getItem('nn_trips') || '[]');
          trips.unshift({ destination: dest, date: new Date().toISOString(), duration: '12 min', distance: '4.1 mi' });
          localStorage.setItem('nn_trips', JSON.stringify(trips.slice(0, 20)));
        } catch {}

        sayLine('arrived');
        setTimeout(() => handleStopNavigation(), 4000);
      }
    }, 15000);
  };

  const handleStopNavigation = () => {
    if (stepTimerRef.current) {
      clearInterval(stepTimerRef.current);
      stepTimerRef.current = null;
    }
    cancelSpeech();
    setIsNavigating(false);
    setDestination(null);
    setRouteData(null);
    setCurrentStep(0);
    setCurrentComment('');
  };

  // Sub-views
  if (view === 'mood') return <MoodSelector onBack={() => setView('map')} onUpgrade={onUpgrade} onSelectVoice={() => setView('voice')} />;
  if (view === 'voice') return <VoicePackSelectionPage onBack={() => setView('map')} onUpgrade={onUpgrade} />;

  return (
    <div className="flex flex-col h-full relative overflow-hidden" style={{ background: '#0D0018' }}>

      {/* MAP — fills most of the screen */}
      <div className="flex-1 relative">
        <NavigationMap
          userLocation={userLocation}
          destination={destination}
          routeData={routeData}
          isPremium={neonMode}
        />

        {/* Destination input overlay — top of map */}
        {!isNavigating && (
          <div className="absolute top-3 left-3 right-3" style={{ zIndex: 1000 }}>
            <DestinationInput onStartNavigation={handleStartNavigation} isNavigating={isNavigating} onStopNavigation={handleStopNavigation} value={destinationInput} onChange={setDestinationInput} />
          </div>
        )}

        {/* Active route card */}
        {isNavigating && routeData && (
          <div className="absolute top-3 left-3 right-3" style={{ zIndex: 1000 }}>
            <SimulatedRoute
              destination={routeData.destination}
              step={currentStep}
              totalSteps={routeData.steps.length}
            />
          </div>
        )}

        {/* Voice comment bar — bottom of map while navigating */}
        {isNavigating && (
          <div className="absolute bottom-3 left-3 right-3" style={{ zIndex: 1000 }}>
            <VoiceCommentBar
              comment={currentComment}
              isMuted={isMuted}
              onToggleMute={() => setIsMuted(m => !m)}
            />
          </div>
        )}
      </div>

      {/* Bottom control bar */}
      <div
        className="shrink-0 flex flex-col gap-1 px-4 pt-2 pb-3"
        style={{ background: 'rgba(13,0,24,0.95)', borderTop: '1px solid rgba(196,0,255,0.15)', backdropFilter: 'blur(12px)' }}
      >
        {/* GO / Stop button — full width */}
        {!isNavigating ? (
          <motion.button
            className="w-full h-12 rounded-2xl text-white font-bold text-sm tracking-wide"
            style={{
              background: 'linear-gradient(135deg,#C400FF 0%,#FF00E6 100%)',
              boxShadow: '0 0 22px rgba(196,0,255,0.7)',
            }}
            animate={{ boxShadow: ['0 0 14px rgba(196,0,255,0.5)', '0 0 28px rgba(196,0,255,0.9)', '0 0 14px rgba(196,0,255,0.5)'] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            whileTap={{ scale: 0.96 }}
            onClick={() => {
              if (destinationInput.trim()) {
                handleStartNavigation(destinationInput.trim());
              }
            }}
          >
            <NavIcon className="inline w-4 h-4 mr-1.5 -mt-0.5" />
            Go
          </motion.button>
        ) : (
          <motion.button
            onClick={handleStopNavigation}
            className="w-full h-12 rounded-2xl text-white font-bold text-sm tracking-wide flex items-center justify-center gap-2"
            style={{ background: 'rgba(239,68,68,0.2)', border: '1.5px solid rgba(239,68,68,0.6)' }}
            whileTap={{ scale: 0.96 }}
          >
            <Square className="w-4 h-4 text-red-400 fill-red-400" />
            Stop
          </motion.button>
        )}

        {/* Control buttons row: Mood / Neon / Voice */}
        <div className="flex items-center gap-2 justify-center">
          {/* Mood button */}
          <motion.button
            onClick={() => { playTapSound(); setView('mood'); }}
            className="flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-xl flex-1"
            style={{ background: 'rgba(196,0,255,0.1)', border: '1px solid rgba(196,0,255,0.25)' }}
            whileTap={{ scale: 0.93 }}
          >
            <Smile className="w-4 h-4" style={{ color: '#C400FF' }} />
            <span className="text-[8px] font-semibold" style={{ color: 'rgba(217,166,255,0.7)' }}>Mood</span>
          </motion.button>

          {/* Neon button */}
          <motion.button
            onClick={() => { playTapSound(); setNeonMode(!neonMode); localStorage.setItem('nn_map_theme', !neonMode ? 'neon' : 'standard'); }}
            className="flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-xl flex-1"
            style={{
              background: neonMode ? 'rgba(196,0,255,0.2)' : 'rgba(196,0,255,0.08)',
              border: neonMode ? '1px solid rgba(196,0,255,0.5)' : '1px solid rgba(196,0,255,0.2)',
              boxShadow: neonMode ? '0 0 8px rgba(196,0,255,0.5)' : 'none',
            }}
            whileTap={{ scale: 0.93 }}
          >
            <Zap className="w-4 h-4" style={{ color: neonMode ? '#C400FF' : 'rgba(196,0,255,0.5)' }} />
            <span className="text-[8px] font-semibold" style={{ color: 'rgba(217,166,255,0.7)' }}>Neon</span>
          </motion.button>

          {/* Voice button */}
          <motion.button
            onClick={() => { playTapSound(); setView('voice'); }}
            className="flex flex-col items-center gap-0.5 px-2.5 py-1.5 rounded-xl flex-1"
            style={{ background: 'rgba(255,0,230,0.1)', border: '1px solid rgba(255,0,230,0.25)' }}
            whileTap={{ scale: 0.93 }}
          >
            <Mic className="w-4 h-4" style={{ color: '#FF00E6' }} />
            <span className="text-[8px] font-semibold" style={{ color: 'rgba(217,166,255,0.7)' }}>Voice</span>
          </motion.button>
        </div>

        {/* Upgrade to Premium */}
        {!isPremium && (
          <motion.button
            onClick={() => { playTapSound(); onUpgrade?.(); }}
            className="w-full h-10 rounded-xl flex items-center justify-center gap-2 font-bold text-sm"
            style={{
              background: 'linear-gradient(135deg, #C400FF, #FF00E6)',
              color: '#fff',
            }}
            animate={{ boxShadow: ['0 0 8px rgba(196,0,255,0.4)', '0 0 16px rgba(196,0,255,0.8)', '0 0 8px rgba(196,0,255,0.4)'] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
            whileTap={{ scale: 0.96 }}
          >
            <span>👑</span>
            Upgrade Premium
          </motion.button>
        )}
      </div>
    </div>
  );
}