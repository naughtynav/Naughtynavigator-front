import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { speakComment } from '../components/navigation/SeductiveComments';
import { playTapSound } from '../lib/soundEffects';

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

const VOICES = [
  { id: 'velvet',   emoji: '🌹', label: 'Velvet Seductress', desc: 'Flirty & Seductive',  accent: '#FF00E6', img: 'https://media.base44.com/images/public/69b8572fda649af9ebb82bbc/79c982dff_generated_image.png' },
  { id: 'bosslady', emoji: '👠', label: 'Boss Lady',          desc: 'Bold & Dominant',   accent: '#C400FF', img: 'https://media.base44.com/images/public/69b8572fda649af9ebb82bbc/46c8d54cc_generated_image.png' },
  { id: 'princess', emoji: '🎀', label: 'Playful Princess',   desc: 'Sweet & Fun',       accent: '#FF6EB3', img: 'https://media.base44.com/images/public/69b8572fda649af9ebb82bbc/cb7c1e93f_generated_image.png' },
  { id: 'softie',   emoji: '🌸', label: 'Sweetheart Softie',  desc: 'Warm & Gentle',     accent: '#D9A6FF', img: 'https://media.base44.com/images/public/69b8572fda649af9ebb82bbc/05df8a1b5_generated_image.png' },
  { id: 'mischief', emoji: '😈', label: 'Mischief Mode',      desc: 'Wild & Unpredictable', accent: '#FF4DFF', img: 'https://media.base44.com/images/public/69b8572fda649af9ebb82bbc/e561994ff_generated_image.png' },
];

const VOICE_PREVIEWS = {
  velvet:   "Mmm… close your eyes for just a second. Breathe. Now follow my voice, gorgeous.",
  bosslady: "Alright, listen up. Route calculated. I'm in charge now — keep up.",
  princess: "Omg we're going on a TRIP?! I'm SO ready, let's GOOO! 🎀",
  softie:   "Hey, I'm so glad you're here. Let's find our way together, nice and easy.",
  mischief: "Navigation activated. Chaos level: moderate. Let's seeeee where this goes!",
};

const MOODS = [
  { id: 'naughty',  emoji: '😈', label: 'Naughty',  color: '#FF4DFF' },
  { id: 'chill',    emoji: '😌', label: 'Chill',    color: '#D9A6FF' },
  { id: 'savage',   emoji: '🔥', label: 'Savage',   color: '#FF2222' },
  { id: 'romantic', emoji: '💖', label: 'Romantic', color: '#FF6EB3' },
];

const MOOD_LINES = {
  naughty:  "Oh, we're going naughty today? I thought you'd never ask. 😈",
  chill:    "Easy, breezy, beautiful… no rush. Just vibes. 😌",
  savage:   "Savage mode activated. I'll match your energy. Let's GO. 🔥",
  romantic: "Someone's got plans tonight… I'll make every mile feel special. 💖",
};

function SectionLabel({ children }) {
  return (
    <p className="text-[10px] font-bold uppercase tracking-widest mb-3" style={{ color: 'rgba(196,0,255,0.55)', letterSpacing: '0.14em' }}>
      {children}
    </p>
  );
}

function PremiumGate({ onUpgrade, onBack }) {
  return (
    <div className="h-full flex flex-col items-center justify-center px-8 text-center" style={{ background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' }}>
      <div className="pointer-events-none absolute inset-0" style={{ background: 'radial-gradient(ellipse at 50% 30%, rgba(196,0,255,0.25) 0%, transparent 65%)' }} />
      <div className="relative z-10 flex flex-col items-center gap-5 max-w-xs">
        <motion.div animate={{ scale: [1, 1.12, 1] }} transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}>
          <span style={{ fontSize: 64, filter: 'drop-shadow(0 0 18px rgba(196,0,255,0.9))' }}>👑</span>
        </motion.div>
        <h2 className="text-2xl font-bold" style={{ color: '#FFFFFF' }}>Premium Feature</h2>
        <p className="text-sm leading-relaxed" style={{ color: 'rgba(217,166,255,0.7)' }}>
          Voice & Personality settings are exclusive to Premium members. Unlock all voices, moods, and seductive vibes.
        </p>
        <motion.button
          onClick={onUpgrade}
          className="w-full h-14 rounded-3xl font-bold text-white text-base"
          style={{ background: 'linear-gradient(135deg, #C400FF, #FF00E6)' }}
          animate={{ boxShadow: ['0 0 20px rgba(196,0,255,0.5)', '0 0 44px rgba(196,0,255,1)', '0 0 20px rgba(196,0,255,0.5)'] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          whileTap={{ scale: 0.97 }}
        >
          ✨ Unlock Premium
        </motion.button>
        <button onClick={onBack} className="text-sm" style={{ color: 'rgba(217,166,255,0.45)' }}>← Go Back</button>
      </div>
    </div>
  );
}

export default function VoicePersonalityPage() {
  const navigate = useNavigate();
  const isPremium = localStorage.getItem('nn_premium') === 'true';

  const [selectedVoice, setSelectedVoice] = useState(() => localStorage.getItem('nn_voice') || 'velvet');
  const [previewing, setPreviewing] = useState(null);
  const [selectedMood, setSelectedMood] = useState(() => localStorage.getItem('nn_mood') || 'naughty');
  const [flash, setFlash] = useState(null);
  const [moodLine, setMoodLine] = useState('');

  if (!isPremium) return <PremiumGate onUpgrade={() => navigate('/upgrade')} onBack={() => navigate('/')} />;

  const handleSelectVoice = (v) => {
    if (!isPremium && v.id !== 'velvet') return;
    playTapSound();
    setSelectedVoice(v.id);
    localStorage.setItem('nn_voice', v.id);
  };

  const handlePreview = (v, e) => {
    e.stopPropagation();
    if (!isPremium && v.id !== 'velvet') return;
    playTapSound();
    setPreviewing(v.id);
    speakComment(VOICE_PREVIEWS[v.id], v.id);
    setTimeout(() => setPreviewing(null), 2500);
  };

  const handleSelectMood = (m) => {
    playTapSound();
    setSelectedMood(m.id);
    localStorage.setItem('nn_mood', m.id);
    setMoodLine(MOOD_LINES[m.id] || '');
    setFlash(m.id);
    setTimeout(() => setFlash(null), 600);
  };

  return (
    <div className="h-full flex flex-col" style={PAGE_BG}>
      {/* Header */}
      <div className="shrink-0 flex items-center gap-3 px-6 py-4" style={{ borderBottom: '1px solid rgba(196,0,255,0.15)' }}>
        <button
          onClick={() => navigate('/')}
          className="h-9 w-9 rounded-2xl flex items-center justify-center"
          style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h1 className="text-lg font-bold" style={{ color: '#E8CCFF' }}>Voice & Personality</h1>
          <p className="text-[11px]" style={{ color: 'rgba(217,166,255,0.45)' }}>Choose your co-pilot's voice & vibe</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-7">

        {/* ── VOICE ── */}
        <div>
          <SectionLabel>🎤 Voice Selection</SectionLabel>
          <div className="space-y-3">
            {VOICES.map((v) => {
              const active = selectedVoice === v.id;
              const locked = !isPremium && v.id !== 'velvet';
              const isPlaying = previewing === v.id;
              return (
                <motion.button
                  key={v.id}
                  onClick={() => handleSelectVoice(v)}
                  className="w-full flex items-center gap-3 px-3 py-3 rounded-2xl text-left relative overflow-hidden"
                  style={{
                    background: active ? `${v.accent}18` : 'rgba(255,255,255,0.04)',
                    border: active ? `1.5px solid ${v.accent}` : '1px solid rgba(255,255,255,0.08)',
                    boxShadow: active ? `0 0 20px ${v.accent}44` : 'none',
                    opacity: locked ? 0.6 : 1,
                  }}
                  animate={active ? { boxShadow: [`0 0 16px ${v.accent}33`, `0 0 28px ${v.accent}66`, `0 0 16px ${v.accent}33`] } : {}}
                  transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                  whileTap={{ scale: locked ? 1 : 0.98 }}
                >
                  {/* Face avatar */}
                  <div className="shrink-0 relative" style={{ width: 56, height: 56 }}>
                    <div className="w-full h-full rounded-xl overflow-hidden" style={{ border: `2px solid ${active ? v.accent : 'rgba(255,255,255,0.12)'}`, boxShadow: active ? `0 0 12px ${v.accent}88` : 'none' }}>
                      <img src={v.img} alt={v.label} className="w-full h-full object-cover object-top" />
                    </div>
                    {active && (
                      <motion.div
                        className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full flex items-center justify-center text-[8px]"
                        style={{ background: v.accent, boxShadow: `0 0 8px ${v.accent}` }}
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 1.2, repeat: Infinity }}
                      >✓</motion.div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold leading-tight" style={{ color: active ? '#fff' : '#d1d5db' }}>{v.label}</p>
                    <p className="text-[10px] mt-0.5" style={{ color: active ? v.accent : 'rgba(161,161,170,0.6)' }}>{v.desc}</p>
                  </div>

                  {locked ? (
                    <div className="flex items-center gap-1.5 shrink-0">
                      <Lock className="w-3.5 h-3.5" style={{ color: '#C400FF' }} />
                      <span className="text-[10px] font-bold" style={{ color: '#C400FF' }}>Premium</span>
                    </div>
                  ) : (
                    <button
                      onClick={(e) => handlePreview(v, e)}
                      className="flex items-center justify-center w-10 h-10 rounded-xl shrink-0 font-bold text-base"
                      style={{
                        background: isPlaying ? `${v.accent}44` : 'rgba(196,0,255,0.18)',
                        border: isPlaying ? `1.5px solid ${v.accent}` : '1.5px solid rgba(196,0,255,0.45)',
                        color: isPlaying ? v.accent : '#D9A6FF',
                        boxShadow: isPlaying ? `0 0 12px ${v.accent}88` : 'none',
                      }}
                    >
                      {isPlaying ? '🔊' : '▶️'}
                    </button>
                  )}
                </motion.button>
                );
            })}
            {!isPremium && (
              <div className="rounded-2xl px-4 py-3 text-center" style={{ background: 'rgba(196,0,255,0.08)', border: '1px solid rgba(196,0,255,0.2)' }}>
                <p className="text-xs italic" style={{ color: '#9B60CC' }}>Unlock all voices with Premium 👑</p>
              </div>
            )}
          </div>
        </div>

        {/* ── MOOD ── */}
        <div>
          <SectionLabel>🎭 Mood & Vibe</SectionLabel>
          <div className="grid grid-cols-2 gap-3 mb-4">
            {MOODS.map((m) => {
              const active = selectedMood === m.id;
              const flashing = flash === m.id;
              return (
                <motion.button
                  key={m.id}
                  onClick={() => handleSelectMood(m)}
                  className="flex flex-col items-center justify-center gap-2 py-8 rounded-2xl relative overflow-hidden"
                  style={{
                    background: active ? `${m.color}22` : 'rgba(255,255,255,0.04)',
                    border: active ? `1.5px solid ${m.color}` : '1px solid rgba(255,255,255,0.08)',
                    boxShadow: active ? `0 0 24px ${m.color}55` : 'none',
                  }}
                  animate={active ? { boxShadow: [`0 0 16px ${m.color}33`, `0 0 32px ${m.color}77`, `0 0 16px ${m.color}33`] } : {}}
                  transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
                  whileTap={{ scale: 0.93 }}
                >
                  <AnimatePresence>
                    {flashing && (
                      <motion.div
                        className="absolute inset-0 rounded-2xl"
                        style={{ background: m.color + '44' }}
                        initial={{ opacity: 0.8 }} animate={{ opacity: 0 }} exit={{ opacity: 0 }}
                        transition={{ duration: 0.5 }}
                      />
                    )}
                  </AnimatePresence>
                  <motion.span
                    className="text-3xl"
                    style={{ filter: active ? `drop-shadow(0 0 10px ${m.color})` : 'none' }}
                    animate={active ? { scale: [1, 1.15, 1] } : {}}
                    transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                  >
                    {m.emoji}
                  </motion.span>
                  <p className="text-sm font-semibold" style={{ color: active ? '#fff' : '#a1a1aa' }}>{m.label}</p>
                </motion.button>
              );
            })}
          </div>
          <AnimatePresence mode="wait">
            {moodLine && (
              <motion.div
                key={moodLine}
                className="rounded-2xl px-4 py-3 text-center"
                style={{ background: 'rgba(196,0,255,0.08)', border: '1px solid rgba(196,0,255,0.2)' }}
                initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -8 }}
                transition={{ duration: 0.3 }}
              >
                <p className="text-xs italic" style={{ color: '#D9A6FF' }}>{moodLine}</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

      </div>
    </div>
  );
}