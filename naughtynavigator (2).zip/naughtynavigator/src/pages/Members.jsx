import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { StackNavigator, useStack } from '../lib/StackNavigator';
import PremiumStatusPage from '../components/navigation/PremiumStatusPage';
import ManageSubscription from './ManageSubscription';
import RestorePurchases from './RestorePurchases';

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

const BENEFITS = [
  { emoji: '💋', label: 'Premium Voice Packs', desc: 'All 5 seductive co-pilots unlocked' },
  { emoji: '🎭', label: 'Mood‑Based Navigation', desc: 'Naughty, Chill, Savage & Romantic routing' },
  { emoji: '💬', label: 'Personality Boosters', desc: 'Extra spicy lines, reactions & commentary' },
  { emoji: '🗺️', label: 'Neon Map Themes', desc: 'Cyber-purple glow on all roads' },
  { emoji: '🚫', label: 'No Ads', desc: 'Just you and your co-pilot. Pure, uninterrupted' },
];

function MembersMain({ onUpgrade }) {
  const { push } = useStack();
  const isPremium = localStorage.getItem('nn_premium') === 'true';

  const ManagePage  = () => <ManageSubscription onBack={() => push(MembersMain)} />;
  const RestorePage = () => <RestorePurchases onBack={() => push(MembersMain)} />;

  return (
    <div className="h-full flex flex-col overflow-hidden" style={PAGE_BG}>
      {/* Ambient glow */}
      <div className="pointer-events-none absolute inset-0 z-0" style={{
        background: 'radial-gradient(ellipse at 50% 10%, rgba(196,0,255,0.22) 0%, transparent 60%)',
      }} />

      {/* Header */}
      <div className="shrink-0 relative z-10 px-6 pt-8 pb-4">
        <h1 className="font-bold" style={{ fontSize: 32, color: '#C400FF', textShadow: '0 0 18px rgba(196,0,255,0.6)', lineHeight: 1.1 }}>
          Members
        </h1>
        <p className="text-xs mt-1" style={{ color: 'rgba(217,166,255,0.5)' }}>
          {isPremium ? 'Your premium membership' : 'Unlock the full experience'}
        </p>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto relative z-10 px-6 pb-12 space-y-6">

        {/* Status Badge Card */}
        <motion.div
          className="flex flex-col items-center text-center rounded-3xl px-6 py-8"
          style={{
            background: isPremium
              ? 'linear-gradient(135deg, rgba(196,0,255,0.18) 0%, rgba(255,0,230,0.08) 100%)'
              : 'rgba(255,255,255,0.05)',
            border: isPremium ? '1.5px solid rgba(196,0,255,0.5)' : '1px solid rgba(196,0,255,0.2)',
            boxShadow: isPremium ? '0 0 40px rgba(196,0,255,0.2)' : 'none',
          }}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          {/* Crown icon */}
          <motion.div className="relative mb-5" style={{ width: 80, height: 80 }}>
            <motion.div
              className="absolute inset-0 rounded-full"
              style={{ background: 'radial-gradient(circle, rgba(196,0,255,0.4) 0%, transparent 70%)' }}
              animate={{ scale: [1, 1.3, 1], opacity: [0.5, 0.9, 0.5] }}
              transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
            />
            <div className="absolute inset-0 rounded-full flex flex-col items-center justify-center"
              style={{ background: 'radial-gradient(circle at 40% 35%, #3D0055 0%, #1A0024 100%)', border: '2px solid rgba(196,0,255,0.6)' }}>
              <span style={{ fontSize: 30, lineHeight: 1, filter: 'drop-shadow(0 0 8px #C400FF)' }}>👑</span>
              <span style={{ fontSize: 16, lineHeight: 1, marginTop: -2, filter: 'drop-shadow(0 0 5px #FF00AA)' }}>💜</span>
            </div>
          </motion.div>

          <h2 className="font-bold mb-2" style={{ fontSize: 22, color: '#FFFFFF', textShadow: isPremium ? '0 0 14px rgba(196,0,255,0.7)' : 'none' }}>
            {isPremium ? 'You are Premium ✨' : 'Upgrade to Premium'}
          </h2>
          <p className="text-sm leading-relaxed" style={{ color: 'rgba(217,166,255,0.65)', maxWidth: 240 }}>
            {isPremium ? 'Full access to all voices, moods & neon themes.' : 'Unlock all voices, moods, and neon themes.'}
          </p>

          {isPremium && (
            <motion.div
              className="mt-4 px-4 py-1.5 rounded-full text-xs font-bold"
              style={{ background: 'rgba(196,0,255,0.2)', border: '1px solid rgba(196,0,255,0.5)', color: '#C400FF' }}
              animate={{ boxShadow: ['0 0 8px rgba(196,0,255,0.4)', '0 0 20px rgba(196,0,255,0.8)', '0 0 8px rgba(196,0,255,0.4)'] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            >
              Active Member 👑
            </motion.div>
          )}
        </motion.div>

        {/* Action Buttons */}
        {isPremium ? (
          <div className="space-y-3">
            <motion.button
              onClick={() => push(ManagePage)}
              className="w-full h-14 rounded-3xl font-bold text-white text-base flex items-center justify-center gap-2"
              style={{ background: 'linear-gradient(135deg, #C400FF, #FF00E6)' }}
              animate={{ boxShadow: ['0 0 20px rgba(196,0,255,0.5)', '0 0 40px rgba(196,0,255,0.9)', '0 0 20px rgba(196,0,255,0.5)'] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              whileTap={{ scale: 0.97 }}
            >
              ⚙️ Manage Subscription
            </motion.button>
            <motion.button
              onClick={() => push(RestorePage)}
              className="w-full h-12 rounded-2xl text-sm font-semibold flex items-center justify-center gap-2"
              style={{
                background: 'rgba(255,255,255,0.06)',
                border: '1px solid rgba(196,0,255,0.3)',
                color: '#D9A6FF',
              }}
              whileTap={{ scale: 0.98 }}
            >
              🔄 Restore Purchases
            </motion.button>
          </div>
        ) : (
          <div className="space-y-3">
            <motion.button
              onClick={onUpgrade}
              className="w-full h-14 rounded-3xl font-bold text-white text-base flex items-center justify-center gap-2"
              style={{ background: 'linear-gradient(135deg, #C400FF, #FF00E6)' }}
              animate={{ boxShadow: ['0 0 20px rgba(196,0,255,0.5)', '0 0 44px rgba(196,0,255,1)', '0 0 20px rgba(196,0,255,0.5)'] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              whileTap={{ scale: 0.97 }}
            >
              ✨ Unlock Premium — $9.99
            </motion.button>
            <motion.button
              onClick={() => push(RestorePage)}
              className="w-full h-12 rounded-2xl text-sm font-semibold flex items-center justify-center gap-2"
              style={{
                background: 'rgba(255,255,255,0.05)',
                border: '1px solid rgba(196,0,255,0.2)',
                color: 'rgba(217,166,255,0.6)',
              }}
              whileTap={{ scale: 0.98 }}
            >
              🔄 Restore Purchases
            </motion.button>
          </div>
        )}

        {/* Benefits list */}
        <div className="space-y-3">
          <p className="text-[10px] font-bold uppercase tracking-widest px-1" style={{ color: 'rgba(196,0,255,0.55)' }}>
            ✦ What's Included
          </p>
          {BENEFITS.map(({ emoji, label, desc }, i) => (
            <motion.div
              key={label}
              className="flex items-center gap-4 rounded-2xl px-4 py-4"
              style={{
                background: 'rgba(255,255,255,0.04)',
                border: '1px solid rgba(196,0,255,0.15)',
              }}
              initial={{ opacity: 0, x: -14 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.1 + i * 0.06 }}
            >
              <span style={{ fontSize: 24, flexShrink: 0, filter: 'drop-shadow(0 0 6px #C400FF)' }}>{emoji}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold" style={{ color: '#EDD9FF' }}>{label}</p>
                <p className="text-[11px] mt-0.5" style={{ color: 'rgba(217,166,255,0.45)' }}>{desc}</p>
              </div>
              {isPremium && <span className="text-green-400 text-sm shrink-0">✓</span>}
            </motion.div>
          ))}
        </div>

        {/* Pricing Options (non-premium only) */}
        {!isPremium && (
          <motion.div className="space-y-3" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.4 }}>
            <p className="text-[10px] font-bold uppercase tracking-widest px-1" style={{ color: 'rgba(196,0,255,0.55)' }}>
              ✦ Pricing Options
            </p>
            <div className="rounded-2xl p-4 space-y-2.5" style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(196,0,255,0.15)' }}>
              {[
                { label: '14-Day Trial', price: '$4.99', color: '#FF6EB3' },
                { label: 'Monthly Plan', price: '$9.99/mo', color: '#FF6EB3' },
                { label: 'Monthly Plus', price: '$14.99/mo', color: '#FF6EB3' },
                { label: '✔ Yearly Plan', price: '$29.99/yr', color: '#FFD700', gold: true },
              ].map(({ label, price, color, gold }, i, arr) => (
                <React.Fragment key={label}>
                  <div className="flex items-center justify-between">
                    <span style={{ fontSize: 13, color: gold ? '#FFD700' : '#D9A6FF', fontWeight: gold ? 600 : 400 }}>{label}</span>
                    <span style={{ fontSize: 14, fontWeight: 700, color }}>{price}</span>
                  </div>
                  {i < arr.length - 1 && <div style={{ height: 1, background: 'rgba(196,0,255,0.1)' }} />}
                </React.Fragment>
              ))}
              <p style={{ fontSize: 10, color: 'rgba(255,215,0,0.7)', textAlign: 'center', marginTop: 6, fontStyle: 'italic' }}>
                best value — save 50%
              </p>
            </div>
          </motion.div>
        )}

      </div>
    </div>
  );
}

export default function Members({ onUpgrade }) {
  return <StackNavigator initialScreen={() => <MembersMain onUpgrade={onUpgrade} />} />;
}