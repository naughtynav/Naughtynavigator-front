import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Lock } from 'lucide-react';
import { useStack } from '../../lib/StackNavigator';
import { speakComment } from '../../components/navigation/SeductiveComments';
import { playTapSound } from '../../lib/soundEffects';

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

const VOICES = [
  { id: 'velvet',   emoji: '🌹', label: 'Velvet Seductress', accent: '#FF00E6' },
  { id: 'bosslady', emoji: '👠', label: 'Boss Lady',          accent: '#C400FF' },
  { id: 'princess', emoji: '🎀', label: 'Playful Princess',   accent: '#FF6EB3' },
  { id: 'softie',   emoji: '🌸', label: 'Sweetheart Softie',  accent: '#D9A6FF' },
  { id: 'mischief', emoji: '😈', label: 'Mischief Mode',      accent: '#FF4DFF' },
];

const VOICE_PREVIEWS = {
  velvet:   "Mmm… close your eyes for just a second. Breathe. Now follow my voice, gorgeous.",
  bosslady: "Alright, listen up. Route calculated. I'm in charge now — keep up.",
  princess: "Omg we're going on a TRIP?! I'm SO ready, let's GOOO! 🎀",
  softie:   "Hey, I'm so glad you're here. Let's find our way together, nice and easy.",
  mischief: "Navigation activated. Chaos level: moderate. Let's seeeee where this goes!",
};

export default function VoiceSettingsPage() {
  const { pop } = useStack();
  const [selected, setSelected] = useState(() => localStorage.getItem('nn_voice') || 'velvet');
  const [previewing, setPreviewing] = useState(null);
  const isPremium = localStorage.getItem('nn_premium') === 'true';

  const handleSelect = (v) => {
    if (!isPremium && v.id !== 'velvet') return;
    playTapSound();
    setSelected(v.id);
    localStorage.setItem('nn_voice', v.id);
  };

  const handlePreview = (v, e) => {
    e.stopPropagation();
    if (!isPremium && v.id !== 'velvet') return;
    playTapSound();
    setPreviewing(v.id);
    speakComment(VOICE_PREVIEWS[v.id], v.id);
    setTimeout(() => setPreviewing(null), 2500);
  };

  return (
    <div className="h-full flex flex-col" style={PAGE_BG}>
      {/* Header */}
      <div className="shrink-0 flex items-center gap-3 px-6 py-4" style={{ borderBottom: '1px solid rgba(196,0,255,0.15)' }}>
        <button
          onClick={pop}
          className="h-9 w-9 rounded-2xl flex items-center justify-center text-lg font-bold"
          style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
        >
          ‹
        </button>
        <div>
          <h1 className="text-base font-bold" style={{ color: '#E8CCFF' }}>Voice Selection</h1>
          <p className="text-[11px]" style={{ color: 'rgba(217,166,255,0.45)' }}>Choose your co-pilot's personality</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-3">
        <p className="text-xs text-zinc-500 mb-4">Tap a voice to select it. Tap Preview to hear a sample.</p>

        {VOICES.map((v) => {
          const active = selected === v.id;
          const locked = !isPremium && v.id !== 'velvet';
          const isPlaying = previewing === v.id;
          return (
            <motion.button
              key={v.id}
              onClick={() => handleSelect(v)}
              className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-left transition-all relative overflow-hidden"
              style={{
                background: active ? `${v.accent}18` : 'rgba(255,255,255,0.04)',
                border: active ? `1.5px solid ${v.accent}` : '1px solid rgba(255,255,255,0.08)',
                boxShadow: active ? `0 0 20px ${v.accent}44` : 'none',
                opacity: locked ? 0.6 : 1,
              }}
              animate={active ? { boxShadow: [`0 0 16px ${v.accent}33`, `0 0 28px ${v.accent}66`, `0 0 16px ${v.accent}33`] } : {}}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              whileTap={{ scale: locked ? 1 : 0.98 }}
            >
              <motion.span
                className="text-2xl"
                animate={isPlaying ? { scale: [1, 1.25, 1], rotate: [-5, 5, -5, 0] } : {}}
                transition={{ duration: 0.4, repeat: isPlaying ? Infinity : 0 }}
              >
                {v.emoji}
              </motion.span>
              <p className="flex-1 text-sm font-semibold" style={{ color: active ? '#fff' : '#a1a1aa' }}>{v.label}</p>
              {locked ? (
                <div className="flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5" style={{ color: '#C400FF' }} />
                  <span className="text-[10px] font-bold" style={{ color: '#C400FF' }}>Premium</span>
                </div>
              ) : (
                <button
                  onClick={(e) => handlePreview(v, e)}
                  className="text-[10px] font-semibold px-2.5 py-1 rounded-lg shrink-0 transition-all"
                  style={{
                    background: isPlaying ? `${v.accent}33` : 'rgba(255,255,255,0.08)',
                    color: isPlaying ? v.accent : '#71717a',
                    border: isPlaying ? `1px solid ${v.accent}55` : '1px solid transparent',
                  }}
                >
                  {isPlaying ? '🔊 Playing…' : '▶ Preview'}
                </button>
              )}
              {active && !locked && (
                <span className="text-xs font-bold px-2 py-0.5 rounded-full ml-1 shrink-0" style={{ background: v.accent + '33', color: v.accent }}>
                  ✓
                </span>
              )}
            </motion.button>
          );
        })}

        {!isPremium && (
          <div className="rounded-2xl px-4 py-3 text-center mt-2" style={{ background: 'rgba(196,0,255,0.08)', border: '1px solid rgba(196,0,255,0.2)' }}>
            <p className="text-xs italic" style={{ color: '#9B60CC' }}>Unlock all voices with Premium 👑</p>
          </div>
        )}
      </div>
    </div>
  );
}