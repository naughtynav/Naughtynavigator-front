import React from 'react';
import { useStack } from '../../lib/StackNavigator';
import PremiumStatusPage from '../../components/navigation/PremiumStatusPage';

export default function PremiumSettingsPage() {
  const { pop } = useStack();
  return <PremiumStatusPage onBack={pop} onUpgrade={pop} />;
}