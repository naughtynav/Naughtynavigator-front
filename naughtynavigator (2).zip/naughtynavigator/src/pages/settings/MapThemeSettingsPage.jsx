import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Lock } from 'lucide-react';
import { useStack } from '../../lib/StackNavigator';
import { playTapSound } from '../../lib/soundEffects';

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

const MAP_THEMES = [
  { id: 'neon',     emoji: '🟣', label: 'Neon Purple', desc: 'Cyber-seductive glow',  accent: '#C400FF', premium: true },
  { id: 'dark',     emoji: '⚫', label: 'Dark Mode',   desc: 'Sleek and minimal',      accent: '#71717a', premium: false },
  { id: 'standard', emoji: '🗺️', label: 'Standard',   desc: 'Classic map look',       accent: '#D9A6FF', premium: false },
];

function MapPreview({ themeId }) {
  const isNeon = themeId === 'neon';
  const isDark = themeId === 'dark';
  const roadColor = isNeon ? '#D9A6FF' : isDark ? '#555' : '#94a3b8';
  const routeColor = isNeon ? '#FF4DFF' : isDark ? '#ec4899' : '#f472b6';
  const bgColor = isNeon ? '#0D0015' : isDark ? '#1c1c1e' : '#e8e8e0';
  const glow = isNeon ? 'drop-shadow(0 0 5px #FF4DFF)' : 'none';

  return (
    <div className="rounded-xl overflow-hidden mb-5" style={{
      border: isNeon ? '1px solid rgba(196,0,255,0.4)' : '1px solid rgba(255,255,255,0.08)',
      boxShadow: isNeon ? '0 0 20px rgba(196,0,255,0.2)' : 'none',
    }}>
      <svg width="100%" viewBox="0 0 280 100" style={{ background: bgColor, display: 'block' }}>
        <line x1="0" y1="50" x2="280" y2="50" stroke={roadColor} strokeWidth="2" />
        <line x1="140" y1="0" x2="140" y2="100" stroke={roadColor} strokeWidth="1.5" />
        <polyline points="20,80 70,55 130,50 180,40 260,20" fill="none" stroke={routeColor} strokeWidth="3" strokeLinecap="round" style={{ filter: glow }} />
        {isNeon && <>
          <circle cx="70" cy="55" r="4" fill="#FF4DFF" style={{ filter: 'drop-shadow(0 0 4px #FF4DFF)' }} />
          <circle cx="180" cy="40" r="4" fill="#FF4DFF" style={{ filter: 'drop-shadow(0 0 4px #FF4DFF)' }} />
        </>}
        <circle cx="260" cy="20" r="5" fill={routeColor} style={{ filter: glow }} />
      </svg>
    </div>
  );
}

export default function MapThemeSettingsPage() {
  const { pop } = useStack();
  const [selected, setSelected] = useState(() => localStorage.getItem('nn_map_theme') || 'neon');
  const isPremium = localStorage.getItem('nn_premium') === 'true';

  const handleSelect = (t) => {
    if (t.premium && !isPremium) return;
    playTapSound();
    setSelected(t.id);
    localStorage.setItem('nn_map_theme', t.id);
  };

  return (
    <div className="h-full flex flex-col" style={PAGE_BG}>
      {/* Header */}
      <div className="shrink-0 flex items-center gap-3 px-6 py-4" style={{ borderBottom: '1px solid rgba(196,0,255,0.15)' }}>
        <button
          onClick={pop}
          className="h-9 w-9 rounded-2xl flex items-center justify-center text-lg font-bold"
          style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
        >
          ‹
        </button>
        <div>
          <h1 className="text-base font-bold" style={{ color: '#E8CCFF' }}>Map Theme</h1>
          <p className="text-[11px]" style={{ color: 'rgba(217,166,255,0.45)' }}>Pick the vibe for your map</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6 space-y-3">
        <MapPreview themeId={selected} />

        {MAP_THEMES.map((t) => {
          const active = selected === t.id;
          const locked = t.premium && !isPremium;
          return (
            <motion.button
              key={t.id}
              onClick={() => handleSelect(t)}
              className="w-full flex items-center gap-4 px-4 py-4 rounded-2xl text-left transition-all"
              style={{
                background: active ? `${t.accent}18` : 'rgba(255,255,255,0.04)',
                border: active ? `1.5px solid ${t.accent}` : '1px solid rgba(255,255,255,0.08)',
                boxShadow: active ? `0 0 16px ${t.accent}33` : 'none',
                opacity: locked ? 0.65 : 1,
              }}
              animate={active ? { boxShadow: [`0 0 12px ${t.accent}22`, `0 0 24px ${t.accent}55`, `0 0 12px ${t.accent}22`] } : {}}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              whileTap={{ scale: locked ? 1 : 0.98 }}
            >
              <span className="text-2xl">{t.emoji}</span>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold" style={{ color: active ? '#fff' : '#a1a1aa' }}>{t.label}</p>
                <p className="text-[11px] text-zinc-600 mt-0.5">{t.desc}</p>
              </div>
              {locked && (
                <div className="flex items-center gap-1 shrink-0">
                  <Lock className="w-3.5 h-3.5" style={{ color: '#C400FF' }} />
                  <span className="text-[10px] font-bold" style={{ color: '#C400FF' }}>Premium</span>
                </div>
              )}
              {active && !locked && (
                <span className="text-xs font-bold px-2 py-0.5 rounded-full shrink-0" style={{ background: t.accent + '33', color: t.accent }}>
                  Active
                </span>
              )}
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}