import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useStack } from '../../lib/StackNavigator';
import { playTapSound } from '../../lib/soundEffects';

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

const MOODS = [
  { id: 'naughty',  emoji: '😈', label: 'Naughty',  color: '#FF4DFF' },
  { id: 'chill',    emoji: '😌', label: 'Chill',    color: '#D9A6FF' },
  { id: 'savage',   emoji: '🔥', label: 'Savage',   color: '#FF2222' },
  { id: 'romantic', emoji: '💖', label: 'Romantic', color: '#FF6EB3' },
];

const MOOD_PERSONALITY_LINES = {
  naughty:  "Oh, we're going naughty today? I thought you'd never ask. 😈",
  chill:    "Easy, breezy, beautiful… no rush. Just vibes. 😌",
  savage:   "Savage mode activated. I'll match your energy. Let's GO. 🔥",
  romantic: "Someone's got plans tonight… I'll make every mile feel special. 💖",
};

export default function MoodSettingsPage() {
  const { pop } = useStack();
  const [selected, setSelected] = useState(() => localStorage.getItem('nn_mood') || 'naughty');
  const [flash, setFlash] = useState(null);
  const [personalityLine, setPersonalityLine] = useState('');

  const handleSelect = (m) => {
    playTapSound();
    setSelected(m.id);
    localStorage.setItem('nn_mood', m.id);
    setPersonalityLine(MOOD_PERSONALITY_LINES[m.id] || '');
    setFlash(m.id);
    setTimeout(() => setFlash(null), 600);
  };

  return (
    <div className="h-full flex flex-col" style={PAGE_BG}>
      {/* Header */}
      <div className="shrink-0 flex items-center gap-3 px-6 py-4" style={{ borderBottom: '1px solid rgba(196,0,255,0.15)' }}>
        <button
          onClick={pop}
          className="h-9 w-9 rounded-2xl flex items-center justify-center text-lg font-bold"
          style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
        >
          ‹
        </button>
        <div>
          <h1 className="text-base font-bold" style={{ color: '#E8CCFF' }}>Mood & Vibe</h1>
          <p className="text-[11px]" style={{ color: 'rgba(217,166,255,0.45)' }}>How are we riding today?</p>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto px-4 py-6">
        <div className="grid grid-cols-2 gap-3 mb-5">
          {MOODS.map((m) => {
            const active = selected === m.id;
            const flashing = flash === m.id;
            return (
              <motion.button
                key={m.id}
                onClick={() => handleSelect(m)}
                className="flex flex-col items-center justify-center gap-2 py-8 rounded-2xl transition-all relative overflow-hidden"
                style={{
                  background: active ? `${m.color}22` : 'rgba(255,255,255,0.04)',
                  border: active ? `1.5px solid ${m.color}` : '1px solid rgba(255,255,255,0.08)',
                  boxShadow: active ? `0 0 24px ${m.color}55` : 'none',
                }}
                animate={active ? { boxShadow: [`0 0 16px ${m.color}33`, `0 0 32px ${m.color}77`, `0 0 16px ${m.color}33`] } : {}}
                transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
                whileTap={{ scale: 0.93 }}
              >
                <AnimatePresence>
                  {flashing && (
                    <motion.div
                      className="absolute inset-0 rounded-2xl"
                      style={{ background: m.color + '44' }}
                      initial={{ opacity: 0.8 }}
                      animate={{ opacity: 0 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.5 }}
                    />
                  )}
                </AnimatePresence>
                <motion.span
                  className="text-3xl"
                  style={{ filter: active ? `drop-shadow(0 0 10px ${m.color})` : 'none' }}
                  animate={active ? { scale: [1, 1.15, 1] } : {}}
                  transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                >
                  {m.emoji}
                </motion.span>
                <p className="text-sm font-semibold" style={{ color: active ? '#fff' : '#a1a1aa' }}>{m.label}</p>
              </motion.button>
            );
          })}
        </div>

        <AnimatePresence mode="wait">
          {personalityLine && (
            <motion.div
              key={personalityLine}
              className="rounded-2xl px-4 py-3 text-center"
              style={{ background: 'rgba(196,0,255,0.08)', border: '1px solid rgba(196,0,255,0.2)' }}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3 }}
            >
              <p className="text-xs italic" style={{ color: '#D9A6FF' }}>{personalityLine}</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}