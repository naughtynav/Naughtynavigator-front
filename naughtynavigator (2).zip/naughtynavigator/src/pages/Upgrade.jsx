import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Lock, Check, AlertCircle } from 'lucide-react';
import { loadStripe } from '@stripe/stripe-js';
import { base44 } from '@/api/base44Client';
import PremiumOnboarding from '../components/navigation/PremiumOnboarding';
import PaywallAnimation from '../components/navigation/PaywallAnimation';

let stripePromise;
const getStripe = (publishableKey) => {
  if (!stripePromise) stripePromise = loadStripe(publishableKey);
  return stripePromise;
};

const PLANS = [
  { id: 'monthly',  label: 'Monthly Plan',      price: '$9.99',  period: '/ month', subtext: 'Billed Monthly',            glowColor: '#C400FF' },
  { id: 'monthly_plus', label: 'Monthly Plus',  price: '$14.99', period: '/ month', subtext: 'Themes & Features Included', glowColor: '#FF6EB3', tagRight: '🎨 All Themes' },
  { id: 'yearly',   label: 'Yearly Plan',        price: '$29.99', period: '/ year',  subtext: 'Themes & Features Included', glowColor: '#FF6EB3', tagLeft: 'Save 50%', tagRight: 'Best Deal!' },
  { id: 'onetime',  label: '14-Day Trial',       price: '$4.99',  period: '',        subtext: 'Themes & Features Included', glowColor: '#C400FF' },
];

const FEATURES_BASIC = [
  'All Map Themes',
  'Early Access to New Content',
  'Ad-Free Navigation',
  'Premium Navigation Styles',
];

const FEATURES_PLUS = [
  'Unlimited Voice Packs',
  'Early Access to New Content',
  'Ad-Free Navigation',
  'Premium Navigation Styles',
];

const FEATURES_TRIAL = [
  'Unlimited Voice Packs',
  'All Map Themes',
  'Early Access to New Content',
  'Ad-Free Navigation',
  'Premium Navigation Styles',
];

const FEATURES = FEATURES_PLUS;

export default function Upgrade({ onClose }) {
  const [selectedPlan, setSelectedPlan] = useState('yearly');
  const [animating, setAnimating]       = useState(false);
  const [purchased, setPurchased]       = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError]               = useState(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    if (params.get('success')) {
      setAnimating(true);
      setTimeout(() => setPurchased(true), 800);
    }
  }, []);

  const handleCheckout = async () => {
    const { playUnlockSound } = await import('../lib/soundEffects');
    playUnlockSound();
    setIsProcessing(true);
    setError(null);
    try {
      const res = await base44.functions.invoke('stripeCheckout', {});
      const { sessionId, publishableKey } = res.data;
      const stripe = await getStripe(publishableKey);
      await stripe.redirectToCheckout({ sessionId });
    } catch {
      setError('Failed to start checkout. Please try again.');
      setIsProcessing(false);
    }
  };

  if (animating) return <PaywallAnimation onComplete={() => { setAnimating(false); setPurchased(true); }} />;
  if (purchased) return <PremiumOnboarding onDone={() => onClose?.()} />;

  return (
    <div
      className="relative flex flex-col h-full overflow-y-auto"
      style={{ background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' }}
    >
      {/* Ambient glow */}
      <div className="fixed inset-0 pointer-events-none z-0" style={{
        background: 'radial-gradient(ellipse at 50% 20%, rgba(196,0,255,0.25) 0%, transparent 60%)',
      }} />

      <div className="relative z-10 flex flex-col w-full px-6 py-8 pb-16">

        {/* ── HEADER ── */}
        <motion.div className="text-center mb-12" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <motion.div className="flex justify-center mb-6" animate={{ y: [0, -8, 0] }} transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}>
            <span style={{ fontSize: 52, filter: 'drop-shadow(0 0 20px rgba(255,110,179,0.9)) drop-shadow(0 0 40px rgba(196,0,255,0.6))' }}>📍💋</span>
          </motion.div>
          <h1 style={{
            fontSize: 34, fontWeight: 800, lineHeight: 1.2, marginBottom: 12,
            background: 'linear-gradient(135deg, #FF6EB3 0%, #C400FF 100%)',
            backgroundClip: 'text', WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent',
          }}>
            Naughty Navigator Premium
          </h1>
          <p style={{ fontSize: 15, color: 'rgba(217,166,255,0.85)', lineHeight: 1.7, maxWidth: 320, margin: '0 auto' }}>
            Unlock all premium voices, moods, themes, and exclusive content.
          </p>
        </motion.div>

        {/* ── CHOOSE YOUR PLAN ── */}
        <motion.div className="mb-12" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.2 }}>
          <h2 style={{ fontSize: 20, fontWeight: 700, color: '#FFFFFF', textAlign: 'center', marginBottom: 20 }}>
            Choose Your Plan
          </h2>

          <div className="space-y-3">
            {PLANS.map((plan, i) => {
              const isSelected = selectedPlan === plan.id;
              return (
                <motion.button
                  key={plan.id}
                  onClick={() => setSelectedPlan(plan.id)}
                  className="w-full relative"
                  initial={{ opacity: 0, y: 16 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.4, delay: 0.25 + i * 0.1 }}
                >
                  {plan.tagLeft && (
                    <div className="absolute top-4 left-4 z-20">
                      <span style={{ fontSize: 11, fontWeight: 700, color: '#FF6EB3', background: 'rgba(255,110,179,0.18)', border: '1px solid rgba(255,110,179,0.45)', padding: '4px 10px', borderRadius: 14 }}>
                        {plan.tagLeft}
                      </span>
                    </div>
                  )}
                  {plan.tagRight && (
                    <motion.div className="absolute top-4 right-4 z-20" animate={{ scale: [1, 1.08, 1] }} transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}>
                      <span style={{ fontSize: 11, fontWeight: 700, color: '#FFD700', background: 'rgba(255,215,0,0.18)', border: '1px solid rgba(255,215,0,0.45)', padding: '4px 10px', borderRadius: 14 }}>
                        ⭐ {plan.tagRight}
                      </span>
                    </motion.div>
                  )}

                  <motion.div
                    className="rounded-3xl p-6 relative overflow-hidden"
                    style={{
                      background: isSelected ? `linear-gradient(135deg, ${plan.glowColor}22 0%, ${plan.glowColor}08 100%)` : 'rgba(255,255,255,0.04)',
                      border: isSelected ? `2px solid ${plan.glowColor}` : '1px solid rgba(196,0,255,0.15)',
                    }}
                    animate={isSelected ? {
                      boxShadow: [
                        `0 0 20px ${plan.glowColor}33, inset 0 0 20px ${plan.glowColor}11`,
                        `0 0 36px ${plan.glowColor}66, inset 0 0 36px ${plan.glowColor}22`,
                        `0 0 20px ${plan.glowColor}33, inset 0 0 20px ${plan.glowColor}11`,
                      ],
                    } : { boxShadow: 'none' }}
                    transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                  >
                    <div className="flex items-center gap-5">
                      {/* Radio */}
                      <div style={{
                        width: 28, height: 28, borderRadius: '50%', flexShrink: 0,
                        border: isSelected ? `3px solid ${plan.glowColor}` : '2px solid rgba(196,0,255,0.4)',
                        background: isSelected ? plan.glowColor : 'transparent',
                        display: 'flex', alignItems: 'center', justifyContent: 'center',
                        boxShadow: isSelected ? `0 0 14px ${plan.glowColor}` : 'none',
                      }}>
                        {isSelected && <div style={{ width: 10, height: 10, borderRadius: '50%', background: '#fff' }} />}
                      </div>

                      {/* Info */}
                      <div className="flex-1 text-left">
                        <p style={{ fontSize: 16, fontWeight: 700, color: '#FFFFFF', marginBottom: 3 }}>{plan.label}</p>
                        <p style={{ fontSize: 12, color: 'rgba(217,166,255,0.6)' }}>{plan.subtext}</p>
                      </div>

                      {/* Price */}
                      <div className="text-right shrink-0">
                        <motion.p
                          style={{ fontSize: 24, fontWeight: 800, color: isSelected ? plan.glowColor : '#D9A6FF' }}
                          animate={isSelected ? { textShadow: [`0 0 0px ${plan.glowColor}00`, `0 0 14px ${plan.glowColor}99`, `0 0 0px ${plan.glowColor}00`] } : {}}
                          transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                        >
                          {plan.price}
                        </motion.p>
                        {plan.period && <p style={{ fontSize: 11, color: 'rgba(217,166,255,0.5)', marginTop: 2 }}>{plan.period}</p>}
                      </div>
                    </div>
                  </motion.div>
                </motion.button>
              );
            })}
          </div>
        </motion.div>

        {/* ── WHAT YOU GET ── */}
        <motion.div className="mb-12" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.4 }}>
          <h3 style={{ fontSize: 18, fontWeight: 700, color: '#FFFFFF', marginBottom: 14 }}>Included With Premium</h3>
          {selectedPlan === 'onetime' && (
            <div className="mb-4 px-4 py-3 rounded-2xl" style={{ background: 'rgba(255,165,0,0.1)', border: '1px solid rgba(255,165,0,0.4)' }}>
              <p className="text-xs font-semibold" style={{ color: '#FFA500' }}>⚠️ 14-Day Access Only</p>
              <p className="text-xs mt-1" style={{ color: 'rgba(255,165,0,0.75)' }}>This plan provides access to premium features for 14 days only. After 14 days, access will expire and you will need to subscribe to continue.</p>
            </div>
          )}
          <div className="space-y-3">
            {(selectedPlan === 'monthly' ? FEATURES_BASIC : selectedPlan === 'onetime' ? FEATURES_TRIAL : FEATURES_PLUS).map((feature, i) => (
              <motion.div key={feature} className="flex items-center gap-3.5"
                initial={{ opacity: 0, x: -16 }} animate={{ opacity: 1, x: 0 }} transition={{ duration: 0.4, delay: 0.5 + i * 0.08 }}>
                <motion.div
                  animate={{ boxShadow: ['0 0 8px rgba(255,110,179,0)', '0 0 14px rgba(255,110,179,0.9)', '0 0 8px rgba(255,110,179,0)'] }}
                  transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
                  style={{ width: 24, height: 24, borderRadius: '50%', background: 'linear-gradient(135deg, #FF6EB3, #FF4DFF)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}
                >
                  <Check className="w-4 h-4" style={{ color: '#fff' }} />
                </motion.div>
                <span style={{ fontSize: 15, color: '#D9A6FF', fontWeight: 500 }}>{feature}</span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* ── PAYMENT SECTION ── */}
        <motion.div className="space-y-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.5, delay: 0.65 }}>
          {error && (
            <div className="flex items-start gap-3 p-4 rounded-2xl bg-red-500/10 border border-red-500/30">
              <AlertCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
              <p className="text-sm text-red-300">{error}</p>
            </div>
          )}

          <motion.button
            onClick={handleCheckout}
            disabled={isProcessing}
            className="w-full h-16 rounded-3xl font-bold text-white text-lg tracking-wide flex items-center justify-center gap-3 disabled:opacity-50 disabled:cursor-not-allowed"
            style={{ background: 'linear-gradient(135deg, #C400FF, #FF00E6)' }}
            animate={{ boxShadow: ['0 0 24px rgba(196,0,255,0.6)', '0 0 48px rgba(196,0,255,1)', '0 0 24px rgba(196,0,255,0.6)'] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            whileTap={{ scale: 0.96 }}
          >
            {isProcessing ? (
              <><motion.span animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>⏳</motion.span> Processing...</>
            ) : (
              <><Lock className="w-5 h-5" /> Continue to Payment</>
            )}
          </motion.button>

          <p style={{ fontSize: 13, color: '#FFFFFF', textAlign: 'center', fontWeight: 500 }}>Secure Checkout</p>

          <div className="flex items-center justify-center gap-6">
            <span style={{ fontSize: 24 }}>💳</span>
            <span style={{ fontSize: 24 }}>💰</span>
            <span style={{ fontSize: 24 }}>🍎</span>
          </div>
        </motion.div>

        {/* ── FOOTER ── */}
        <div className="text-center space-y-1.5 mt-10 pt-8" style={{ borderTop: '1px solid rgba(196,0,255,0.15)' }}>
          <p style={{ fontSize: 13, color: '#FFFFFF', fontWeight: 600 }}>100% Secure Checkout</p>
          <p style={{ fontSize: 12, color: 'rgba(217,166,255,0.7)' }}>Powered by Stripe</p>
        </div>

      </div>
    </div>
  );
}