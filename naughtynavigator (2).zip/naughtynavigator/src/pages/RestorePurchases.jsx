import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

export default function RestorePurchases({ onBack }) {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState(null); // null | 'loading' | 'success' | 'not_found' | 'error'
  const [message, setMessage] = useState('');

  const handleRestore = async (e) => {
    e.preventDefault();
    if (!email.trim()) return;
    setStatus('loading');

    try {
      const user = await base44.auth.me();
      const isPremium = localStorage.getItem('nn_premium') === 'true';

      // Check if the entered email matches the logged-in user and they have premium
      if (user && user.email === email.trim() && (isPremium || user.role === 'admin')) {
        localStorage.setItem('nn_premium', 'true');
        setStatus('success');
        setMessage('Your purchase has been restored! Welcome back.');
      } else if (user && user.email === email.trim()) {
        setStatus('not_found');
        setMessage('No active subscription found for this email. Please contact support if you believe this is an error.');
      } else {
        setStatus('not_found');
        setMessage('No active subscription found for this email. Please contact support if you believe this is an error.');
      }
    } catch {
      setStatus('error');
      setMessage('Something went wrong. Please try again or contact support.');
    }
  };

  return (
    <div className="h-full flex flex-col overflow-hidden" style={PAGE_BG}>
      {/* Ambient glow */}
      <div className="pointer-events-none absolute inset-0 z-0" style={{
        background: 'radial-gradient(ellipse at 50% 10%, rgba(196,0,255,0.22) 0%, transparent 60%)',
      }} />

      {/* Header */}
      <div className="shrink-0 relative z-10 flex items-center gap-3 px-6 py-4" style={{ borderBottom: '1px solid rgba(196,0,255,0.15)' }}>
        <button
          onClick={onBack}
          className="h-9 w-9 rounded-2xl flex items-center justify-center text-lg font-bold transition-all"
          style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
        >
          ‹
        </button>
        <h1 className="font-bold" style={{ fontSize: 22, color: '#C400FF', textShadow: '0 0 14px rgba(196,0,255,0.7)' }}>
          Restore Purchases
        </h1>
      </div>

      {/* Content */}
      <div className="flex-1 overflow-y-auto relative z-10 px-6 py-8 space-y-6">

        {/* Icon */}
        <motion.div
          className="flex flex-col items-center text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4 }}
        >
          <motion.div
            className="mb-5 flex items-center justify-center rounded-full"
            style={{ width: 80, height: 80, background: 'radial-gradient(circle at 40% 35%, #3D0055 0%, #1A0024 100%)', border: '2px solid rgba(196,0,255,0.6)' }}
            animate={{ boxShadow: ['0 0 16px rgba(196,0,255,0.4)', '0 0 36px rgba(196,0,255,0.8)', '0 0 16px rgba(196,0,255,0.4)'] }}
            transition={{ duration: 2.4, repeat: Infinity, ease: 'easeInOut' }}
          >
            <span style={{ fontSize: 36, filter: 'drop-shadow(0 0 8px #C400FF)' }}>🔄</span>
          </motion.div>
          <h2 className="font-bold mb-2" style={{ fontSize: 20, color: '#FFFFFF' }}>
            Restore Your Premium Access
          </h2>
          <p className="text-sm leading-relaxed" style={{ color: 'rgba(217,166,255,0.65)', maxWidth: 280 }}>
            Enter the email address associated with your purchase and we'll restore your access.
          </p>
        </motion.div>

        {/* Form */}
        <AnimatePresence mode="wait">
          {status === 'success' ? (
            <motion.div
              key="success"
              className="flex flex-col items-center text-center space-y-4 py-6"
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.4 }}
            >
              <motion.div
                className="flex items-center justify-center rounded-full"
                style={{ width: 64, height: 64, background: 'rgba(0,200,100,0.15)', border: '2px solid rgba(0,200,100,0.5)' }}
                animate={{ boxShadow: ['0 0 12px rgba(0,200,100,0.3)', '0 0 28px rgba(0,200,100,0.7)', '0 0 12px rgba(0,200,100,0.3)'] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              >
                <span style={{ fontSize: 28 }}>✅</span>
              </motion.div>
              <p className="font-bold text-lg" style={{ color: '#4DFFB4' }}>Purchase Restored!</p>
              <p className="text-sm" style={{ color: 'rgba(217,166,255,0.7)', maxWidth: 260 }}>{message}</p>
              <motion.button
                onClick={onBack}
                className="mt-4 w-full h-14 rounded-3xl font-bold text-white text-base"
                style={{ background: 'linear-gradient(135deg, #C400FF, #FF00E6)', boxShadow: '0 0 28px rgba(196,0,255,0.7)' }}
                whileTap={{ scale: 0.97 }}
              >
                Back to Premium 👑
              </motion.button>
            </motion.div>
          ) : (
            <motion.form
              key="form"
              onSubmit={handleRestore}
              className="space-y-4"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4, delay: 0.2 }}
            >
              <div>
                <label className="block text-sm font-semibold mb-2" style={{ color: '#D9A6FF' }}>
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full px-4 py-3.5 rounded-2xl text-sm outline-none transition-all"
                  style={{
                    background: 'rgba(255,255,255,0.06)',
                    border: '1px solid rgba(196,0,255,0.35)',
                    color: '#FFFFFF',
                  }}
                  onFocus={e => e.target.style.borderColor = '#C400FF'}
                  onBlur={e => e.target.style.borderColor = 'rgba(196,0,255,0.35)'}
                />
              </div>

              {/* Error / not found message */}
              <AnimatePresence>
                {(status === 'not_found' || status === 'error') && (
                  <motion.div
                    className="px-4 py-3 rounded-2xl"
                    style={{ background: 'rgba(255,80,80,0.1)', border: '1px solid rgba(255,80,80,0.35)' }}
                    initial={{ opacity: 0, y: -8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                  >
                    <p className="text-xs" style={{ color: '#FF8080' }}>{message}</p>
                  </motion.div>
                )}
              </AnimatePresence>

              <motion.button
                type="submit"
                disabled={status === 'loading' || !email.trim()}
                className="w-full h-14 rounded-3xl font-bold text-white text-base flex items-center justify-center gap-2 disabled:opacity-50"
                style={{ background: 'linear-gradient(135deg, #C400FF, #FF00E6)' }}
                animate={{ boxShadow: ['0 0 20px rgba(196,0,255,0.5)', '0 0 40px rgba(196,0,255,0.9)', '0 0 20px rgba(196,0,255,0.5)'] }}
                transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                whileTap={{ scale: 0.97 }}
              >
                {status === 'loading' ? (
                  <><motion.span animate={{ rotate: 360 }} transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}>⏳</motion.span> Checking...</>
                ) : (
                  '🔄 Restore Purchases'
                )}
              </motion.button>

              {/* Support note */}
              <p className="text-center text-xs" style={{ color: 'rgba(217,166,255,0.45)', paddingTop: 4 }}>
                Having trouble? Contact us at{' '}
                <span style={{ color: '#C400FF' }}>support@naughtynavigator.app</span>
              </p>
            </motion.form>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}