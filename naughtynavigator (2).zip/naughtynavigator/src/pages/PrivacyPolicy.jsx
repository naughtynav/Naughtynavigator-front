import React from 'react';
import { ArrowLeft } from 'lucide-react';
import PrivacyPolicyContent from '../components/navigation/PrivacyPolicyContent';

export default function PrivacyPolicy() {
  return (
    <div className="bg-zinc-950 text-zinc-100 min-h-full flex flex-col">
      <div className="sticky top-0 z-50 bg-zinc-950/80 backdrop-blur-xl border-b border-zinc-800/50">
        <div className="max-w-lg mx-auto px-4 py-3 flex items-center gap-3">
          <a href="/" className="text-zinc-400 hover:text-zinc-100 transition-colors">
            <ArrowLeft className="w-5 h-5" />
          </a>
          <h1 className="text-base font-semibold">Privacy Policy</h1>
        </div>
      </div>
      <div className="flex-1 max-w-lg mx-auto w-full">
        <PrivacyPolicyContent />
      </div>
    </div>
  );
}