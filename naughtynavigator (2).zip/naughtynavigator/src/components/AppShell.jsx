import React, { useState } from 'react';
import { Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import BottomTabBar from './navigation/BottomTabBar';
import Navigation from '../pages/Navigation';
import Settings from '../pages/Settings';
import Upgrade from '../pages/Upgrade';
import PremiumBadge from './navigation/PremiumBadge';
import TripsTab from './navigation/TripsTab';
import VoicePersonalityPage from '../pages/VoicePersonalityPage';
import MapThemePage from '../pages/MapThemePage';
import Members from '../pages/Members';

export default function AppShell() {
  const navigate = useNavigate();
  const location = useLocation();

  const [isPremium, setIsPremium] = useState(() => localStorage.getItem('nn_premium') === 'true');
  const [selectedVoice, setSelectedVoice] = useState(() => localStorage.getItem('nn_voice') || 'velvet');

  const handleVoiceChange = (v) => {
    setSelectedVoice(v);
    localStorage.setItem('nn_voice', v);
  };

  // Derive active tab from path
  const path = location.pathname;
  const activeTab = path.startsWith('/settings') ? 'settings'
    : path.startsWith('/trips') ? 'trips'
    : path.startsWith('/voice-personality') ? 'voice'
    : path.startsWith('/map-themes') ? 'map'
    : path.startsWith('/members') ? 'members'
    : path.startsWith('/upgrade') ? 'upgrade'
    : path === '/' || path.startsWith('/navigate') ? 'navigate'
    : 'navigate';

  const handleTabChange = (tab) => {
    if (tab === 'navigate') navigate('/');
    else if (tab === 'voice') navigate('/voice-personality');
    else if (tab === 'map') navigate('/map-themes');
    else if (tab === 'members') navigate('/members');
    else navigate(`/${tab}`);
  };

  return (
    <div className="flex flex-col w-full h-full" style={{ background: '#080010' }}>
      {/* Header */}
      <div className="shrink-0 px-4 py-3 border-b border-zinc-800/50 flex items-center gap-2" style={{ background: 'rgba(13,0,24,0.98)' }}>
        <img src="https://media.base44.com/images/public/69b8572fda649af9ebb82bbc/f8b628f68_Copilot_20260326_181419.png" alt="Naughty Navigator" className="w-7 h-7" />
        <h1 className="text-base font-bold tracking-tight bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
          Naughty Navigator
        </h1>
        {isPremium && (
          <div className="ml-auto">
            <PremiumBadge size="sm" />
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        <Routes>
          <Route path="/" element={
            <Navigation
              selectedVoice={selectedVoice}
              onVoiceChange={handleVoiceChange}
              isPremium={isPremium}
              onUpgrade={() => navigate('/upgrade')}
            />
          } />
          <Route path="/navigate" element={<Navigate to="/" replace />} />
          <Route path="/upgrade" element={
            <Upgrade onClose={(prefs) => {
              setIsPremium(localStorage.getItem('nn_premium') === 'true');
              if (prefs?.selectedVoice) handleVoiceChange(prefs.selectedVoice);
              navigate('/');
            }} />
          } />
          <Route path="/trips" element={<TripsTab onNavigateTo={() => navigate('/')} />} />
          <Route path="/members" element={<Members onUpgrade={() => navigate('/upgrade')} />} />
          <Route path="/settings/*" element={<Settings />} />
          <Route path="/voice-personality" element={<VoicePersonalityPage />} />
          <Route path="/map-themes" element={<MapThemePage />} />
        </Routes>
      </div>

      {/* Bottom tab bar */}
      <BottomTabBar activeTab={activeTab} onTabChange={handleTabChange} />
    </div>
  );
}