import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Lock, Check } from 'lucide-react';

const FEATURES = [
  'Unlimited Voice Packs',
  'Exclusive Themes & Features',
  'Early Access to New Content',
  'Ad-Free Navigation',
  'Premium Navigation Styles',
];

const PLANS = [
  { id: 'monthly', label: 'Monthly Plan', price: '$4.99', subtext: 'Billed Monthly', glowColor: '#C400FF', period: 'month' },
  { id: 'yearly', label: 'Yearly Plan', price: '$29.99', subtext: 'Billed Annually', glowColor: '#FF6EB3', period: 'year', tag: 'Save 50%', bestDeal: 'Best Deal!' },
  { id: 'onetime', label: 'One-Time Purchase', price: '$9.99', subtext: 'Lifetime access', glowColor: '#C400FF', period: 'onetime' },
];

export default function CheckoutScreen({ onProceed, isLoading }) {
  const [selectedPlan, setSelectedPlan] = useState('yearly');

  return (
    <div
      className="relative flex flex-col h-full overflow-y-auto"
      style={{
        background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)',
        paddingBottom: '40px',
      }}
    >
      {/* Ambient glow */}
      <div className="fixed inset-0 pointer-events-none" style={{
        background: 'radial-gradient(ellipse at 50% 20%, rgba(196,0,255,0.25) 0%, transparent 60%)',
        zIndex: 0,
      }} />

      <div className="relative z-10 flex flex-col w-full px-6 py-8">
        {/* HEADER */}
        <motion.div
          className="text-center mb-10"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          {/* Logo */}
          <motion.div
            className="flex justify-center mb-4"
            animate={{ y: [0, -6, 0] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
          >
            <motion.div
              style={{
                fontSize: 48,
                filter: 'drop-shadow(0 0 16px rgba(255,110,179,0.8)) drop-shadow(0 0 32px rgba(196,0,255,0.5))',
              }}
            >
              📍💋
            </motion.div>
          </motion.div>

          {/* Title */}
          <h1
            style={{
              fontSize: 32,
              fontWeight: 800,
              background: 'linear-gradient(135deg, #FF6EB3 0%, #C400FF 100%)',
              backgroundClip: 'text',
              WebkitBackgroundClip: 'text',
              WebkitTextFillColor: 'transparent',
              textShadow: '0 0 20px rgba(196,0,255,0.4)',
              marginBottom: 8,
              lineHeight: 1.2,
            }}
          >
            Naughty Navigator Premium
          </h1>

          {/* Subtitle */}
          <p style={{
            fontSize: 14,
            color: 'rgba(217,166,255,0.8)',
            lineHeight: 1.6,
            maxWidth: 300,
            margin: '0 auto',
          }}>
            Unlock all premium voices, moods, themes, and exclusive content.
          </p>
        </motion.div>

        {/* CHOOSE YOUR PLAN SECTION */}
        <motion.div
          className="mb-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.15 }}
        >
          <h2 style={{
            fontSize: 18,
            fontWeight: 700,
            color: '#FFFFFF',
            textAlign: 'center',
            marginBottom: 16,
          }}>
            Choose Your Plan
          </h2>

          <div className="space-y-3">
            {PLANS.map((plan, i) => (
              <motion.button
                key={plan.id}
                onClick={() => setSelectedPlan(plan.id)}
                className="w-full relative"
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.4, delay: 0.2 + i * 0.08 }}
              >
                {/* Tags */}
                {plan.tag && (
                  <div className="absolute top-3 left-4 z-20">
                    <span style={{
                      fontSize: 10,
                      fontWeight: 700,
                      color: '#FF6EB3',
                      background: 'rgba(255,110,179,0.15)',
                      border: '1px solid rgba(255,110,179,0.4)',
                      padding: '2px 8px',
                      borderRadius: 12,
                    }}>
                      {plan.tag}
                    </span>
                  </div>
                )}
                {plan.bestDeal && (
                  <motion.div
                    className="absolute top-3 right-4 z-20"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                  >
                    <span style={{
                      fontSize: 10,
                      fontWeight: 700,
                      color: '#FFD700',
                      background: 'rgba(255,215,0,0.15)',
                      border: '1px solid rgba(255,215,0,0.4)',
                      padding: '2px 8px',
                      borderRadius: 12,
                    }}>
                      ⭐ {plan.bestDeal}
                    </span>
                  </motion.div>
                )}

                {/* Plan Container */}
                <motion.div
                  className="rounded-2xl p-5 relative overflow-hidden"
                  style={{
                    background: selectedPlan === plan.id
                      ? `linear-gradient(135deg, ${plan.glowColor}20 0%, ${plan.glowColor}05 100%)`
                      : 'rgba(255,255,255,0.04)',
                    border: selectedPlan === plan.id
                      ? `2px solid ${plan.glowColor}`
                      : '1px solid rgba(196,0,255,0.15)',
                    boxShadow: selectedPlan === plan.id
                      ? `0 0 20px ${plan.glowColor}44, inset 0 0 20px ${plan.glowColor}11`
                      : 'none',
                  }}
                  animate={selectedPlan === plan.id ? {
                    boxShadow: [
                      `0 0 16px ${plan.glowColor}33, inset 0 0 16px ${plan.glowColor}11`,
                      `0 0 28px ${plan.glowColor}66, inset 0 0 28px ${plan.glowColor}22`,
                      `0 0 16px ${plan.glowColor}33, inset 0 0 16px ${plan.glowColor}11`,
                    ],
                  } : {}}
                  transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
                >
                  <div className="flex items-center gap-4">
                    {/* Radio Button */}
                    <div style={{
                      width: 24,
                      height: 24,
                      borderRadius: '50%',
                      border: selectedPlan === plan.id ? `3px solid ${plan.glowColor}` : '2px solid rgba(196,0,255,0.4)',
                      background: selectedPlan === plan.id ? plan.glowColor : 'transparent',
                      flexShrink: 0,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      boxShadow: selectedPlan === plan.id ? `0 0 12px ${plan.glowColor}` : 'none',
                    }}>
                      {selectedPlan === plan.id && (
                        <motion.div
                          animate={{ scale: [1, 1.2, 1] }}
                          transition={{ duration: 0.3 }}
                          style={{
                            width: 8,
                            height: 8,
                            borderRadius: '50%',
                            background: '#fff',
                          }}
                        />
                      )}
                    </div>

                    {/* Plan Info */}
                    <div className="flex-1 text-left">
                      <p style={{
                        fontSize: 14,
                        fontWeight: 600,
                        color: '#FFFFFF',
                        marginBottom: 2,
                      }}>
                        {plan.label}
                      </p>
                      <p style={{
                        fontSize: 11,
                        color: 'rgba(217,166,255,0.6)',
                      }}>
                        {plan.subtext}
                      </p>
                    </div>

                    {/* Price */}
                    <div className="text-right shrink-0">
                      <motion.p
                        style={{
                          fontSize: 20,
                          fontWeight: 800,
                          color: selectedPlan === plan.id ? plan.glowColor : '#D9A6FF',
                        }}
                        animate={selectedPlan === plan.id ? {
                          textShadow: [
                            `0 0 0px ${plan.glowColor}00`,
                            `0 0 12px ${plan.glowColor}99`,
                            `0 0 0px ${plan.glowColor}00`,
                          ],
                        } : {}}
                        transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                      >
                        {plan.price}
                      </motion.p>
                    </div>
                  </div>
                </motion.div>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* WHAT YOU GET SECTION */}
        <motion.div
          className="mb-10"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.35 }}
        >
          <h3 style={{
            fontSize: 16,
            fontWeight: 700,
            color: '#FFFFFF',
            marginBottom: 12,
          }}>
            Included With Premium
          </h3>

          <div className="space-y-2.5">
            {FEATURES.map((feature, i) => (
              <motion.div
                key={feature}
                className="flex items-center gap-3"
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.4, delay: 0.45 + i * 0.06 }}
              >
                <motion.div
                  animate={{
                    boxShadow: ['0 0 8px rgba(255,110,179,0)', '0 0 12px rgba(255,110,179,0.8)', '0 0 8px rgba(255,110,179,0)'],
                  }}
                  transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
                  style={{
                    width: 20,
                    height: 20,
                    borderRadius: '50%',
                    background: 'linear-gradient(135deg, #FF6EB3, #FF4DFF)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexShrink: 0,
                  }}
                >
                  <Check className="w-3.5 h-3.5" style={{ color: '#fff' }} />
                </motion.div>
                <span style={{
                  fontSize: 14,
                  color: '#D9A6FF',
                }}>
                  {feature}
                </span>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* PAYMENT SECTION */}
        <motion.div
          className="mb-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.6 }}
        >
          <motion.button
            onClick={onProceed}
            disabled={isLoading}
            className="w-full h-14 rounded-2xl font-bold text-white text-base tracking-wide flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              background: 'linear-gradient(135deg, #C400FF, #FF00E6)',
              boxShadow: '0 0 28px rgba(196,0,255,0.7), 0 0 56px rgba(196,0,255,0.3)',
            }}
            animate={{
              boxShadow: [
                '0 0 20px rgba(196,0,255,0.6)',
                '0 0 44px rgba(196,0,255,1)',
                '0 0 20px rgba(196,0,255,0.6)',
              ],
            }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            whileTap={{ scale: 0.96 }}
          >
            {isLoading ? (
              <>
                <motion.span
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                >
                  ⏳
                </motion.span>
                Processing...
              </>
            ) : (
              <>
                <Lock className="w-4 h-4" />
                Continue to Payment
              </>
            )}
          </motion.button>

          {/* Secure Checkout */}
          <motion.p
            className="text-center mt-2"
            style={{
              fontSize: 12,
              color: '#FFFFFF',
            }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.7 }}
          >
            Secure Checkout
          </motion.p>

          {/* Payment Icons */}
          <motion.div
            className="flex items-center justify-center gap-4 mt-3"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, delay: 0.75 }}
          >
            <span style={{ fontSize: 18 }}>💳</span>
            <span style={{ fontSize: 18 }}>💰</span>
            <span style={{ fontSize: 18 }}>🍎</span>
          </motion.div>
        </motion.div>

        {/* FOOTER */}
        <motion.div
          className="text-center space-y-2"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.8 }}
        >
          <p style={{
            fontSize: 11,
            color: 'rgba(217,166,255,0.7)',
            fontWeight: 500,
          }}>
            Three ways to get premium:
          </p>
          <div style={{
            fontSize: 11,
            color: 'rgba(217,166,255,0.6)',
            lineHeight: 1.8,
          }}>
            <p>✔ One-time unlock: <span style={{ color: '#FF6EB3', fontWeight: 600 }}>$9.99</span></p>
            <p>✔ Monthly subscription: <span style={{ color: '#FF6EB3', fontWeight: 600 }}>$4.99</span></p>
            <p>✔ Yearly subscription: <span style={{ color: '#FFD700', fontWeight: 600 }}>$29.99</span> (your best value)</p>
          </div>
          <p style={{
            fontSize: 10,
            color: 'rgba(217,166,255,0.5)',
            fontStyle: 'italic',
            marginTop: 8,
          }}>
            This gives every type of user a path to upgrade.
          </p>
        </motion.div>
      </div>
    </div>
  );
}