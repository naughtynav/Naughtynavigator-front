import React from 'react';

const sections = [
  {
    icon: '📩',
    title: 'How to Reach Us',
    content: 'For all support inquiries, please contact us at:',
    highlight: 'Email: naughtynav62@gmail.com',
    footer: 'This inbox is monitored regularly, and we aim to respond as quickly as possible.',
  },
  {
    icon: '🛠️',
    title: 'What We Can Help With',
    content: 'Our support team can assist with:',
    items: [
      'App functionality questions',
      'Account or login issues',
      'Voice pack or upgrade concerns',
      'Bug reports or technical problems',
      'Feedback and feature suggestions',
      'Billing or purchase questions',
    ],
  },
  {
    icon: '🕒',
    title: 'Response Time',
    content: 'We strive to respond to all inquiries within 1–3 business days. Response times may vary during weekends, holidays, or high‑volume periods.',
  },
  {
    icon: '📎',
    title: 'Helpful Tips When Contacting Support',
    content: 'To help us assist you faster, please include:',
    items: [
      'A brief description of the issue',
      'Your device type (Android model)',
      'App version (found in your settings menu)',
      'Screenshots, if applicable',
    ],
  },
  {
    icon: '💬',
    title: 'Feedback & Suggestions',
    content: 'We love hearing from our users. If you have ideas for new features, voice packs, or improvements, feel free to share them. Your feedback helps shape the future of Naughty Navigator.',
  },
];

export default function ContactSupportContent() {
  return (
    <div className="overflow-y-auto h-full px-4 py-6 space-y-5" style={{ background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' }}>
      {/* Header */}
      <div className="space-y-1">
        <h2 className="text-base font-bold" style={{ color: '#E8CCFF' }}>Naughty Navigator – Contact Support</h2>
        <p className="text-xs" style={{ color: 'rgba(217,166,255,0.45)' }}>Last Updated: March 27, 2026</p>
        <p className="text-xs leading-relaxed" style={{ color: 'rgba(217,166,255,0.6)' }}>
          We're here to make sure your experience with Naughty Navigator is smooth, enjoyable, and fully supported. Whether you have a question, need help with a feature, or want to report an issue, our support team is ready to assist.
        </p>
      </div>

      <div className="h-px" style={{ background: 'rgba(196,0,255,0.15)' }} />

      {sections.map((section, i) => (
        <div key={i} className="space-y-2">
          <h3 className="text-sm font-semibold" style={{ color: '#D9A6FF' }}>
            {section.icon} {section.title}
          </h3>
          {section.content && (
            <p className="text-xs leading-relaxed" style={{ color: 'rgba(217,166,255,0.6)' }}>{section.content}</p>
          )}
          {section.highlight && (
            <div className="rounded-xl px-4 py-3" style={{ background: 'rgba(196,0,255,0.1)', border: '1px solid rgba(196,0,255,0.3)' }}>
              <p className="text-sm font-semibold" style={{ color: '#C400FF' }}>{section.highlight}</p>
            </div>
          )}
          {section.items && (
            <ul className="space-y-1 pl-4">
              {section.items.map((item, j) => (
                <li key={j} className="text-xs leading-relaxed list-disc" style={{ color: 'rgba(217,166,255,0.55)' }}>{item}</li>
              ))}
            </ul>
          )}
          {section.footer && (
            <p className="text-xs leading-relaxed" style={{ color: 'rgba(217,166,255,0.55)' }}>{section.footer}</p>
          )}
        </div>
      ))}

      <div className="rounded-2xl px-4 py-3 text-center" style={{ background: 'rgba(196,0,255,0.06)', border: '1px solid rgba(196,0,255,0.2)' }}>
        <p className="text-xs italic" style={{ color: '#9B60CC' }}>
          "Thank you for being part of the Naughty Navigator community. We're committed to giving you a fun, premium, and reliable experience every time you open the app."
        </p>
      </div>
    </div>
  );
}