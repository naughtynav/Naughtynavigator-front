import React, { useEffect } from 'react';
import { MapContainer, TileLayer, Polyline, Marker, useMap, useMapEvents } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix default marker icons
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

function RecenterMap({ center }) {
  const map = useMap();
  useEffect(() => {
    if (center) map.setView(center, map.getZoom());
  }, [center, map]);
  return null;
}

// Injects CSS filters onto the Leaflet tile layer for neon effect
function NeonFilter() {
  const map = useMap();
  useEffect(() => {
    const pane = map.getPane('tilePane');
    if (pane) {
      // Shift hue toward purple/violet and boost contrast for neon look
      pane.style.filter = 'hue-rotate(200deg) saturate(2.2) brightness(0.75) contrast(1.15)';
    }
    return () => {
      if (pane) pane.style.filter = '';
    };
  }, [map]);
  return null;
}

export default function NavigationMap({ routeCoords, userLocation, destination, isPremium }) {
  const center = userLocation || (routeCoords?.length ? routeCoords[0] : [40.7128, -74.006]);

  return (
    <div className="relative w-full h-full overflow-hidden" style={{ minHeight: '300px' }}>
      <MapContainer
        center={center}
        zoom={14}
        style={{ width: '100%', height: '100%', minHeight: '300px' }}
        zoomControl={false}
        attributionControl={false}
      >
        <TileLayer
          url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
        />

        {/* Neon mode enhancements for premium users */}
        {isPremium && <NeonFilter />}

        {routeCoords?.length > 1 && (
          <Polyline
            positions={routeCoords}
            pathOptions={isPremium
              ? { color: '#C400FF', weight: 5, opacity: 1 }
              : { color: '#ec4899', weight: 4, opacity: 0.85 }
            }
          />
        )}

        {userLocation && <Marker position={userLocation} />}
        {routeCoords?.length > 0 && (
          <Marker position={routeCoords[routeCoords.length - 1]} />
        )}
        <RecenterMap center={userLocation || center} />
      </MapContainer>

      {/* Premium neon glow overlay on roads */}
      {isPremium && (
        <>
          {/* Subtle vignette + neon tint overlay */}
          <div
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'radial-gradient(ellipse at center, transparent 40%, rgba(26,0,36,0.55) 100%)',
              zIndex: 400,
            }}
          />
          {/* Neon mode badge */}
          <div
            className="absolute bottom-2 right-2 flex items-center gap-1 px-2 py-1 rounded-lg pointer-events-none"
            style={{
              background: 'rgba(26,0,36,0.8)',
              border: '1px solid rgba(196,0,255,0.6)',
              boxShadow: '0 0 10px rgba(196,0,255,0.4)',
              zIndex: 500,
            }}
          >
            <span style={{ fontSize: 10 }}>🗺️</span>
            <span style={{ fontSize: 9, fontWeight: 700, color: '#C400FF', letterSpacing: '0.08em' }}>NEON MODE</span>
          </div>
        </>
      )}
    </div>
  );
}