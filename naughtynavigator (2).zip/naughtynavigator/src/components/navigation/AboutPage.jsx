import React from 'react';
import { motion } from 'framer-motion';

const FEATURES = [
  { emoji: '🗺️', text: 'Turn-by-turn navigation with personality' },
  { emoji: '💋', text: 'Multiple seductive voice co-pilots' },
  { emoji: '😈', text: 'Mood-based routing & commentary' },
  { emoji: '🟣', text: 'Neon map themes for premium users' },
  { emoji: '🔊', text: 'Real-time spoken directions' },
];

export default function AboutPage() {
  return (
    <div className="overflow-y-auto h-full bg-zinc-950 px-4 py-6">

      {/* Hero */}
      <motion.div
        className="flex flex-col items-center text-center mb-8"
        initial={{ opacity: 0, y: -16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45 }}
      >
        {/* Glow + Logo */}
        <div className="relative mb-4">
          <div
            className="absolute inset-0 rounded-full pointer-events-none"
            style={{
              background: 'radial-gradient(circle, rgba(196,0,255,0.35) 0%, transparent 70%)',
              filter: 'blur(18px)',
            }}
          />
          <motion.span
            style={{ fontSize: 56, filter: 'drop-shadow(0 0 20px #C400FF)', position: 'relative', zIndex: 1 }}
            animate={{ scale: [1, 1.07, 1], rotate: [-2, 2, -2] }}
            transition={{ duration: 3, repeat: Infinity, ease: 'easeInOut' }}
          >
            🧭
          </motion.span>
        </div>

        <h1
          className="text-xl font-extrabold tracking-tight"
          style={{
            background: 'linear-gradient(90deg, #FF00E6, #C400FF, #D9A6FF)',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}
        >
          Naughty Navigator
        </h1>
        <p className="text-xs text-zinc-500 mt-1 tracking-widest uppercase">Version 1.0.0</p>
      </motion.div>

      {/* Tagline card */}
      <motion.div
        className="rounded-2xl px-5 py-4 mb-5 text-center"
        style={{
          background: 'rgba(196,0,255,0.07)',
          border: '1px solid rgba(196,0,255,0.25)',
          boxShadow: '0 0 20px rgba(196,0,255,0.08)',
        }}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.1 }}
      >
        <p className="text-sm text-zinc-200 leading-relaxed italic">
          "The GPS that flirts back."
        </p>
        <p className="text-xs text-zinc-500 mt-2 leading-relaxed">
          Naughty Navigator is a navigation app with attitude — blending real turn-by-turn directions
          with seductive voice co-pilots, mood-based commentary, and a premium neon aesthetic.
          Every route is an experience.
        </p>
      </motion.div>

      {/* Features */}
      <motion.div
        className="mb-5"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
      >
        <p className="text-[10px] uppercase tracking-widest text-zinc-600 font-semibold mb-3 px-1">
          What it does
        </p>
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden divide-y divide-zinc-800/60">
          {FEATURES.map((f, i) => (
            <div key={i} className="flex items-center gap-3 px-4 py-3">
              <span className="text-lg shrink-0">{f.emoji}</span>
              <p className="text-sm text-zinc-300">{f.text}</p>
            </div>
          ))}
        </div>
      </motion.div>

      {/* Brand identity */}
      <motion.div
        className="mb-5"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.3 }}
      >
        <p className="text-[10px] uppercase tracking-widest text-zinc-600 font-semibold mb-3 px-1">
          Brand Identity
        </p>
        <div
          className="rounded-2xl px-5 py-4 space-y-3"
          style={{ background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)' }}
        >
          <div className="flex items-center justify-between">
            <p className="text-xs text-zinc-500">Primary Color</p>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full" style={{ background: '#C400FF', boxShadow: '0 0 8px #C400FF' }} />
              <p className="text-xs font-mono text-zinc-300">#C400FF</p>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-xs text-zinc-500">Accent Color</p>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full" style={{ background: '#FF4DFF', boxShadow: '0 0 8px #FF4DFF' }} />
              <p className="text-xs font-mono text-zinc-300">#FF4DFF</p>
            </div>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-xs text-zinc-500">Style</p>
            <p className="text-xs text-zinc-300">Dark · Neon · Seductive</p>
          </div>
          <div className="flex items-center justify-between">
            <p className="text-xs text-zinc-500">Tone</p>
            <p className="text-xs text-zinc-300">Playful · Bold · Flirtatious</p>
          </div>
        </div>
      </motion.div>

      {/* Footer */}
      <div className="text-center pt-2 pb-4">
        <p className="text-[10px] text-zinc-700 italic">
          "Let me show you what I can really do…"
        </p>
        <p className="text-[10px] text-zinc-800 mt-1">© 2026 Naughty Navigator. All rights reserved.</p>
      </div>
    </div>
  );
}