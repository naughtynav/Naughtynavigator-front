import React from 'react';

const sections = [
  {
    title: '1. License Grant',
    content: 'We grant you a limited, non‑exclusive, non‑transferable, revocable license to use the App for personal, non‑commercial purposes in accordance with this Agreement.\n\nYou may not:',
    items: [
      'Copy, modify, or create derivative works of the App',
      'Reverse engineer, decompile, or attempt to extract source code',
      'Rent, lease, sell, or sublicense the App',
      'Use the App for unlawful or harmful purposes',
    ],
  },
  {
    title: '2. Ownership',
    content: 'All rights, title, and interest in the App—including voice packs, personality content, graphics, branding, and features—are owned by the Company or licensed to us. This Agreement does not transfer any ownership rights to you.',
  },
  {
    title: '3. User Responsibilities',
    content: 'You agree to:',
    items: [
      'Use the App safely and responsibly',
      'Follow all traffic laws and avoid interacting with the App while driving',
      'Ensure your device meets minimum system requirements',
      'Keep your account information accurate and secure',
    ],
    footer: 'You are solely responsible for any consequences resulting from misuse of the App.',
  },
  {
    title: '4. In‑App Purchases',
    content: 'The App may offer optional paid features, upgrades, or voice packs.\n\nBy making a purchase, you acknowledge that:',
    items: [
      'All transactions are processed through the Google Play Store',
      'Refunds are governed by Google Play policies',
      'Digital items may change or be updated over time',
    ],
  },
  {
    title: '5. Updates & Modifications',
    content: 'We may provide updates, enhancements, or bug fixes. These may:',
    items: [
      'Automatically install',
      'Modify or remove certain features',
      'Be required for continued use of the App',
    ],
    footer: 'We are not obligated to maintain or support older versions.',
  },
  {
    title: '6. Privacy',
    content: 'Your use of the App is also governed by our Privacy Policy, which explains how we collect, use, and protect your information.',
  },
  {
    title: '7. Disclaimer of Warranties',
    content: 'The App is provided "as is" and "as available."\n\nWe do not guarantee:',
    items: [
      'Error‑free performance',
      'Uninterrupted access',
      'Accuracy of navigation or content',
    ],
    footer: 'To the fullest extent permitted by law, we disclaim all warranties, express or implied.',
  },
  {
    title: '8. Limitation of Liability',
    content: 'To the maximum extent permitted by law, we are not liable for:',
    items: [
      'Indirect, incidental, or consequential damages',
      'Loss of data, revenue, or profits',
      'Damages resulting from misuse of the App',
    ],
    footer: 'Our total liability will not exceed the amount you paid for the App, if any.',
  },
  {
    title: '9. Termination',
    content: 'We may suspend or terminate your access to the App at any time for violations of this Agreement.\n\nUpon termination:',
    items: [
      'Your license to use the App ends immediately',
      'You must delete all copies of the App from your device',
    ],
  },
  {
    title: '10. Governing Law',
    content: 'This Agreement is governed by the laws of the State of Illinois, without regard to conflict‑of‑law principles.',
  },
  {
    title: '11. Contact Information',
    content: 'For questions about this Agreement, please contact:',
    footer: 'Email: naughtynav62@gmail.com',
  },
];

export default function EULAContent() {
  return (
    <div className="overflow-y-auto h-full bg-zinc-950 px-4 py-6 space-y-6 pb-20">
      <div className="space-y-2">
        <h2 className="text-lg font-bold text-zinc-100">Naughty Navigator – EULA</h2>
        <p className="text-xs text-zinc-500">Last Updated: March 27, 2026</p>
        <p className="text-sm text-zinc-400 leading-relaxed">
          This End‑User License Agreement ("Agreement") is a legal contract between you ("User") and Naughty Navigator ("Company," "we," "our," or "us"). By downloading, installing, or using the Naughty Navigator mobile application ("App"), you agree to be bound by the terms of this Agreement.
        </p>
        <p className="text-sm text-zinc-400 leading-relaxed font-medium">
          If you do not agree to these terms, do not install or use the App.
        </p>
      </div>

      <div className="h-px bg-zinc-800" />

      {sections.map((section, i) => (
        <div key={i} className="space-y-3">
          <h2 className="text-sm font-semibold text-zinc-200">{section.title}</h2>
          {section.content && (
            <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{section.content}</p>
          )}
          {section.items && (
            <ul className="space-y-1 pl-4">
              {section.items.map((item, j) => (
                <li key={j} className="text-sm text-zinc-400 list-disc leading-relaxed">{item}</li>
              ))}
            </ul>
          )}
          {section.footer && (
            <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{section.footer}</p>
          )}
        </div>
      ))}

      <div className="h-px bg-zinc-800" />
      <p className="text-sm text-zinc-400 leading-relaxed text-center italic">
        By installing or using Naughty Navigator, you acknowledge that you have read, understood, and agree to be bound by this EULA.
      </p>
    </div>
  );
}