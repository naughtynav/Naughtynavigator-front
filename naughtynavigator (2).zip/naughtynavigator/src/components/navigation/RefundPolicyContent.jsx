import React from 'react';

const sections = [
  {
    title: '📌 Overview',
    content: 'All purchases made through Naughty Navigator are processed securely through the Google Play Store. Because of this, refunds are generally managed by Google according to their policies.\n\nHowever, we will always do our best to support you and guide you through the process.',
  },
  {
    title: '🛒 Eligible Refund Situations',
    content: 'You may be eligible for a refund if:',
    items: [
      'You were charged by mistake',
      'You purchased the wrong item',
      'A technical issue prevented you from accessing purchased content',
      'A duplicate purchase occurred',
    ],
    footer: 'Refund eligibility is determined by Google Play and may vary based on timing and purchase history.',
  },
  {
    title: '❌ Non‑Refundable Situations',
    content: 'Refunds are typically not granted for:',
    items: [
      'Change of mind',
      'Full use of a digital item before requesting a refund',
      'Purchases made more than 48 hours ago (Google Play restrictions)',
      'Promotional or discounted items',
    ],
  },
  {
    title: '🧾 How to Request a Refund',
    subsections: [
      {
        subtitle: 'Option 1: Through Google Play (Recommended)',
        steps: [
          'Open your browser and visit play.google.com/store/account',
          'Select Order History',
          'Choose the Naughty Navigator purchase',
          'Select Request a Refund and follow the prompts',
        ],
      },
      {
        subtitle: 'Option 2: Contact Us for Assistance',
        text: 'If you experience an issue with a purchase, we\'re happy to help guide you.\n\nEmail: naughtynav62@gmail.com\n\nPlease include:\n• Your Google Play order number (starts with GPA‑)\n• The item purchased\n• A brief description of the issue',
      },
    ],
  },
  {
    title: '⏳ Refund Processing Time',
    content: 'Refunds approved by Google Play are typically processed within 3–5 business days, depending on your payment method.',
  },
  {
    title: '🛠️ Technical Issues',
    content: 'If a purchase is not appearing in your app or a feature is not working as expected, please contact us immediately. Many issues can be resolved without needing a refund.',
    footer: 'Support Email: naughtynav62@gmail.com',
  },
  {
    title: '📄 Policy Updates',
    content: 'We may update this Refund Policy from time to time. Updates will be posted within the app or on our website.',
  },
];

export default function RefundPolicyContent() {
  return (
    <div className="overflow-y-auto h-full bg-zinc-950 px-4 py-6 space-y-6 pb-20">
      <div className="space-y-2">
        <h2 className="text-lg font-bold text-zinc-100">Naughty Navigator – Refund Policy</h2>
        <p className="text-xs text-zinc-500">Last Updated: March 27, 2026</p>
        <p className="text-sm text-zinc-400 leading-relaxed">
          Thank you for using Naughty Navigator. We want every user to enjoy a smooth, premium experience. This Refund Policy explains how refunds are handled for in‑app purchases, subscriptions, and digital content.
        </p>
      </div>

      <div className="h-px bg-zinc-800" />

      {sections.map((section, i) => (
        <div key={i} className="space-y-3">
          <h2 className="text-sm font-semibold text-zinc-200">{section.title}</h2>
          {section.content && (
            <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{section.content}</p>
          )}
          {section.items && (
            <ul className="space-y-1 pl-4">
              {section.items.map((item, j) => (
                <li key={j} className="text-sm text-zinc-400 list-disc leading-relaxed">{item}</li>
              ))}
            </ul>
          )}
          {section.subsections && section.subsections.map((sub, j) => (
            <div key={j} className="space-y-2 pl-2 border-l border-zinc-800">
              <p className="text-xs font-medium text-zinc-300">{sub.subtitle}</p>
              {sub.steps && (
                <ol className="space-y-1 pl-4">
                  {sub.steps.map((step, k) => (
                    <li key={k} className="text-sm text-zinc-400 list-decimal leading-relaxed">{step}</li>
                  ))}
                </ol>
              )}
              {sub.text && (
                <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{sub.text}</p>
              )}
            </div>
          ))}
          {section.footer && (
            <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{section.footer}</p>
          )}
        </div>
      ))}

      <div className="h-px bg-zinc-800" />
      <p className="text-sm text-zinc-400 leading-relaxed text-center italic">
        Thank you for supporting Naughty Navigator. We're committed to providing a fun, reliable, and premium experience for every user.
      </p>
    </div>
  );
}