import React from 'react';
import { Search, StopCircle } from 'lucide-react';

export default function DestinationInput({ onStartNavigation, isNavigating, onStopNavigation, value, onChange }) {
  const inputValue = value ?? '';
  const handleChange = (v) => { onChange?.(v); };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (inputValue.trim()) {
      onStartNavigation(inputValue.trim());
    }
  };

  if (isNavigating) {
    return (
      <button
        onClick={onStopNavigation}
        className="w-full flex items-center justify-center gap-2 h-12 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-400 text-sm font-medium hover:bg-red-500/20 transition-colors"
      >
        <StopCircle className="w-4 h-4" />
        Stop Navigation
      </button>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <div className="relative flex-1">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
        <input
          type="text"
          value={inputValue}
          onChange={(e) => handleChange(e.target.value)}
          placeholder="Where to, gorgeous?"
          className="w-full h-12 pl-9 pr-4 rounded-2xl bg-zinc-900 border border-zinc-800 text-zinc-100 text-sm placeholder:text-zinc-600 focus:outline-none focus:border-pink-500/50 transition-colors"
        />
      </div>
    </form>
  );
}