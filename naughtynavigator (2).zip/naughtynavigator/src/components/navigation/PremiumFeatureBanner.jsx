import React from 'react';
import { Lock, Sparkles } from 'lucide-react';
import { motion } from 'framer-motion';

export default function PremiumFeatureBanner({ label, onUpgrade }) {
  return (
    <motion.div
      className="flex items-center gap-3 bg-zinc-900 border border-pink-500/20 rounded-2xl px-4 py-3"
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
    >
      <div className="h-8 w-8 rounded-lg bg-pink-500/10 flex items-center justify-center shrink-0">
        <Lock className="w-4 h-4 text-pink-400" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs font-medium text-zinc-300">{label}</p>
        <p className="text-[10px] text-zinc-500">Premium feature</p>
      </div>
      <button
        onClick={onUpgrade}
        className="flex items-center gap-1 h-7 px-3 rounded-lg bg-pink-500/15 border border-pink-500/30 text-pink-300 text-[11px] font-medium hover:bg-pink-500/25 transition-colors shrink-0"
      >
        <Sparkles className="w-3 h-3" />
        Unlock
      </button>
    </motion.div>
  );
}