import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const ERRORS = [
  {
    id: 'gps_off',
    icon: '📡',
    title: 'GPS is Off',
    situation: 'When location is disabled or unavailable',
    lines: [
      "Babe, I can't guide you if I don't know where you are… turn on GPS.",
      "Lost without you — and without your coordinates. Enable GPS, gorgeous.",
      "I like a mystery, but not this kind. Share your location, darling.",
      "Even I need a little info to work with. GPS on, please.",
    ],
    accent: '#FF4DFF',
  },
  {
    id: 'no_internet',
    icon: '📶',
    title: 'No Internet',
    situation: 'When the connection drops',
    lines: [
      "The connection died… just like that last date of yours. Check your signal.",
      "I'm ghosting you — not by choice. Your internet is the problem, not me.",
      "Can't load the map without Wi-Fi, honey. I need more than vibes.",
      "Signal lost. Even I need a little bandwidth to perform at my best.",
    ],
    accent: '#FF8C00',
  },
  {
    id: 'route_fail',
    icon: '🛣️',
    title: 'Route Failed',
    situation: "When a route can't be calculated",
    lines: [
      "I tried every road and none of them want us together right now. Retry?",
      "Even I can't find a path to that destination. Are you sure it's real?",
      "Route failed. Don't worry — some detours lead to better things.",
      "That route's a dead end, baby. Let's try a different approach.",
    ],
    accent: '#C400FF',
  },
  {
    id: 'no_results',
    icon: '🔍',
    title: 'Search Returns Nothing',
    situation: 'When a destination search finds no results',
    lines: [
      "Nothing? Honey, even I can't conjure a place that doesn't exist.",
      "I searched everywhere and came up empty. Try being more specific, babe.",
      "That place is a mystery even to me. Check your spelling, gorgeous.",
      "No results found. Either it doesn't exist… or it's hiding from both of us.",
    ],
    accent: '#FF6EB3',
  },
];

function ErrorCard({ error, isOpen, onToggle }) {
  const [copiedLine, setCopiedLine] = useState(null);

  const handleCopy = (line, i) => {
    navigator.clipboard?.writeText(line);
    setCopiedLine(i);
    setTimeout(() => setCopiedLine(null), 1500);
  };

  return (
    <motion.div
      className="rounded-2xl overflow-hidden"
      style={{
        background: 'rgba(255,255,255,0.04)',
        border: `1px solid ${isOpen ? error.accent + '66' : 'rgba(255,255,255,0.08)'}`,
        boxShadow: isOpen ? `0 0 20px ${error.accent}22` : 'none',
        transition: 'border-color 0.3s ease, box-shadow 0.3s ease',
      }}
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
    >
      {/* Header */}
      <button
        onClick={onToggle}
        className="w-full flex items-center gap-4 px-4 py-4 text-left"
      >
        <div
          className="h-11 w-11 rounded-xl flex items-center justify-center shrink-0 text-xl"
          style={{ background: `${error.accent}18`, border: `1px solid ${error.accent}44` }}
        >
          {error.icon}
        </div>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-zinc-100">{error.title}</p>
          <p className="text-[11px] text-zinc-500 mt-0.5">{error.situation}</p>
        </div>
        <motion.span
          animate={{ rotate: isOpen ? 90 : 0 }}
          transition={{ duration: 0.2 }}
          className="text-zinc-500 text-base shrink-0"
          style={{ color: isOpen ? error.accent : undefined }}
        >
          ›
        </motion.span>
      </button>

      {/* Lines */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.25, ease: 'easeInOut' }}
            style={{ overflow: 'hidden' }}
          >
            <div
              className="px-4 pb-4 space-y-2"
              style={{ borderTop: `1px solid ${error.accent}22` }}
            >
              <p
                className="text-[10px] font-semibold uppercase tracking-widest pt-3 pb-1"
                style={{ color: error.accent }}
              >
                ✦ Naughty Navigator Says…
              </p>
              {error.lines.map((line, i) => (
                <motion.div
                  key={i}
                  className="flex items-start gap-3 rounded-xl px-3 py-3"
                  style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.07)' }}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.06 }}
                >
                  <span style={{ color: error.accent, fontSize: 14, lineHeight: 1.6, flexShrink: 0 }}>💬</span>
                  <p className="text-xs text-zinc-300 leading-relaxed flex-1 italic">"{line}"</p>
                  <button
                    onClick={() => handleCopy(line, i)}
                    className="shrink-0 text-[10px] font-medium px-2 py-1 rounded-lg transition-colors"
                    style={{
                      background: copiedLine === i ? `${error.accent}33` : 'rgba(255,255,255,0.06)',
                      color: copiedLine === i ? error.accent : '#71717a',
                      border: `1px solid ${copiedLine === i ? error.accent + '55' : 'transparent'}`,
                    }}
                  >
                    {copiedLine === i ? '✓' : 'Copy'}
                  </button>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

export default function ErrorStatements() {
  const [openId, setOpenId] = useState(null);

  return (
    <div className="h-full overflow-y-auto bg-zinc-950 px-4 py-6 space-y-4">
      {/* Header */}
      <div className="space-y-1 mb-6">
        <div className="flex items-center gap-2">
          <span style={{ fontSize: 22, filter: 'drop-shadow(0 0 8px #C400FF)' }}>💬</span>
          <h2 className="text-base font-bold text-zinc-100">Error Statements</h2>
        </div>
        <p className="text-xs text-zinc-500 leading-relaxed">
          Playful lines your Naughty Navigator uses when things go wrong.
        </p>
      </div>

      {/* Cards */}
      <div className="space-y-3">
        {ERRORS.map((error) => (
          <ErrorCard
            key={error.id}
            error={error}
            isOpen={openId === error.id}
            onToggle={() => setOpenId(openId === error.id ? null : error.id)}
          />
        ))}
      </div>

      {/* Footer */}
      <div
        className="rounded-2xl px-4 py-4 text-center mt-2"
        style={{ background: 'rgba(196,0,255,0.06)', border: '1px solid rgba(196,0,255,0.2)' }}
      >
        <p className="text-xs italic" style={{ color: '#9B60CC' }}>
          "Even my bad days sound better than your GPS."
        </p>
      </div>
    </div>
  );
}