import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

const TABS = [
  { id: 'navigate', label: 'Navigate', emoji: '🧭' },
  { id: 'trips', label: 'Trips', emoji: '📍' },
  { id: 'voice', label: 'Voice', emoji: '💋' },
  { id: 'map', label: 'Map', emoji: '🗺️' },
  { id: 'members', label: 'Members', emoji: '👑', highlight: true },
  { id: 'settings', label: 'Settings', emoji: '✨' },
];

export default function BottomTabBar({ activeTab, onTabChange }) {
  return (
    <div
      className="flex items-center justify-around px-1"
      style={{
        paddingBottom: 'max(0.6rem, var(--safe-area-inset-bottom))',
        paddingTop: '0.5rem',
        background: 'rgba(10,0,20,0.97)',
        borderTop: '1px solid rgba(196,0,255,0.2)',
        backdropFilter: 'blur(20px)',
      }}
    >
      {TABS.map(({ id, label, emoji, highlight }) => {
        const active = activeTab === id;
        const isGold = highlight;
        return (
          <motion.button
            key={`${id}-${label}`}
            onClick={() => onTabChange(id)}
            className="flex flex-col items-center gap-0.5 px-2 py-1 rounded-2xl relative"
            whileTap={{ scale: 0.88 }}
            style={{ minWidth: 44 }}
          >
            {/* Active glow pill */}
            {active && (
              <motion.div
                layoutId="tab-pill"
                className="absolute inset-0 rounded-2xl"
                style={{
                  background: isGold
                    ? 'rgba(255,215,0,0.12)'
                    : 'rgba(196,0,255,0.15)',
                  border: isGold
                    ? '1px solid rgba(255,215,0,0.35)'
                    : '1px solid rgba(255,0,230,0.4)',
                  boxShadow: isGold
                    ? '0 0 12px rgba(255,215,0,0.3)'
                    : '0 0 12px rgba(196,0,255,0.4)',
                }}
                transition={{ type: 'spring', stiffness: 400, damping: 30 }}
              />
            )}
            <motion.span
              className="text-xl relative z-10"
              animate={active ? { scale: [1, 1.25, 1] } : { scale: 1 }}
              transition={{ duration: 0.35 }}
              style={{
                filter: active
                  ? isGold
                    ? 'drop-shadow(0 0 6px rgba(255,215,0,0.9))'
                    : 'drop-shadow(0 0 6px rgba(255,0,230,0.9))'
                  : 'none',
              }}
            >
              {emoji}
            </motion.span>
            <span
              className="text-[9px] font-bold relative z-10 tracking-wide"
              style={{
                color: active
                  ? isGold ? '#FFD700' : '#FF00E6'
                  : isGold ? 'rgba(255,215,0,0.5)' : 'rgba(180,120,220,0.45)',
              }}
            >
              {label}
            </span>
          </motion.button>
        );
      })}
    </div>
  );
}