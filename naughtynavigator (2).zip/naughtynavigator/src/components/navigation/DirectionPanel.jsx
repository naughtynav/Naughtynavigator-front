import React from 'react';
import { Volume2, VolumeX } from 'lucide-react';

export default function DirectionPanel({ currentComment, isMuted, onToggleMute }) {
  return (
    <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-2xl p-4 flex items-start gap-3 relative overflow-hidden">
      <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-pink-500/30 to-transparent" />
      <div className="flex-1 min-w-0">
        <p className="text-sm text-zinc-300 leading-relaxed italic">"{currentComment}"</p>
      </div>
      <button
        onClick={onToggleMute}
        className="shrink-0 h-8 w-8 rounded-lg bg-zinc-800 hover:bg-zinc-700 flex items-center justify-center text-zinc-400 hover:text-zinc-200 transition-colors mt-0.5"
      >
        {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
      </button>
    </div>
  );
}