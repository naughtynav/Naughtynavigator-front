import React, { useState, useCallback } from 'react';
import RecentTrips from './RecentTrips';
import usePullToRefresh from '../../lib/usePullToRefresh';

export default function TripsTab({ onNavigateTo }) {
  const [trips, setTrips] = useState(() => {
    try { return JSON.parse(localStorage.getItem('nn_trips') || '[]'); } catch { return []; }
  });

  const loadTrips = useCallback(async () => {
    try {
      const fresh = JSON.parse(localStorage.getItem('nn_trips') || '[]');
      setTrips(fresh);
    } catch {}
  }, []);

  const { scrollRef, pullY, refreshing } = usePullToRefresh(loadTrips);

  return (
    <div
      ref={scrollRef}
      className="h-full overflow-y-auto"
      style={{ background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 100%)' }}
    >
      {/* Pull indicator */}
      {(pullY > 0 || refreshing) && (
        <div className="flex justify-center py-3" style={{ height: pullY || (refreshing ? 48 : 0), overflow: 'hidden', transition: 'height 0.2s' }}>
          <span style={{ fontSize: 20, animation: refreshing ? 'spin 1s linear infinite' : 'none' }}>
            {refreshing ? '🔄' : '↓'}
          </span>
        </div>
      )}

      <div className="px-4 py-6 pb-10">
        <p className="text-[10px] uppercase tracking-widest font-semibold mb-4 px-1" style={{ color: 'rgba(196,0,255,0.55)' }}>
          Trip History
        </p>
        <RecentTrips trips={trips} onNavigateTo={onNavigateTo} />
      </div>
    </div>
  );
}