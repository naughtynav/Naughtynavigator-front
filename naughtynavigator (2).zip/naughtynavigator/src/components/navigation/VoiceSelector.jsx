import React from 'react';

const VOICES = [
  { id: 'sultry', label: 'Sultry', emoji: '💋' },
  { id: 'daddy', label: 'Daddy', emoji: '😈' },
  { id: 'smooth', label: 'Smooth', emoji: '🎷' },
  { id: 'spicy', label: 'Spicy', emoji: '🌶️' },
];

export default function VoiceSelector({ selectedVoice, onSelect }) {
  return (
    <div className="space-y-2">
      <p className="text-xs text-zinc-500 font-medium uppercase tracking-widest px-1">Voice</p>
      <div className="grid grid-cols-4 gap-2">
        {VOICES.map(({ id, label, emoji }) => (
          <button
            key={id}
            onClick={() => onSelect(id)}
            className={`flex flex-col items-center gap-1.5 py-3 rounded-2xl border transition-all duration-200 active:scale-95
              ${selectedVoice === id
                ? 'border-pink-500/40 bg-pink-500/10 text-pink-300'
                : 'border-zinc-800 bg-zinc-900 text-zinc-500 hover:border-zinc-700'
              }`}
          >
            <span className="text-xl">{emoji}</span>
            <span className="text-[10px] font-medium">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}