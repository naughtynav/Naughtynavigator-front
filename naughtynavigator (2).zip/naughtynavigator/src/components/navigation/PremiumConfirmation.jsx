import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const UNLOCKED = [
  { emoji: '💋', label: 'Voice Packs' },
  { emoji: '🎭', label: 'Mood Navigation' },
  { emoji: '💬', label: 'Personality Boosters' },
  { emoji: '🎨', label: 'Neon Themes' },
  { emoji: '🚫', label: 'No Ads' },
];

// Simple floating particle
function Particle({ x, y, delay }) {
  return (
    <motion.div
      className="absolute rounded-full pointer-events-none"
      style={{
        left: `${x}%`,
        top: `${y}%`,
        width: 6,
        height: 6,
        background: 'rgba(196,0,255,0.7)',
        boxShadow: '0 0 8px #C400FF',
      }}
      initial={{ opacity: 0, scale: 0 }}
      animate={{
        opacity: [0, 0.8, 0],
        scale: [0, 1.5, 0],
        y: [0, -40, -80],
      }}
      transition={{
        duration: 2.5,
        delay,
        repeat: Infinity,
        ease: 'easeOut',
      }}
    />
  );
}

const PARTICLES = Array.from({ length: 12 }, (_, i) => ({
  id: i,
  x: 5 + (i * 8) % 90,
  y: 20 + (i * 13) % 70,
  delay: i * 0.2,
}));

export default function PremiumConfirmation({ onDone }) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    setVisible(true);
  }, []);

  return (
    <div
      className="relative flex flex-col items-center justify-center h-full overflow-hidden"
      style={{ background: 'linear-gradient(160deg, #2A0038 0%, #1A0024 55%, #0D0015 100%)' }}
    >
      {/* Slow moving ambient glow */}
      <motion.div
        className="absolute inset-0 pointer-events-none"
        animate={{
          background: [
            'radial-gradient(ellipse at 40% 30%, rgba(196,0,255,0.18) 0%, transparent 60%)',
            'radial-gradient(ellipse at 60% 50%, rgba(140,0,200,0.22) 0%, transparent 60%)',
            'radial-gradient(ellipse at 45% 25%, rgba(196,0,255,0.18) 0%, transparent 60%)',
          ],
        }}
        transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut' }}
      />

      {/* Particles */}
      {PARTICLES.map(p => <Particle key={p.id} {...p} />)}

      {/* Crown + Heart */}
      <div className="relative z-10 flex flex-col items-center mb-6">
        {/* Glow halo */}
        <motion.div
          className="absolute rounded-full"
          style={{
            width: 120,
            height: 120,
            background: 'radial-gradient(circle, rgba(196,0,255,0.35) 0%, transparent 70%)',
          }}
          animate={{ scale: [1, 1.3, 1], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.div
          className="relative text-6xl"
          style={{ filter: 'drop-shadow(0 0 24px #C400FF)' }}
          animate={{ scale: [1, 1.12, 1], rotate: [-3, 3, -3] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
        >
          👑
        </motion.div>
        <motion.div
          className="text-3xl -mt-2"
          style={{ filter: 'drop-shadow(0 0 12px #FF00AA)' }}
          animate={{ scale: [1, 1.2, 1] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut', delay: 0.4 }}
        >
          💜
        </motion.div>
      </div>

      {/* Header */}
      <motion.div
        className="relative z-10 text-center px-6 mb-5"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
      >
        <h1
          className="text-2xl font-bold text-white leading-tight mb-2"
          style={{ textShadow: '0 0 20px rgba(196,0,255,0.9), 0 0 40px rgba(196,0,255,0.4)' }}
        >
          Welcome to Naughty Navigator Premium
        </h1>
        <p className="text-sm font-medium" style={{ color: '#E0A0FF' }}>
          You're officially upgraded, gorgeous.
        </p>
        <p className="text-sm mt-1" style={{ color: '#C890E8' }}>
          Let's make every ride unforgettable.
        </p>
      </motion.div>

      {/* Unlocked features */}
      <motion.div
        className="relative z-10 w-full px-6 mb-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <p className="text-xs font-semibold tracking-widest uppercase text-center mb-3" style={{ color: '#C400FF' }}>
          Premium features unlocked
        </p>
        <div
          className="rounded-2xl px-4 py-3 space-y-2"
          style={{
            background: 'rgba(196,0,255,0.07)',
            border: '1px solid rgba(196,0,255,0.35)',
            boxShadow: '0 0 20px rgba(196,0,255,0.1) inset',
          }}
        >
          {UNLOCKED.map(({ emoji, label }, i) => (
            <motion.div
              key={label}
              className="flex items-center gap-3"
              initial={{ opacity: 0, x: -16 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: 0.5 + i * 0.08 }}
            >
              <span className="text-lg" style={{ filter: 'drop-shadow(0 0 6px #C400FF)' }}>{emoji}</span>
              <span className="text-sm font-medium text-white">{label}</span>
              <motion.span
                className="ml-auto text-xs font-bold"
                style={{ color: '#C400FF' }}
                animate={{ opacity: [0.6, 1, 0.6] }}
                transition={{ duration: 1.5, repeat: Infinity, delay: i * 0.1 }}
              >
                ✓
              </motion.span>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* CTA Button */}
      <motion.div
        className="relative z-10 w-full px-6"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.9 }}
      >
        <motion.button
          onClick={onDone}
          className="w-full rounded-2xl text-white font-bold text-base tracking-wide"
          style={{
            background: 'linear-gradient(135deg, #8B00CC 0%, #C400FF 60%, #9B00DD 100%)',
            height: '52px',
            boxShadow: '0 0 24px rgba(196,0,255,0.6), 0 0 48px rgba(196,0,255,0.25)',
          }}
          animate={{
            boxShadow: [
              '0 0 20px rgba(196,0,255,0.5)',
              '0 0 40px rgba(196,0,255,0.9)',
              '0 0 20px rgba(196,0,255,0.5)',
            ],
          }}
          transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
          whileTap={{ scale: 0.97 }}
        >
          ✨ Start Exploring Premium
        </motion.button>
        <p className="text-center text-xs italic mt-2" style={{ color: '#9B60CC' }}>
          "I've been waiting to show you what I can really do…"
        </p>
      </motion.div>
    </div>
  );
}