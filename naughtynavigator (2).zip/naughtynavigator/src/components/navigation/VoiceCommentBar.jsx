import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Volume2, VolumeX } from 'lucide-react';

export default function VoiceCommentBar({ comment, isMuted, onToggleMute }) {
  if (!comment) return null;

  return (
    <AnimatePresence>
      <motion.div
        key={comment}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.35 }}
        className="flex items-center gap-3 px-4 py-3 rounded-2xl"
        style={{
          background: 'rgba(26,0,40,0.92)',
          border: '1px solid rgba(196,0,255,0.35)',
          boxShadow: '0 0 18px rgba(196,0,255,0.2)',
          backdropFilter: 'blur(12px)',
        }}
      >
        {/* Pulsing mic dot */}
        <motion.div
          className="shrink-0 w-2 h-2 rounded-full"
          style={{ background: isMuted ? '#555' : '#C400FF' }}
          animate={isMuted ? {} : { scale: [1, 1.4, 1], opacity: [1, 0.6, 1] }}
          transition={{ duration: 1.2, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* Comment text */}
        <p className="flex-1 text-xs leading-snug italic" style={{ color: 'rgba(237,217,255,0.88)' }}>
          {isMuted ? '🔇 Voice muted' : `"${comment}"`}
        </p>

        {/* Mute toggle */}
        <button
          onClick={onToggleMute}
          className="shrink-0 w-7 h-7 rounded-xl flex items-center justify-center"
          style={{
            background: isMuted ? 'rgba(255,255,255,0.06)' : 'rgba(196,0,255,0.15)',
            border: isMuted ? '1px solid rgba(255,255,255,0.1)' : '1px solid rgba(196,0,255,0.4)',
          }}
        >
          {isMuted
            ? <VolumeX className="w-3.5 h-3.5" style={{ color: '#666' }} />
            : <Volume2 className="w-3.5 h-3.5" style={{ color: '#C400FF' }} />
          }
        </button>
      </motion.div>
    </AnimatePresence>
  );
}