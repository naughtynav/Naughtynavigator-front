import React from 'react';
import { MapPin, Clock, ChevronUp } from 'lucide-react';
import { motion } from 'framer-motion';
import { format } from 'date-fns';

export default function RecentTrips({ trips = [], onNavigateTo }) {
  if (trips.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-12 text-center space-y-4 px-6">

        {/* Clock icon with neon glow halo */}
        <div className="relative flex items-center justify-center">
          <div className="absolute rounded-full"
            style={{ width: 72, height: 72, background: 'radial-gradient(circle, rgba(196,0,255,0.25) 0%, rgba(255,110,179,0.12) 50%, transparent 75%)' }} />
          <div className="relative h-16 w-16 rounded-2xl flex items-center justify-center"
            style={{ background: 'rgba(196,0,255,0.08)', border: '1px solid rgba(196,0,255,0.25)', boxShadow: '0 0 18px rgba(196,0,255,0.2), 0 0 6px rgba(255,110,179,0.2)' }}>
            <Clock className="w-7 h-7" style={{ color: '#C400FF' }} />
          </div>
        </div>

        <p className="text-sm font-semibold" style={{ color: '#E8CCFF' }}>
          Your journey history will show up here, babe.
        </p>

        <div className="space-y-1">
          <p className="text-xs" style={{ color: 'rgba(217,166,255,0.5)' }}>No trips yet — your story's just getting started.</p>
          <p className="text-xs italic" style={{ color: 'rgba(196,0,255,0.5)' }}>Let's make some memories. 💜</p>
        </div>

        {onNavigateTo && (
          <motion.button
            onClick={() => onNavigateTo(null)}
            className="mt-2 px-6 h-11 rounded-2xl text-white text-sm font-bold tracking-wide"
            style={{
              background: 'linear-gradient(135deg,#C400FF 0%,#FF00E6 100%)',
              boxShadow: '0 0 18px rgba(196,0,255,0.6)',
            }}
            animate={{ boxShadow: ['0 0 12px rgba(196,0,255,0.4)', '0 0 24px rgba(196,0,255,0.8)', '0 0 12px rgba(196,0,255,0.4)'] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            whileTap={{ scale: 0.96 }}
          >
            Start Navigating ✦
          </motion.button>
        )}

        <motion.div
          className="flex flex-col items-center gap-1 mt-2 opacity-40"
          animate={{ y: [0, -4, 0] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut' }}
        >
          <ChevronUp className="w-4 h-4" style={{ color: '#D9A6FF' }} />
          <span className="text-[10px]" style={{ color: '#D9A6FF' }}>Tap Navigate to begin</span>
        </motion.div>

      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {trips.map((trip, i) => (
        <motion.div
          key={i}
          className="flex items-center gap-4 px-4 py-3 rounded-2xl"
          style={{ background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(196,0,255,0.15)' }}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.05 }}
        >
          <div className="h-10 w-10 rounded-xl flex items-center justify-center shrink-0"
            style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)' }}>
            <MapPin className="w-4 h-4" style={{ color: '#C400FF' }} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-semibold truncate" style={{ color: '#E8CCFF' }}>{trip.destination}</p>
            <p className="text-[11px] mt-0.5" style={{ color: 'rgba(217,166,255,0.45)' }}>
              {trip.date ? format(new Date(trip.date), 'MMM d, yyyy') : ''}{trip.duration ? ` · ${trip.duration}` : ''}{trip.distance ? ` · ${trip.distance}` : ''}
            </p>
          </div>
        </motion.div>
      ))}
    </div>
  );
}