import React from 'react';
import { motion } from 'framer-motion';
import { Navigation, Clock, MapPin } from 'lucide-react';

export default function SimulatedRoute({ destination, step, totalSteps }) {
  if (!destination) return null;

  const progress = totalSteps > 0 ? ((step + 1) / totalSteps) * 100 : 0;

  return (
    <div className="bg-zinc-900/80 backdrop-blur border border-zinc-800 rounded-xl p-4 space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="h-8 w-8 rounded-lg bg-pink-500/10 flex items-center justify-center">
            <Navigation className="w-4 h-4 text-pink-400" />
          </div>
          <div>
            <p className="text-xs text-zinc-500">Navigating to</p>
            <p className="text-sm font-medium text-zinc-200 truncate max-w-[180px]">{destination}</p>
          </div>
        </div>
        <div className="text-right">
          <div className="flex items-center gap-1 text-zinc-500">
            <Clock className="w-3 h-3" />
            <span className="text-xs">{Math.max(1, totalSteps - step)} min</span>
          </div>
        </div>
      </div>

      <div className="relative">
        <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-pink-500 to-purple-500 rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          />
        </div>
        <div className="flex justify-between mt-1.5">
          <span className="text-[10px] text-zinc-600">Start</span>
          <span className="text-[10px] text-zinc-600 flex items-center gap-0.5">
            <MapPin className="w-2.5 h-2.5" /> Destination
          </span>
        </div>
      </div>
    </div>
  );
}