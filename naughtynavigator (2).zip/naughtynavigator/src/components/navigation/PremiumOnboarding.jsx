import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

// ─── Data ────────────────────────────────────────────────────────────────────

const VOICES = [
  { id: 'sultry', emoji: '💋', label: 'Sultry Seduction', accent: '#FF00E6', preview: 'Oh, take a left here, gorgeous…' },
  { id: 'daddy', emoji: '👑', label: 'Dominant Daddy', accent: '#C400FF', preview: 'I said turn right. Now.' },
  { id: 'smooth', emoji: '🕶️', label: 'Smooth Operator', accent: '#D9A6FF', preview: 'Slide right onto the highway, baby.' },
  { id: 'spicy', emoji: '🔥', label: 'Spicy Trouble', accent: '#FF4DFF', preview: "Keep up, or I'll reroute your life." },
];

const MOODS = [
  { id: 'naughty', emoji: '😈', label: 'Naughty', color: '#FF4DFF' },
  { id: 'chill', emoji: '😌', label: 'Chill', color: '#D9A6FF' },
  { id: 'savage', emoji: '🔥', label: 'Savage', color: '#FF2222' },
  { id: 'romantic', emoji: '💖', label: 'Romantic', color: '#FF6EB3' },
];

// ─── Shared helpers ───────────────────────────────────────────────────────────

const BG = { background: 'linear-gradient(180deg, #1A0024 0%, #0D0015 100%)' };

function NeonButton({ onClick, children, style = {} }) {
  return (
    <motion.button
      onClick={onClick}
      className="w-full text-white font-bold text-base tracking-wide rounded-3xl"
      style={{
        height: 54,
        background: '#C400FF',
        boxShadow: '0 0 24px rgba(196,0,255,0.7)',
        border: 'none',
        cursor: 'pointer',
        ...style,
      }}
      animate={{ boxShadow: ['0 0 18px rgba(196,0,255,0.5)', '0 0 40px rgba(196,0,255,1)', '0 0 18px rgba(196,0,255,0.5)'] }}
      transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
      whileTap={{ scale: 0.97 }}
    >
      {children}
    </motion.button>
  );
}

function StepDots({ total, current }) {
  return (
    <div className="flex items-center justify-center gap-2 mb-6">
      {Array.from({ length: total }).map((_, i) => (
        <motion.div
          key={i}
          animate={{ width: i === current ? 20 : 6, background: i === current ? '#C400FF' : 'rgba(196,0,255,0.3)' }}
          transition={{ duration: 0.3 }}
          style={{ height: 6, borderRadius: 3 }}
        />
      ))}
    </div>
  );
}

// ─── Slide transition wrapper ─────────────────────────────────────────────────

const slideVariants = {
  enter: (dir) => ({ x: dir > 0 ? '100%' : '-100%', opacity: 0 }),
  center: { x: 0, opacity: 1 },
  exit: (dir) => ({ x: dir > 0 ? '-100%' : '100%', opacity: 0 }),
};

// ─── Screen 1: Welcome ────────────────────────────────────────────────────────

function ScreenWelcome({ onNext }) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-6 text-center">
      {/* Ambient glow */}
      <div className="absolute inset-0 pointer-events-none" style={{
        background: 'radial-gradient(ellipse at 50% 30%, rgba(196,0,255,0.25) 0%, transparent 65%)',
      }} />

      <motion.div
        className="relative z-10 flex flex-col items-center mb-8"
        initial={{ opacity: 0, scale: 0.7 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
      >
        {/* Halo */}
        <motion.div
          className="absolute rounded-full"
          style={{ width: 130, height: 130, background: 'radial-gradient(circle, rgba(196,0,255,0.4) 0%, transparent 70%)' }}
          animate={{ scale: [1, 1.3, 1], opacity: [0.6, 1, 0.6] }}
          transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
        />
        <motion.span
          style={{ fontSize: 68, filter: 'drop-shadow(0 0 28px #C400FF)' }}
          animate={{ scale: [1, 1.08, 1], rotate: [-2, 2, -2] }}
          transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
        >👑</motion.span>
        <motion.span
          style={{ fontSize: 36, marginTop: -8, filter: 'drop-shadow(0 0 14px #FF00AA)' }}
          animate={{ scale: [1, 1.18, 1] }}
          transition={{ duration: 1.8, repeat: Infinity, ease: 'easeInOut', delay: 0.3 }}
        >💜</motion.span>
      </motion.div>

      <motion.div
        className="relative z-10 mb-10"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <h1 style={{ fontSize: 28, fontWeight: 800, color: '#FFFFFF', textShadow: '0 0 20px rgba(196,0,255,0.9)', lineHeight: 1.2, marginBottom: 12 }}>
          Welcome to Premium,<br />gorgeous.
        </h1>
        <p style={{ fontSize: 15, color: '#D9A6FF', lineHeight: 1.6 }}>
          Let's set you up for the most seductive ride of your life. This'll only take a second.
        </p>
      </motion.div>

      <motion.div
        className="relative z-10 w-full"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.4 }}
      >
        <NeonButton onClick={onNext}>Continue ✨</NeonButton>
      </motion.div>
    </div>
  );
}

// ─── Screen 2: Choose Voice ───────────────────────────────────────────────────

function ScreenVoice({ onNext, selectedVoice, onSelectVoice }) {
  const [previewing, setPreviewing] = useState(null);

  const handlePreview = (v) => {
    setPreviewing(v.id);
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      const utt = new SpeechSynthesisUtterance(v.preview);
      utt.rate = 0.9;
      utt.pitch = v.id === 'daddy' ? 0.6 : v.id === 'smooth' ? 0.85 : 1.1;
      utt.onend = () => setPreviewing(null);
      window.speechSynthesis.speak(utt);
    }
    onSelectVoice(v.id);
  };

  return (
    <div className="flex flex-col h-full px-6 pt-4 pb-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#C400FF', marginBottom: 6 }}>
          Step 2 of 4
        </p>
        <h2 style={{ fontSize: 24, fontWeight: 800, color: '#FFFFFF', marginBottom: 4 }}>Choose Your Voice</h2>
        <p style={{ fontSize: 13, color: '#9B60CC', marginBottom: 20 }}>Tap to preview. Select your favorite co‑pilot.</p>
      </motion.div>

      <div className="flex flex-col gap-3 flex-1">
        {VOICES.map((v, i) => {
          const selected = selectedVoice === v.id;
          const isPlaying = previewing === v.id;
          return (
            <motion.button
              key={v.id}
              onClick={() => handlePreview(v)}
              className="flex items-center gap-4 text-left w-full"
              style={{
                background: selected ? 'rgba(196,0,255,0.14)' : 'rgba(255,255,255,0.04)',
                border: selected ? `1.5px solid ${v.accent}` : '1px solid rgba(196,0,255,0.2)',
                boxShadow: selected ? `0 0 18px ${v.accent}44` : 'none',
                borderRadius: 18,
                padding: '14px 16px',
                cursor: 'pointer',
                transition: 'all 0.2s ease',
              }}
              initial={{ opacity: 0, x: -16 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.3, delay: i * 0.07 }}
              whileTap={{ scale: 0.98 }}
            >
              <motion.div
                style={{
                  width: 52, height: 52, borderRadius: '50%',
                  background: '#2A0038',
                  border: `2px solid ${v.accent}`,
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 24, flexShrink: 0,
                }}
                animate={isPlaying ? { scale: [1, 1.12, 1] } : {}}
                transition={{ duration: 0.6, repeat: isPlaying ? Infinity : 0 }}
              >
                {v.emoji}
              </motion.div>
              <div className="flex-1 min-w-0">
                <p style={{ fontSize: 14, fontWeight: 700, color: selected ? '#FFFFFF' : '#C890E8', marginBottom: 2 }}>{v.label}</p>
                <p style={{ fontSize: 11, color: '#7A4499', lineHeight: 1.4, fontStyle: 'italic' }}>"{v.preview}"</p>
              </div>
              <div style={{
                width: 22, height: 22, borderRadius: '50%', flexShrink: 0,
                border: selected ? `2px solid ${v.accent}` : '2px solid rgba(196,0,255,0.3)',
                background: selected ? v.accent : 'transparent',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                transition: 'all 0.2s ease',
              }}>
                {selected && <span style={{ fontSize: 10, color: '#fff', fontWeight: 700 }}>✓</span>}
              </div>
            </motion.button>
          );
        })}
      </div>

      <div className="mt-5">
        <NeonButton onClick={onNext}>Next →</NeonButton>
      </div>
    </div>
  );
}

// ─── Screen 3: Pick Mood ──────────────────────────────────────────────────────

function ScreenMood({ onNext, selectedMood, onSelectMood }) {
  return (
    <div className="flex flex-col h-full px-6 pt-4 pb-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#C400FF', marginBottom: 6 }}>
          Step 3 of 4
        </p>
        <h2 style={{ fontSize: 24, fontWeight: 800, color: '#FFFFFF', marginBottom: 4 }}>Pick Your Mood</h2>
        <p style={{ fontSize: 13, color: '#9B60CC', marginBottom: 24 }}>How are we riding today?</p>
      </motion.div>

      <div className="grid grid-cols-2 gap-4 flex-1 content-start">
        {MOODS.map((m, i) => {
          const selected = selectedMood === m.id;
          return (
            <motion.button
              key={m.id}
              onClick={() => onSelectMood(m.id)}
              className="flex flex-col items-center justify-center gap-2"
              style={{
                background: selected ? `${m.color}22` : 'rgba(255,255,255,0.04)',
                border: selected ? `1.5px solid ${m.color}` : '1px solid rgba(196,0,255,0.2)',
                boxShadow: selected ? `0 0 20px ${m.color}55` : 'none',
                borderRadius: 20,
                padding: '28px 16px',
                cursor: 'pointer',
                transition: 'all 0.25s ease',
                minHeight: 110,
              }}
              initial={{ opacity: 0, scale: 0.85 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.35, delay: i * 0.07 }}
              whileTap={{ scale: 0.95 }}
            >
              <motion.span
                style={{ fontSize: 36, filter: selected ? `drop-shadow(0 0 10px ${m.color})` : 'none' }}
                animate={selected ? { scale: [1, 1.15, 1] } : {}}
                transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
              >
                {m.emoji}
              </motion.span>
              <p style={{ fontSize: 14, fontWeight: 700, color: selected ? '#FFFFFF' : '#C890E8' }}>{m.label}</p>
            </motion.button>
          );
        })}
      </div>

      <div className="mt-6">
        <NeonButton onClick={onNext}>Next →</NeonButton>
      </div>
    </div>
  );
}

// ─── Screen 4: Neon Map ───────────────────────────────────────────────────────

function ScreenNeonMap({ onNext, neonEnabled, onToggle }) {
  return (
    <div className="flex flex-col h-full px-6 pt-4 pb-6">
      <motion.div initial={{ opacity: 0, y: -12 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
        <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase', color: '#C400FF', marginBottom: 6 }}>
          Step 4 of 4
        </p>
        <h2 style={{ fontSize: 24, fontWeight: 800, color: '#FFFFFF', marginBottom: 4 }}>Enable Neon Map</h2>
        <p style={{ fontSize: 13, color: '#9B60CC', marginBottom: 20 }}>Give your map a cyber‑seductive glow.</p>
      </motion.div>

      {/* Map preview */}
      <motion.div
        className="relative rounded-2xl overflow-hidden mb-6 flex-1"
        style={{
          background: 'linear-gradient(135deg, #0D0015 0%, #1A0024 50%, #0D0015 100%)',
          border: neonEnabled ? '1.5px solid rgba(196,0,255,0.7)' : '1px solid rgba(196,0,255,0.2)',
          boxShadow: neonEnabled ? '0 0 30px rgba(196,0,255,0.35)' : 'none',
          minHeight: 160,
          transition: 'all 0.4s ease',
        }}
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, delay: 0.15 }}
      >
        {/* Simulated neon map roads */}
        <svg width="100%" height="100%" viewBox="0 0 300 180" preserveAspectRatio="xMidYMid slice">
          {/* Land */}
          <rect width="300" height="180" fill="#0D0015" />
          {/* Water blob */}
          <ellipse cx="240" cy="140" rx="80" ry="50" fill="#1A0024" />
          {/* Roads */}
          <line x1="0" y1="90" x2="300" y2="90" stroke={neonEnabled ? '#D9A6FF' : '#444'} strokeWidth={neonEnabled ? 2.5 : 1.5}
            style={{ filter: neonEnabled ? 'drop-shadow(0 0 4px #D9A6FF)' : 'none' }} />
          <line x1="150" y1="0" x2="150" y2="180" stroke={neonEnabled ? '#D9A6FF' : '#444'} strokeWidth={neonEnabled ? 2 : 1.5}
            style={{ filter: neonEnabled ? 'drop-shadow(0 0 4px #D9A6FF)' : 'none' }} />
          <line x1="0" y1="40" x2="300" y2="140" stroke={neonEnabled ? '#C400FF' : '#555'} strokeWidth={neonEnabled ? 4 : 2}
            style={{ filter: neonEnabled ? 'drop-shadow(0 0 8px #C400FF)' : 'none' }} />
          <line x1="0" y1="140" x2="300" y2="50" stroke={neonEnabled ? '#C400FF' : '#555'} strokeWidth={neonEnabled ? 3.5 : 2}
            style={{ filter: neonEnabled ? 'drop-shadow(0 0 6px #C400FF)' : 'none' }} />
          {/* Route line */}
          <polyline points="30,150 80,110 130,90 180,70 250,45" fill="none"
            stroke={neonEnabled ? '#FF4DFF' : '#ec4899'} strokeWidth={neonEnabled ? 3.5 : 2}
            strokeLinecap="round" strokeLinejoin="round"
            style={{ filter: neonEnabled ? 'drop-shadow(0 0 6px #FF4DFF)' : 'none' }} />
          {/* POIs */}
          {neonEnabled && <>
            <circle cx="80" cy="110" r="5" fill="#FF4DFF" style={{ filter: 'drop-shadow(0 0 5px #FF4DFF)' }} />
            <circle cx="180" cy="70" r="5" fill="#FF4DFF" style={{ filter: 'drop-shadow(0 0 5px #FF4DFF)' }} />
          </>}
          {/* Labels */}
          <text x="60" y="86" fontSize="8" fill={neonEnabled ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.3)'} fontFamily="sans-serif">Main St</text>
          <text x="155" y="60" fontSize="8" fill={neonEnabled ? 'rgba(255,255,255,0.7)' : 'rgba(255,255,255,0.3)'} fontFamily="sans-serif">5th Ave</text>
        </svg>
        {/* Neon mode badge */}
        {neonEnabled && (
          <motion.div
            className="absolute bottom-3 right-3 flex items-center gap-1 px-2 py-1 rounded-lg"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            style={{ background: 'rgba(26,0,36,0.85)', border: '1px solid rgba(196,0,255,0.6)', boxShadow: '0 0 10px rgba(196,0,255,0.4)' }}
          >
            <span style={{ fontSize: 9 }}>🗺️</span>
            <span style={{ fontSize: 8, fontWeight: 700, color: '#C400FF', letterSpacing: '0.1em' }}>NEON MODE</span>
          </motion.div>
        )}
      </motion.div>

      {/* Toggle */}
      <motion.div
        className="flex items-center justify-between rounded-2xl px-5 py-4 mb-6"
        style={{
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid rgba(196,0,255,0.25)',
        }}
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.2 }}
      >
        <div>
          <p style={{ fontSize: 14, fontWeight: 700, color: '#FFFFFF', marginBottom: 2 }}>Neon Map Mode</p>
          <p style={{ fontSize: 11, color: '#7A4499' }}>Cyber‑purple glow on all roads</p>
        </div>
        <button
          onClick={onToggle}
          style={{
            width: 52, height: 28, borderRadius: 14,
            background: neonEnabled ? '#C400FF' : 'rgba(255,255,255,0.12)',
            boxShadow: neonEnabled ? '0 0 16px rgba(196,0,255,0.7)' : 'none',
            border: 'none', cursor: 'pointer',
            position: 'relative', transition: 'all 0.3s ease',
          }}
        >
          <motion.div
            animate={{ left: neonEnabled ? 26 : 4 }}
            transition={{ duration: 0.25 }}
            style={{
              position: 'absolute', top: 4,
              width: 20, height: 20, borderRadius: '50%',
              background: '#FFFFFF',
              boxShadow: neonEnabled ? '0 0 8px rgba(196,0,255,0.8)' : 'none',
            }}
          />
        </button>
      </motion.div>

      <NeonButton onClick={onNext}>Finish 🎉</NeonButton>
    </div>
  );
}

// ─── Final Screen ─────────────────────────────────────────────────────────────

function ScreenFinal({ onDone }) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-6 text-center">
      <div className="absolute inset-0 pointer-events-none" style={{
        background: 'radial-gradient(ellipse at 50% 40%, rgba(196,0,255,0.22) 0%, transparent 65%)',
      }} />

      <motion.span
        className="relative z-10"
        style={{ fontSize: 72, filter: 'drop-shadow(0 0 30px #FF4DFF)' }}
        initial={{ opacity: 0, scale: 0.5 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
      >🪩</motion.span>

      <motion.div
        className="relative z-10 mt-6 mb-10"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <h1 style={{ fontSize: 30, fontWeight: 800, color: '#FFFFFF', textShadow: '0 0 20px rgba(196,0,255,0.9)', lineHeight: 1.2, marginBottom: 12 }}>
          You're all set,<br />baby.
        </h1>
        <p style={{ fontSize: 15, color: '#D9A6FF', lineHeight: 1.6 }}>
          Your Premium experience is ready. Let's make every turn a moment.
        </p>
      </motion.div>

      <motion.div
        className="relative z-10 w-full"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.4 }}
      >
        <NeonButton onClick={onDone}>Start Navigating 🗺️</NeonButton>
        <p style={{ fontSize: 12, fontStyle: 'italic', color: '#9B60CC', marginTop: 10 }}>
          "I've been waiting to show you what I can really do…"
        </p>
      </motion.div>
    </div>
  );
}

// ─── Main Onboarding ──────────────────────────────────────────────────────────

const TOTAL_STEPS = 4; // welcome, voice, mood, neon map (not counting final)

export default function PremiumOnboarding({ onDone }) {
  const [step, setStep] = useState(0);
  const [dir, setDir] = useState(1);
  const [selectedVoice, setSelectedVoice] = useState('sultry');
  const [selectedMood, setSelectedMood] = useState('naughty');
  const [neonEnabled, setNeonEnabled] = useState(true);

  const goNext = () => {
    setDir(1);
    setStep(s => s + 1);
  };

  const handleDone = () => {
    // Persist choices
    localStorage.setItem('nn_voice', selectedVoice);
    localStorage.setItem('nn_mood', selectedMood);
    localStorage.setItem('nn_neon_map', neonEnabled ? 'true' : 'false');
    onDone?.({ selectedVoice, selectedMood, neonEnabled });
  };

  const screens = [
    <ScreenWelcome onNext={goNext} />,
    <ScreenVoice onNext={goNext} selectedVoice={selectedVoice} onSelectVoice={setSelectedVoice} />,
    <ScreenMood onNext={goNext} selectedMood={selectedMood} onSelectMood={setSelectedMood} />,
    <ScreenNeonMap onNext={goNext} neonEnabled={neonEnabled} onToggle={() => setNeonEnabled(e => !e)} />,
    <ScreenFinal onDone={handleDone} />,
  ];

  const isFinal = step === screens.length - 1;

  return (
    <div
      className="relative flex flex-col h-full overflow-hidden"
      style={BG}
    >
      {/* Step dots (not on final) */}
      {!isFinal && (
        <div className="pt-5 pb-2 shrink-0">
          <StepDots total={TOTAL_STEPS} current={step} />
        </div>
      )}

      <AnimatePresence mode="wait" custom={dir}>
        <motion.div
          key={step}
          custom={dir}
          variants={slideVariants}
          initial="enter"
          animate="center"
          exit="exit"
          transition={{ duration: 0.35, ease: 'easeInOut' }}
          className="flex-1 overflow-y-auto"
          style={{ minHeight: 0 }}
        >
          {screens[step]}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}