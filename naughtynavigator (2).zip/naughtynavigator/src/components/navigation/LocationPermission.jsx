import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2, XCircle } from 'lucide-react';

const REASONS = [
  {
    emoji: '📍',
    title: 'Real-Time Positioning',
    desc: 'So I always know exactly where you are, gorgeous.',
  },
  {
    emoji: '🗺️',
    title: 'Route Calculation',
    desc: 'To plot the most seductive path to your destination.',
  },
  {
    emoji: '🔄',
    title: 'Live Rerouting',
    desc: 'If you go off-route, I\'ll find you a new way instantly.',
  },
  {
    emoji: '🔒',
    title: 'Stays on Your Device',
    desc: 'Your location is never stored or shared. Just between us.',
  },
];

export default function LocationPermission({ onGranted }) {
  const [status, setStatus] = useState('unknown'); // unknown | granted | denied | loading
  const [permissionState, setPermissionState] = useState(null);

  useEffect(() => {
    if (!navigator.permissions) return;
    navigator.permissions.query({ name: 'geolocation' }).then((result) => {
      setPermissionState(result.state);
      if (result.state === 'granted') setStatus('granted');
      if (result.state === 'denied') setStatus('denied');
      result.onchange = () => {
        setPermissionState(result.state);
        if (result.state === 'granted') setStatus('granted');
        if (result.state === 'denied') setStatus('denied');
      };
    });
  }, []);

  const handleEnable = () => {
    setStatus('loading');
    navigator.geolocation.getCurrentPosition(
      () => {
        setStatus('granted');
        onGranted?.();
      },
      () => setStatus('denied')
    );
  };

  const isGranted = status === 'granted';
  const isDenied = status === 'denied';
  const isLoading = status === 'loading';

  return (
    <div
      className="relative flex flex-col h-full overflow-y-auto px-5 py-6"
      style={{ background: 'linear-gradient(180deg, #1A0024 0%, #0D0015 100%)' }}
    >
      {/* Ambient glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background: 'radial-gradient(ellipse at 50% 20%, rgba(196,0,255,0.22) 0%, transparent 60%)',
        }}
      />

      {/* Icon */}
      <motion.div
        className="relative z-10 flex flex-col items-center mt-4 mb-6"
        initial={{ opacity: 0, scale: 0.7 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5, ease: [0.34, 1.56, 0.64, 1] }}
      >
        <div className="relative">
          <motion.div
            className="absolute rounded-full"
            style={{
              width: 110, height: 110,
              top: '50%', left: '50%',
              transform: 'translate(-50%,-50%)',
              background: 'radial-gradient(circle, rgba(196,0,255,0.35) 0%, transparent 70%)',
            }}
            animate={{ scale: [1, 1.3, 1], opacity: [0.6, 1, 0.6] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
          />
          <motion.span
            style={{ fontSize: 64, filter: 'drop-shadow(0 0 24px #C400FF)', display: 'block', position: 'relative', zIndex: 1 }}
            animate={{ scale: [1, 1.06, 1] }}
            transition={{ duration: 2.5, repeat: Infinity, ease: 'easeInOut' }}
          >
            📍
          </motion.span>
        </div>
      </motion.div>

      {/* Heading */}
      <motion.div
        className="relative z-10 text-center mb-6"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.1 }}
      >
        <h1 style={{ fontSize: 24, fontWeight: 800, color: '#FFFFFF', textShadow: '0 0 18px rgba(196,0,255,0.8)', lineHeight: 1.2, marginBottom: 8 }}>
          {isGranted ? 'Location Enabled ✓' : "Let me find you,\ngorgeous."}
        </h1>
        <p style={{ fontSize: 13, color: '#D9A6FF', lineHeight: 1.6 }}>
          {isGranted
            ? 'Naughty Navigator has access to your location and is ready to navigate.'
            : 'Naughty Navigator needs your location to guide you — no location, no navigation.'}
        </p>
      </motion.div>

      {/* Status pill */}
      {status !== 'unknown' && (
        <motion.div
          className="relative z-10 flex items-center justify-center gap-2 rounded-2xl px-4 py-3 mb-5 mx-auto"
          style={{
            background: isGranted ? 'rgba(34,197,94,0.12)' : isDenied ? 'rgba(239,68,68,0.12)' : 'rgba(196,0,255,0.12)',
            border: isGranted ? '1px solid rgba(34,197,94,0.35)' : isDenied ? '1px solid rgba(239,68,68,0.35)' : '1px solid rgba(196,0,255,0.35)',
            minWidth: 200,
          }}
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.3 }}
        >
          {isGranted && <CheckCircle2 className="w-4 h-4 text-green-400 shrink-0" />}
          {isDenied && <XCircle className="w-4 h-4 text-red-400 shrink-0" />}
          <p className="text-xs font-semibold"
            style={{ color: isGranted ? '#4ade80' : isDenied ? '#f87171' : '#D9A6FF' }}>
            {isGranted ? 'Location is enabled' : isDenied ? 'Location is blocked' : 'Checking…'}
          </p>
        </motion.div>
      )}

      {/* Reasons */}
      <motion.div
        className="relative z-10 w-full flex flex-col gap-2.5 mb-6"
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, delay: 0.25 }}
      >
        <p className="text-[10px] uppercase tracking-widest text-zinc-600 font-semibold px-1 mb-1">
          Why we need it
        </p>
        {REASONS.map(({ emoji, title, desc }, i) => (
          <motion.div
            key={title}
            className="flex items-start gap-4"
            style={{
              background: 'rgba(255,255,255,0.04)',
              border: '1px solid rgba(196,0,255,0.2)',
              borderRadius: 16,
              padding: '13px 15px',
            }}
            initial={{ opacity: 0, x: -12 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.3, delay: 0.3 + i * 0.06 }}
          >
            <span style={{ fontSize: 24, lineHeight: 1, flexShrink: 0, filter: 'drop-shadow(0 0 5px #C400FF)' }}>{emoji}</span>
            <div>
              <p style={{ fontSize: 13, fontWeight: 700, color: '#FFFFFF', marginBottom: 2 }}>{title}</p>
              <p style={{ fontSize: 11, color: '#9B60CC', lineHeight: 1.5 }}>{desc}</p>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* CTA */}
      <motion.div
        className="relative z-10 w-full"
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4, delay: 0.55 }}
      >
        {!isGranted ? (
          <>
            <motion.button
              onClick={handleEnable}
              disabled={isLoading}
              className="w-full text-white font-bold text-base tracking-wide rounded-3xl disabled:opacity-60"
              style={{
                height: 54,
                background: '#C400FF',
                boxShadow: '0 0 24px rgba(196,0,255,0.7)',
                border: 'none',
                cursor: 'pointer',
              }}
              animate={{ boxShadow: ['0 0 18px rgba(196,0,255,0.5)', '0 0 40px rgba(196,0,255,1)', '0 0 18px rgba(196,0,255,0.5)'] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
              whileTap={{ scale: 0.97 }}
            >
              {isLoading ? 'Requesting…' : '📍 Enable Location'}
            </motion.button>

            {isDenied && (
              <motion.div
                className="mt-3 rounded-xl px-4 py-3 text-center"
                style={{ background: 'rgba(239,68,68,0.10)', border: '1px solid rgba(239,68,68,0.25)' }}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                <p className="text-xs text-red-400 leading-relaxed">
                  Location was blocked. Please enable it in your browser or device settings, then tap again.
                </p>
              </motion.div>
            )}
          </>
        ) : (
          <div
            className="w-full rounded-3xl flex items-center justify-center gap-2 font-bold text-sm"
            style={{
              height: 54,
              background: 'rgba(34,197,94,0.15)',
              border: '1.5px solid rgba(34,197,94,0.4)',
              color: '#4ade80',
            }}
          >
            <CheckCircle2 className="w-5 h-5" />
            Location Active
          </div>
        )}

        <p className="text-center text-xs italic mt-4" style={{ color: '#7A4499' }}>
          "I need to know where you are before I can take you somewhere naughty…"
        </p>
      </motion.div>
    </div>
  );
}