import React from 'react';

const sections = [
  {
    title: '🔹 1. Information We Collect',
    content: 'We collect only the information necessary to operate the App, improve performance, and provide a safe experience.',
    subsections: [
      {
        subtitle: 'a. Information You Provide',
        items: [
          'Email address (if you create an account)',
          'Password (encrypted and never visible to us)',
          'Profile preferences (voice, mood, theme selections)',
        ],
      },
      {
        subtitle: 'b. Automatically Collected Information',
        items: [
          'Device type and operating system',
          'App version',
          'Basic usage analytics',
          'Crash reports and performance logs',
          'Navigation events (start/end of trips, but not your exact route history unless you enable it)',
        ],
      },
      {
        subtitle: 'c. Location Information',
        text: 'To provide navigation, the App requires access to your device\'s location.\nWe use your location only while navigation is active.\n\nWe do not store your real‑time location or sell/share it with advertisers.',
      },
      {
        subtitle: 'd. Third‑Party Sign‑In',
        text: 'If you sign in using Google, Microsoft, or Apple:',
        items: [
          'We receive your name, email, and unique identifier',
          'We do not access your contacts, files, calendars, or personal data',
        ],
      },
    ],
  },
  {
    title: '🔹 2. How We Use Your Information',
    content: 'We use your information to:',
    items: [
      'Provide navigation and app functionality',
      'Personalize your experience (voices, moods, themes)',
      'Improve performance and fix issues',
      'Maintain security',
      'Provide customer support',
    ],
    footer: 'We do not sell your data.\nWe do not use your data for targeted advertising.',
  },
  {
    title: '🔹 3. How We Protect Your Information',
    content: 'We use industry‑standard safeguards, including:',
    items: [
      'Encrypted data transmission (HTTPS)',
      'Secure authentication',
      'Encrypted passwords',
      'Limited access controls',
    ],
    footer: 'Your privacy and safety are our priority.',
  },
  {
    title: '🔹 4. Sharing of Information',
    content: 'We may share information only when necessary:',
    items: [
      'With trusted service providers who help operate the App',
      'To comply with legal requirements',
      'To protect the safety and rights of users',
      'With your explicit consent',
    ],
    footer: 'We do not share your information with advertisers or data brokers.',
  },
  {
    title: '🔹 5. Third‑Party Services',
    content: 'The App may use trusted third‑party tools such as:',
    items: [
      'Authentication providers (Google, Microsoft, Apple)',
      'Analytics services',
      'Error‑reporting tools',
    ],
    footer: 'These services have their own privacy policies.',
  },
  {
    title: '🔹 6. Children\'s Privacy',
    content: 'Naughty Navigator is not intended for children under 13.\nWe do not knowingly collect information from children.\n\nIf we learn that a child\'s information was collected, we will delete it promptly.',
  },
  {
    title: '🔹 7. Your Rights',
    content: 'Depending on your location, you may have the right to:',
    items: [
      'Access your data',
      'Update or correct your information',
      'Request deletion of your account',
      'Request that we stop using your data',
    ],
    footer: 'You may contact us to exercise these rights.',
  },
  {
    title: '🔹 8. Data Retention',
    content: 'We retain your information only as long as necessary to:',
    items: [
      'Provide the App\'s features',
      'Comply with legal obligations',
      'Resolve disputes',
      'Improve performance',
    ],
    footer: 'You may request deletion at any time.',
  },
  {
    title: '🔹 9. Contact Us',
    content: 'For questions or concerns about this Privacy Policy, contact:',
    footer: 'Naughty Navigator Support\nEmail: naughtynav62@gmail.com',
  },
  {
    title: '🔹 10. Changes to This Policy',
    content: 'We may update this Privacy Policy to reflect improvements or legal requirements.\nWhen we do, we will update the "Last Updated" date.',
  },
];

export default function PrivacyPolicyContent() {
  return (
    <div className="overflow-y-auto h-full bg-zinc-950 px-4 py-6 space-y-6 pb-20">
      <div className="space-y-2">
        <h2 className="text-lg font-bold text-zinc-100">Naughty Navigator — Privacy Policy</h2>
        <p className="text-xs text-zinc-500">Last Updated: March 2026</p>
        <p className="text-sm text-zinc-400 leading-relaxed">
          Naughty Navigator ("the App") is designed to provide a fun, personality‑driven navigation experience while respecting your privacy and protecting your personal information. This Privacy Policy explains what data we collect, how we use it, and the choices you have.
        </p>
        <p className="text-sm text-zinc-400 leading-relaxed">
          By using the App, you agree to the practices described in this Privacy Policy.
        </p>
      </div>

      <div className="h-px bg-zinc-800" />

      {sections.map((section, i) => (
        <div key={i} className="space-y-3">
          <h2 className="text-sm font-semibold text-zinc-200">{section.title}</h2>
          {section.content && <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{section.content}</p>}
          {section.items && (
            <ul className="space-y-1 pl-4">
              {section.items.map((item, j) => (
                <li key={j} className="text-sm text-zinc-400 list-disc leading-relaxed">{item}</li>
              ))}
            </ul>
          )}
          {section.subsections && section.subsections.map((sub, j) => (
            <div key={j} className="space-y-1 pl-2 border-l border-zinc-800">
              <p className="text-xs font-medium text-zinc-300">{sub.subtitle}</p>
              {sub.text && <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{sub.text}</p>}
              {sub.items && (
                <ul className="space-y-1 pl-4">
                  {sub.items.map((item, k) => (
                    <li key={k} className="text-sm text-zinc-400 list-disc leading-relaxed">{item}</li>
                  ))}
                </ul>
              )}
            </div>
          ))}
          {section.footer && <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{section.footer}</p>}
        </div>
      ))}
    </div>
  );
}