import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Lock } from 'lucide-react';
import { playTapSound } from '../../lib/soundEffects';

const PAGE_BG = { background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' };

const THEMES = [
  {
    id: 'default',
    label: 'Default',
    desc: 'Clean dark map, classic look',
    emoji: '🗺️',
    premium: false,
    accent: '#94a3b8',
    preview: { bg: '#1c1c2e', road: '#334155', route: '#ec4899', water: '#1e3a5f' },
  },
  {
    id: 'neon',
    label: 'Neon Glow',
    desc: 'Cyber-purple glow on all roads',
    emoji: '🟣',
    premium: true,
    accent: '#C400FF',
    preview: { bg: '#0D0015', road: '#D9A6FF', route: '#FF4DFF', water: '#1A0024' },
  },
  {
    id: 'midnight',
    label: 'Midnight Blue',
    desc: 'Deep ocean vibes, cool and moody',
    emoji: '🌊',
    premium: true,
    accent: '#3B82F6',
    preview: { bg: '#0a0f1e', road: '#3B82F6', route: '#60a5fa', water: '#0c1a3a' },
  },
  {
    id: 'hotpink',
    label: 'Hot Pink Glow',
    desc: 'Bold, unapologetic, totally you',
    emoji: '💗',
    premium: true,
    accent: '#FF006E',
    preview: { bg: '#1a0010', road: '#FF6EB3', route: '#FF006E', water: '#250020' },
  },
  {
    id: 'gold',
    label: 'Gold Luxe',
    desc: 'Opulent golden roads for a luxe ride',
    emoji: '✨',
    premium: true,
    accent: '#D4AF37',
    preview: { bg: '#0f0c00', road: '#D4AF37', route: '#FFD700', water: '#1a1400' },
  },
  {
    id: 'valentine',
    label: "Valentine's Blush",
    desc: 'Romantic rose tones for lovebirds',
    emoji: '💘',
    premium: true,
    seasonal: true,
    accent: '#FF4D6D',
    preview: { bg: '#1a000a', road: '#FF4D6D', route: '#FF85A1', water: '#250010' },
  },
];

function MapPreviewSVG({ colors, active }) {
  const { bg, road, route, water } = colors;
  const glow = active ? `drop-shadow(0 0 5px ${route})` : 'none';

  return (
    <svg width="100%" viewBox="0 0 160 90" style={{ background: bg, display: 'block', borderRadius: 12 }}>
      {/* water */}
      <ellipse cx="130" cy="70" rx="50" ry="30" fill={water} />
      {/* grid roads */}
      <line x1="0" y1="45" x2="160" y2="45" stroke={road} strokeWidth="1.5" opacity="0.7" />
      <line x1="80" y1="0" x2="80" y2="90" stroke={road} strokeWidth="1" opacity="0.5" />
      <line x1="0" y1="20" x2="160" y2="65" stroke={road} strokeWidth="1" opacity="0.4" />
      {/* route */}
      <polyline
        points="15,75 45,55 75,45 105,32 145,14"
        fill="none"
        stroke={route}
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        style={{ filter: glow }}
      />
      {/* dots */}
      <circle cx="45" cy="55" r="3.5" fill={route} style={{ filter: glow }} />
      <circle cx="105" cy="32" r="3.5" fill={route} style={{ filter: glow }} />
      {/* destination pin */}
      <circle cx="145" cy="14" r="5" fill={route} style={{ filter: glow }} />
      <circle cx="145" cy="14" r="2.5" fill={bg} />
    </svg>
  );
}

export default function MapThemePage({ onBack }) {
  const [selected, setSelected] = useState(() => localStorage.getItem('nn_map_theme') || 'default');
  const isPremium = localStorage.getItem('nn_premium') === 'true';

  const handleSelect = (theme) => {
    if (theme.premium && !isPremium) return;
    playTapSound();
    setSelected(theme.id);
    localStorage.setItem('nn_map_theme', theme.id);
  };

  return (
    <div className="h-full flex flex-col" style={PAGE_BG}>
      {/* Ambient glow */}
      <div className="pointer-events-none absolute inset-0 z-0" style={{
        background: 'radial-gradient(ellipse at 50% 10%, rgba(196,0,255,0.2) 0%, transparent 60%)',
      }} />

      {/* Header */}
      <div className="shrink-0 relative z-10 flex items-center gap-3 px-6 py-4" style={{ borderBottom: '1px solid rgba(196,0,255,0.15)' }}>
        <button
          onClick={onBack}
          className="h-9 w-9 rounded-2xl flex items-center justify-center text-lg font-bold"
          style={{ background: 'rgba(196,0,255,0.12)', border: '1px solid rgba(196,0,255,0.25)', color: '#D9A6FF' }}
        >
          ‹
        </button>
        <h1 className="font-bold" style={{ fontSize: 22, color: '#C400FF', textShadow: '0 0 14px rgba(196,0,255,0.7)' }}>
          Map Themes
        </h1>
      </div>

      {/* List */}
      <div className="flex-1 overflow-y-auto relative z-10 px-5 py-6 space-y-3 pb-10">
        <p className="text-xs px-1 mb-4" style={{ color: 'rgba(217,166,255,0.45)' }}>
          Pick the vibe for your map. Premium themes require an active subscription.
        </p>

        {THEMES.map((theme, i) => {
          const active = selected === theme.id;
          const locked = theme.premium && !isPremium;

          return (
            <motion.button
              key={theme.id}
              onClick={() => handleSelect(theme)}
              className="w-full text-left rounded-3xl overflow-hidden"
              style={{
                background: active ? `${theme.accent}14` : 'rgba(255,255,255,0.04)',
                border: active ? `1.5px solid ${theme.accent}` : '1px solid rgba(196,0,255,0.18)',
                boxShadow: active ? `0 0 24px ${theme.accent}44` : 'none',
                opacity: locked ? 0.7 : 1,
                transition: 'border 0.25s ease, box-shadow 0.25s ease',
              }}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: locked ? 0.7 : 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.06 }}
              whileTap={{ scale: locked ? 1 : 0.99 }}
            >
              {/* Map preview */}
              <div className="relative" style={{ borderRadius: '20px 20px 0 0', overflow: 'hidden' }}>
                <MapPreviewSVG colors={theme.preview} active={active} />

                {/* Active badge */}
                {active && (
                  <div className="absolute top-2 right-2 px-2 py-0.5 rounded-lg text-[10px] font-bold"
                    style={{ background: theme.accent, color: '#fff', boxShadow: `0 0 8px ${theme.accent}` }}>
                    Active
                  </div>
                )}

                {/* Seasonal badge */}
                {theme.seasonal && (
                  <div className="absolute top-2 left-2 px-2 py-0.5 rounded-lg text-[10px] font-bold"
                    style={{ background: 'rgba(255,77,255,0.25)', border: '1px solid rgba(255,77,255,0.5)', color: '#FF77FF' }}>
                    Seasonal
                  </div>
                )}
              </div>

              {/* Info row */}
              <div className="flex items-center gap-3 px-4 py-3">
                <span style={{ fontSize: 22, flexShrink: 0 }}>{theme.emoji}</span>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold" style={{ color: active ? '#fff' : '#EDD9FF' }}>{theme.label}</p>
                  <p className="text-[11px] mt-0.5" style={{ color: 'rgba(217,166,255,0.45)' }}>{theme.desc}</p>
                </div>

                {locked ? (
                  <div className="flex items-center gap-1.5 shrink-0">
                    <Lock className="w-3.5 h-3.5" style={{ color: '#C400FF' }} />
                    <span className="text-[10px] font-bold" style={{ color: '#C400FF' }}>Premium</span>
                  </div>
                ) : (
                  /* Toggle */
                  <div
                    className="shrink-0 rounded-full relative transition-all duration-300"
                    style={{
                      width: 44,
                      height: 24,
                      background: active ? theme.accent : 'rgba(255,255,255,0.1)',
                      boxShadow: active ? `0 0 14px ${theme.accent}88` : 'none',
                    }}
                  >
                    <motion.div
                      animate={{ left: active ? 22 : 4 }}
                      transition={{ duration: 0.2 }}
                      className="absolute top-1 w-4 h-4 rounded-full bg-white"
                      style={{ boxShadow: active ? `0 0 6px ${theme.accent}` : 'none' }}
                    />
                  </div>
                )}
              </div>
            </motion.button>
          );
        })}

        {!isPremium && (
          <div className="rounded-2xl px-4 py-4 text-center mt-2"
            style={{ background: 'rgba(196,0,255,0.07)', border: '1px solid rgba(196,0,255,0.2)' }}>
            <p className="text-xs font-semibold mb-1" style={{ color: '#C400FF' }}>👑 Unlock all themes with Premium</p>
            <p className="text-[11px]" style={{ color: 'rgba(217,166,255,0.5)' }}>
              Neon Glow, Midnight Blue, Hot Pink & more.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}