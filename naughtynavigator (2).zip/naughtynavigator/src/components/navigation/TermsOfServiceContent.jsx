import React from 'react';

const sections = [
  {
    title: '1. Acceptance of Terms',
    content: 'By using Naughty Navigator, you confirm that:',
    items: [
      'You are at least 18 years old.',
      'You have the legal capacity to enter into this agreement.',
      'You agree to comply with these Terms and all applicable laws.',
    ],
    footer: 'If you do not agree, you must discontinue use of the Services.',
  },
  {
    title: '2. Description of Services',
    content: 'Naughty Navigator provides entertainment‑focused navigation experiences, voice packs, personality features, and optional premium upgrades. The app is not a replacement for official navigation tools and should be used responsibly.',
  },
  {
    title: '3. Changes to These Terms',
    content: 'We may update these Terms at any time. Updates will be posted within the app or on our website. Continued use of the Services after changes means you accept the updated Terms.',
  },
  {
    title: '4. User Responsibilities',
    content: 'You agree to:',
    items: [
      'Use the Services safely and lawfully.',
      'Follow all traffic laws and avoid interacting with the app while driving.',
      'Use the app for personal, non‑commercial purposes unless otherwise authorized.',
    ],
    footer: 'You may not:\n• Reverse engineer, copy, or distribute the app or its content.\n• Use the Services for harmful, fraudulent, or illegal activity.\n• Attempt to bypass security features or access restricted areas.',
  },
  {
    title: '5. Accounts & Purchases',
    content: 'Some features may require creating an account or making in‑app purchases. You agree that:',
    items: [
      'All information you provide is accurate.',
      'Purchases are final and non‑refundable except where required by law.',
      'Premium features, voice packs, and upgrades may change over time.',
    ],
    footer: 'We reserve the right to suspend or terminate accounts that violate these Terms.',
  },
  {
    title: '6. Intellectual Property',
    content: 'All branding, voice content, personality lines, graphics, features, and other materials within Naughty Navigator are owned by us or licensed to us.',
    footer: 'You may not reproduce, modify, or distribute any part of the Services without written permission.',
  },
  {
    title: '7. Safety Disclaimer',
    content: 'Naughty Navigator is designed for entertainment. You acknowledge that:',
    items: [
      'The app may use playful, humorous, or suggestive language.',
      'The app is not intended to provide official navigation accuracy.',
      'You are solely responsible for safe driving and decision‑making.',
      'We are not liable for accidents, injuries, or damages resulting from misuse of the app.',
    ],
  },
  {
    title: '8. Third‑Party Services',
    content: 'The app may integrate with third‑party tools or mapping providers. We are not responsible for:',
    items: [
      'Third‑party content or accuracy',
      'Their privacy practices',
      'Their terms and conditions',
    ],
    footer: 'Your use of third‑party services is at your own risk.',
  },
  {
    title: '9. Privacy',
    content: 'Your use of the Services is also governed by the Naughty Navigator Privacy Policy, which explains how we collect, use, and protect your information.',
  },
  {
    title: '10. Limitation of Liability',
    content: 'To the fullest extent permitted by law:',
    items: [
      'The Services are provided "as is" and "as available."',
      'We disclaim all warranties, express or implied.',
      'We are not liable for indirect, incidental, or consequential damages.',
      'Our total liability will not exceed the amount you paid for the Services, if any.',
    ],
  },
  {
    title: '11. Termination',
    content: 'We may suspend or terminate your access to the Services at any time for violations of these Terms or for any reason at our discretion.',
    footer: 'You may stop using the Services at any time.',
  },
  {
    title: '12. Governing Law',
    content: 'These Terms are governed by the laws of the State of Illinois, without regard to conflict‑of‑law principles.',
  },
  {
    title: '13. Contact Information',
    content: 'For questions about these Terms, you may contact us at:',
    footer: 'Email: support@naughtynavigator.com',
  },
];

export default function TermsOfServiceContent() {
  return (
    <div className="overflow-y-auto h-full px-4 py-6 space-y-5" style={{ background: 'linear-gradient(180deg, #1A0028 0%, #0D0018 60%, #080010 100%)' }}>
      <div className="space-y-1">
        <h2 className="text-base font-bold" style={{ color: '#E8CCFF' }}>Naughty Navigator – Terms of Service</h2>
        <p className="text-xs" style={{ color: 'rgba(217,166,255,0.45)' }}>Last Updated: March 27, 2026</p>
        <p className="text-xs leading-relaxed" style={{ color: 'rgba(217,166,255,0.6)' }}>
          Welcome to Naughty Navigator. These Terms of Service ("Terms") govern your access to and use of the Naughty Navigator mobile application, website, and related services (collectively, the "Services"). By downloading, accessing, or using the Services, you agree to these Terms.
        </p>
      </div>

      <div className="h-px" style={{ background: 'rgba(196,0,255,0.15)' }} />

      {sections.map((section, i) => (
        <div key={i} className="space-y-2">
          <h3 className="text-sm font-semibold" style={{ color: '#D9A6FF' }}>{section.title}</h3>
          {section.content && (
            <p className="text-xs leading-relaxed" style={{ color: 'rgba(217,166,255,0.6)' }}>{section.content}</p>
          )}
          {section.items && (
            <ul className="space-y-1 pl-4">
              {section.items.map((item, j) => (
                <li key={j} className="text-xs leading-relaxed list-disc" style={{ color: 'rgba(217,166,255,0.55)' }}>{item}</li>
              ))}
            </ul>
          )}
          {section.footer && (
            <p className="text-xs leading-relaxed whitespace-pre-line" style={{ color: 'rgba(217,166,255,0.55)' }}>{section.footer}</p>
          )}
        </div>
      ))}

      <div className="rounded-2xl px-4 py-3 text-center" style={{ background: 'rgba(196,0,255,0.06)', border: '1px solid rgba(196,0,255,0.2)' }}>
        <p className="text-xs italic" style={{ color: '#9B60CC' }}>
          "Thank you for choosing Naughty Navigator. We're committed to providing a fun, premium, and responsible experience."
        </p>
      </div>
    </div>
  );
}