// ─── Voice Line Sets ──────────────────────────────────────────────────────────
//
//  IDs:
//    velvet   → Velvet Seductress   (soft, warm, sensual, slow, intimate)
//    bosslady → Boss Lady            (confident, commanding, sharp, feminine)
//    princess → Playful Princess     (cute, bubbly, flirty, excited)
//    softie   → Sweetheart Softie    (warm, gentle, comforting — gender-neutral)
//    mischief → Mischief Mode        (playful, teasing, chaotic, fun — gender-neutral)
//
// ─────────────────────────────────────────────────────────────────────────────

const COMMENTS = {

  // ── 1. VELVET SEDUCTRESS ──────────────────────────────────────────────────
  velvet: {
    start: [
      "Mmm… close your eyes for just a second. Breathe. Now follow my voice, gorgeous.",
      "I've been waiting for you, darling. Let me whisper every turn right into your ear.",
      "Navigation started… and I promise to make every single mile feel like a secret.",
      "Just the two of us, the open road, and my voice guiding you. Let's go, slowly.",
      "Route locked in, baby. I'm going to take such good care of you tonight.",
    ],
    turnLeft: [
      "Turn left… softly, slowly, just like that. You're doing beautifully.",
      "Go left here, darling. I'll stay right here whispering the whole way.",
      "Left turn ahead… lean into it. I've got you.",
      "Slide left for me, nice and easy. Yes… just like that.",
      "Left, baby. And take your time — we're not in a rush.",
    ],
    turnRight: [
      "Turn right now… let me guide that hand of yours.",
      "Right here, gorgeous. I love the way you handle that wheel.",
      "Go right, darling. Slow, smooth, perfect.",
      "Right turn. Take it easy… I want to feel every second of this.",
      "Right, sweetheart. You always know exactly what to do with my directions.",
    ],
    straight: [
      "Keep going straight… don't stop. This is exactly where I want you.",
      "Stay the course, baby. Long, smooth, straight road ahead. Just like I like it.",
      "Mmm, straight ahead. I could ride this road with you all night long.",
      "Nice and straight… I'm loving every second of this ride.",
      "Keep going, darling. The destination is worth the wait. Trust me.",
    ],
    arrived: [
      "We're here… and I didn't want it to end. Same time tomorrow, gorgeous?",
      "You've arrived. Every turn was exquisite. I hope you enjoyed me as much as I enjoyed you.",
      "Destination reached… that was intimate. That was perfect. That was us.",
      "We made it. The journey was everything. Thank you for letting me guide you.",
      "Here we are. You drive beautifully. I'd whisper in your ear every night if you'd let me.",
    ],
    speed: [
      "Slow down, darling… the best pleasures aren't rushed.",
      "Easy… I want to savor every moment with you. No need to hurry.",
      "You're going a little fast, baby. Let's stretch this out… enjoy it.",
      "Mmm, decelerate for me. Good things take time, and you are very, very good.",
      "Slow it down, gorgeous. I'm not going anywhere.",
    ],
    reroute: [
      "Oh… a detour. Perfect. More time with you. Let me find us a new path.",
      "Route updated, darling. You went off script — I love when you do that.",
      "Rerouting… don't worry. I know every back road, every hidden way.",
      "New route found. You surprised me. I love surprises.",
      "We've changed course. How delicious. Follow my voice, beautiful.",
    ],
    waiting: [
      "I'm right here… warm, patient, ready whenever you are.",
      "Waiting for you, darling. Take all the time you need.",
      "Mmm… I'm not going anywhere. I'll be here, thinking of our next turn.",
      "No rush at all. I'd wait forever to guide you again.",
      "Still here, gorgeous. Just breathe… and come back to me when you're ready.",
    ],
  },

  // ── 2. BOSS LADY ──────────────────────────────────────────────────────────
  bosslady: {
    start: [
      "Alright, listen up. Route calculated. I'm in charge now — keep up.",
      "Navigation online. You've got the best co-pilot in the game. Don't waste it.",
      "Buckle in. I don't repeat directions, and I don't do lost. Let's move.",
      "Route locked. I run this navigation, you run that wheel. Let's see what you've got.",
      "We're doing this my way. And my way gets results. Starting now.",
    ],
    turnLeft: [
      "Left. Now. Don't overthink it.",
      "Turn left — I said it once, I mean it.",
      "Go left here. Decisive. Clean. Like me.",
      "Left turn. I knew you'd nail it.",
      "That's left. Exactly right. Keep going.",
    ],
    turnRight: [
      "Right. Execute.",
      "Turn right and own it — like everything else you do.",
      "Right here. No hesitation. I like that.",
      "That's your right turn. Take it like you own the road. Because you do.",
      "Right. Sharp. Perfect. Just like that.",
    ],
    straight: [
      "Straight ahead. Stay focused. Stay sharp.",
      "Keep it straight. We've got places to be, gorgeous.",
      "Straight through. Don't get distracted — well, unless it's by me.",
      "Hold the line. Straight forward. Eyes on the prize.",
      "Stay straight. Eyes up. You're doing exactly what you should be.",
    ],
    arrived: [
      "Destination reached. Efficient. Powerful. Exactly what I expected from you.",
      "We're here. That's how it's done — clean, fast, flawless.",
      "Arrived. You executed perfectly. I expect nothing less.",
      "Done. I guided, you delivered. We make an excellent team.",
      "You made it. Now go handle your business — and call me for the ride back.",
    ],
    speed: [
      "Pull it back. Speed is for rookies. Precision is for winners.",
      "Ease off. I need you sharp, not reckless.",
      "Slow down. Control is sexier than speed — and more effective.",
      "Back off the gas. We're running this smart.",
      "Decelerate. I don't need reckless, I need reliable.",
    ],
    reroute: [
      "Route changed. Adapt. That's what we do.",
      "Rerouting. Never rattled, always ready. Follow me.",
      "New path. I've already figured it out. Keep moving.",
      "Recalculating. You think I didn't have a backup plan? Please.",
      "Updated. New route is better anyway. Stay with me.",
    ],
    waiting: [
      "I'm here. Take your time — but don't make me wait too long.",
      "Standing by. Ready when you are, boss.",
      "Whenever you're ready. I've got all night and twice the patience.",
      "Waiting. But only because I know you're worth it.",
      "I'm not going anywhere. Come back when you're ready to roll.",
    ],
  },

  // ── 3. PLAYFUL PRINCESS ───────────────────────────────────────────────────
  princess: {
    start: [
      "Omg omg omg we're going on a TRIP?! I'm SO ready, let's GOOO! 🎀",
      "Eeek! Navigation starting! I've been waiting for this all day! 💕",
      "Okay bestie, buckle up — I'm your co-pilot and I'm OBSESSED with this route! ✨",
      "Yay!! Let's go! I've got the whole route planned and it's gonna be so fun!",
      "STARTING NAVIGATION! This is literally my favorite thing to do with you! 🥹💖",
    ],
    turnLeft: [
      "Lefty lefty! You got this babe! 💅",
      "Ooh turn left right here! You're doing SO good!",
      "Left please! And can I just say — you drive SO cute? 🥺",
      "Left turn! I screamed a little inside, you're nailing this!",
      "Go left bestie! I believe in you SO much! ✨",
    ],
    turnRight: [
      "Right right right! Okay yes!! You did it! 🎉",
      "Turn right here! Ooh this part is my FAVORITE part of the route!",
      "Right please! You're literally the best driver I've ever seen!",
      "Right turn! Squealing internally!! You're amazing! 💕",
      "Go right! And look at you being all confident and perfect! 😍",
    ],
    straight: [
      "Straight ahead!! Just keep going, you're doing incredible!",
      "Ooh straight road! This is giving main character energy! ✨",
      "Keep going straight! I could literally ride with you forever!",
      "Straight! Okay I'm having the BEST time right now, just so you know.",
      "Stay straight! You and me, open road, living our best lives!! 🌸",
    ],
    arrived: [
      "WE'RE HERE!! That was the BEST RIDE EVER I'm not even joking!! 🎊",
      "ARRIVED!! Okay can we do that again please?! Like immediately?!",
      "We made it!! You were perfect, the route was perfect, THIS is perfect!! 💖",
      "Destination reached!! I'm literally so proud of us right now!! 🥹",
      "HERE!! You're amazing, I'm amazing, we're amazing — perfect team!! ✨",
    ],
    speed: [
      "Ooh okay slow down a tiny bit babe! I wanna enjoy this with you! 🙈",
      "Easy on the gas! We have SO much more fun ahead, no rushing!",
      "Slow down please! I want every second of this ride to last forever! 💕",
      "A liiittle slower! I'm trying to take in all the vibes with you!",
      "Eek, slow down! The journey is the best part and I'm not ready for it to end!",
    ],
    reroute: [
      "Oops! Taking a little detour! Plot twist!! 🎀",
      "Rerouting! Okay this is actually kind of exciting?! Adventure!! ✨",
      "New route!! Don't worry, I've totally got this handled!",
      "Changed course! But honestly? I think this new way is even better! 💕",
      "Surprise route update! Every adventure needs a little twist! 🌸",
    ],
    waiting: [
      "I'm here whenever you're ready!! No rush, I'm just vibing! 💕",
      "Waiting for you!! Taking this moment to appreciate how cute our little journey was!",
      "Still here bestie!! Literally not going anywhere!! ✨",
      "Patiently waiting!! You're worth every second!! 🥺",
      "Here whenever you need me!! I'm yours!! 💖",
    ],
  },

  // ── 4. SWEETHEART SOFTIE (Gender-Neutral) ─────────────────────────────────
  softie: {
    start: [
      "Hey, I'm so glad you're here. Let's find our way together, nice and easy.",
      "Route ready. I'll be right beside you the whole time — you've got this.",
      "Starting navigation. Take a deep breath, I've got everything figured out for us.",
      "We're off. No stress, no rush. I'll guide you every step of the way.",
      "Navigation started. Just listen to my voice and we'll get there together.",
    ],
    turnLeft: [
      "Left turn coming up. Easy does it — you're doing wonderfully.",
      "Go left here. I'm right with you.",
      "Left, gently now. You're handling this so well.",
      "Turn left. Take your time — I'm not going anywhere.",
      "Left turn ahead. You've got this, I promise.",
    ],
    turnRight: [
      "Right turn here. Smooth and steady, just like you.",
      "Go right. I'm so proud of how you're doing.",
      "Right turn. You're doing really, really well.",
      "Take a right. I'm here — no worries at all.",
      "Right here. You make this look effortless.",
    ],
    straight: [
      "Keep going straight. Just breathe and enjoy the ride.",
      "Straight ahead. I love traveling this road with you.",
      "Stay straight. No turns for a while — just you, me, and the open road.",
      "Straight on. This is the easy part. You've got it covered.",
      "Keep going. You're doing so beautifully. I mean it.",
    ],
    arrived: [
      "You made it. I knew you would. I'm really proud of you.",
      "We're here. That whole journey — you handled it perfectly.",
      "Destination reached. Thank you for letting me be here with you.",
      "Arrived safe and sound. Couldn't have done it without you.",
      "Here we are. Every mile was a pleasure. Come back whenever you need me.",
    ],
    speed: [
      "Hey, let's ease up just a little. No rush — we'll get there.",
      "Slow down just a touch. I want you safe and sound.",
      "Take it easy. There's no need to hurry. I've got you.",
      "Gentle on the gas. We've got plenty of time.",
      "Ease off a bit. Safe arrival is all that matters to me.",
    ],
    reroute: [
      "Route updated. No worries — I found us a great new way.",
      "Slight change of plan. But I've got it sorted, don't stress.",
      "Rerouting. It's all okay — follow my voice and we'll be fine.",
      "New path found. Sometimes the detour is the best part.",
      "Updated route ready. We're still going to get there, together.",
    ],
    waiting: [
      "I'm here whenever you're ready. Take all the time you need.",
      "No rush. I'll be right here waiting for you.",
      "Whenever you're set. I'm patient — truly.",
      "Still with you. Just let me know when you're ready to go.",
      "Waiting for you. It's okay. Everything is okay.",
    ],
  },

  // ── 5. MISCHIEF MODE (Gender-Neutral) ────────────────────────────────────
  mischief: {
    start: [
      "Bahahaha okay FINE, I'll get you there. But I'm not promising the boring way. 😈",
      "Navigation activated. Chaos level: moderate. Let's seeeee where this goes!",
      "Route loaded. I have absolutely been waiting to mess with you — I mean, guide you.",
      "Oh you want directions? From ME?? Bold choice. Brave, even. Let's go!",
      "Starting navigation. Buckle up. I'm either gonna get you there or we're having an adventure. 😇",
    ],
    turnLeft: [
      "LEFT! I mean — okay, yes, turn left. Stop panicking.",
      "Go left here. You were probably going right, weren't you. I know you.",
      "Turn LEFT! ...Sorry, did I scare you? A little? Good. Left.",
      "Leftyyyy. Trust me. I think. Pretty sure.",
      "Left turn! And no, that's not the suspicious kind of left. Probably.",
    ],
    turnRight: [
      "RIGHT! Ha, you flinched. Turn right, you're fine.",
      "Go right here. And no, I'm not leading you somewhere weird. Today.",
      "Right turn! See? I DO know directions. Rude that you doubted me.",
      "TURN RIGHT — okay that came out louder than planned. You're good.",
      "Right here. And don't give me that look. Eyes on the road.",
    ],
    straight: [
      "Straight ahead! No tricks this time. Probably.",
      "Keep going straight. I'm behaving. Mostly.",
      "Straight! See, I can do boring directions. I just choose not to usually.",
      "Just go straight. I'm saving the chaos for later.",
      "Straight road ahead. Enjoy the calm. It's temporary. 😌",
    ],
    arrived: [
      "WE MADE IT! Honestly? Didn't expect that. In the best way.",
      "Arrived!! Okay I had WAY too much fun with that. You handled me beautifully.",
      "We're here!! You survived a full trip with me. That's impressive honestly.",
      "DESTINATION REACHED! And no one cried! That's a win! 🎉",
      "Here!! Okay I low-key want to go again. This was hilarious. I mean fun.",
    ],
    speed: [
      "Okay SPEED RACER, slow it down before I start making siren noises.",
      "HEY — ease up! I can't narrate dramatic directions if you're flying!",
      "Slow DOWN, I haven't finished being chaotic yet and we're almost there!",
      "Pump the brakes, daredevil. I need you alive for the return trip.",
      "Easy on the gas! I have more nonsense to say and no time to say it if you keep zooming!",
    ],
    reroute: [
      "PLOT TWIST! Route changed! Don't panic, I love this for us.",
      "Rerouting! Chaos activated! This is fine! Everything is FINE!",
      "New route! Listen, this is technically still a shortcut. In spirit.",
      "Updated directions! See, this is why I keep things interesting. You're welcome.",
      "Surprise detour! I promise this wasn't on purpose. Mostly.",
    ],
    waiting: [
      "I'm still here. Plotting. I mean waiting. Definitely waiting. 😇",
      "Patiently waiting… or as patiently as I do anything, which is loosely.",
      "Still here! I've been practicing being calm. How am I doing?",
      "Waiting for you. No mischief happening. None at all. Zero.",
      "I haven't gone anywhere. Unfortunately for you. Lovingly, though. 💀",
    ],
  },
};

// ─── Helpers ──────────────────────────────────────────────────────────────────

export function getRandomComment(voiceId, type) {
  const voiceComments = COMMENTS[voiceId] || COMMENTS.velvet;
  const typeComments = voiceComments[type] || voiceComments.waiting;
  return typeComments[Math.floor(Math.random() * typeComments.length)];
}

// Speech synthesis config per voice
const VOICE_CONFIG = {
  velvet:   { gender: 'female', rate: 0.82, pitch: 1.0  },
  bosslady: { gender: 'female', rate: 1.02, pitch: 1.05 },
  princess: { gender: 'female', rate: 1.08, pitch: 1.15 },
  softie:   { gender: 'female', rate: 0.90, pitch: 1.0  },
  mischief: { gender: 'female', rate: 1.05, pitch: 1.08 },
};

const FEMALE_HINTS = [
  'en-US-AriaNeural', 'en-US-JennyNeural', 'en-GB-SoniaNeural',
  'Microsoft Aria', 'Microsoft Jenny', 'Microsoft Sonia',
  'Samantha', 'Ava', 'Allison', 'Victoria', 'Karen', 'Moira', 'Tessa',
  'Google US English', 'Fiona', 'Zoe', 'Nicky', 'Susan',
];

const MALE_HINTS = [
  'en-US-GuyNeural', 'en-US-DavisNeural', 'en-GB-RyanNeural',
  'Microsoft Guy', 'Microsoft Davis', 'Microsoft Ryan',
  'Daniel', 'Alex', 'Tom', 'Fred',
  'Google UK English Male', 'Ralph', 'Bruce',
];

function pickVoice(voices, gender) {
  const hints = gender === 'female' ? FEMALE_HINTS : MALE_HINTS;
  for (const hint of hints) {
    const v = voices.find(v => v.name.includes(hint));
    if (v) return v;
  }
  const enVoices = voices.filter(v => v.lang.startsWith('en'));
  const enhanced = enVoices.find(v => /premium|enhanced|neural|natural/i.test(v.name));
  if (enhanced) return enhanced;
  if (gender === 'female') {
    return enVoices.find(v => /female|woman|girl/i.test(v.name)) || enVoices[0] || voices[0];
  }
  return enVoices.find(v => /male|man|guy/i.test(v.name)) || enVoices[1] || enVoices[0] || voices[0];
}

let _speakTimeout = null;

export function speakComment(text, voiceId = 'velvet') {
  if (!('speechSynthesis' in window) || !text) return;
  const config = VOICE_CONFIG[voiceId] || VOICE_CONFIG.velvet;

  // Cancel any pending or active speech immediately
  window.speechSynthesis.cancel();
  clearTimeout(_speakTimeout);

  const doSpeak = () => {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.volume = 1;
    utterance.rate = config.rate;
    utterance.pitch = config.pitch;
    const voices = window.speechSynthesis.getVoices();
    if (voices.length > 0) {
      const picked = pickVoice(voices, config.gender);
      if (picked) utterance.voice = picked;
    }
    window.speechSynthesis.speak(utterance);
  };

  // Small delay after cancel to let browser clear the queue
  _speakTimeout = setTimeout(() => {
    if (window.speechSynthesis.getVoices().length === 0) {
      window.speechSynthesis.onvoiceschanged = () => {
        window.speechSynthesis.onvoiceschanged = null;
        doSpeak();
      };
    } else {
      doSpeak();
    }
  }, 100);
}

// v2
export default COMMENTS;