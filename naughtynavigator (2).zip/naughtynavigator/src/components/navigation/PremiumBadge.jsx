import React from 'react';
import { motion } from 'framer-motion';

/**
 * PremiumBadge
 * Props:
 *   size: 'sm' | 'md' | 'lg'  (default 'md')
 *   showLabel: boolean         (default false)
 */
export default function PremiumBadge({ size = 'md', showLabel = false }) {
  const dims = {
    sm: { outer: 32, inner: 26, crown: 'text-sm', heart: 'text-[9px]', sparkle: 10, label: false },
    md: { outer: 48, inner: 38, crown: 'text-xl', heart: 'text-xs',   sparkle: 14, label: true },
    lg: { outer: 64, inner: 52, crown: 'text-3xl', heart: 'text-base', sparkle: 18, label: true },
  }[size] || {};

  return (
    <div className="flex flex-col items-center gap-1" style={{ userSelect: 'none' }}>
      <div className="relative" style={{ width: dims.outer, height: dims.outer }}>

        {/* Outer pulsing glow ring */}
        <motion.div
          className="absolute inset-0 rounded-full pointer-events-none"
          style={{
            boxShadow: '0 0 0 2px #C400FF, 0 0 12px 4px rgba(196,0,255,0.55), 0 0 24px 6px rgba(255,0,230,0.25)',
          }}
          animate={{ boxShadow: [
            '0 0 0 2px #C400FF, 0 0 10px 3px rgba(196,0,255,0.5), 0 0 20px 5px rgba(255,0,230,0.2)',
            '0 0 0 2px #FF00E6, 0 0 18px 7px rgba(196,0,255,0.8), 0 0 34px 10px rgba(255,0,230,0.35)',
            '0 0 0 2px #C400FF, 0 0 10px 3px rgba(196,0,255,0.5), 0 0 20px 5px rgba(255,0,230,0.2)',
          ]}}
          transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
        />

        {/* Badge circle */}
        <div
          className="absolute inset-0 rounded-full flex flex-col items-center justify-center"
          style={{
            background: 'radial-gradient(circle at 40% 35%, #3D0055 0%, #2A0038 55%, #1A0024 100%)',
            border: '1.5px solid rgba(196,0,255,0.7)',
          }}
        >
          <span
            className={`${dims.crown} leading-none`}
            style={{ filter: 'drop-shadow(0 0 6px #C400FF)' }}
          >
            👑
          </span>
          <span
            className={`${dims.heart} leading-none -mt-0.5`}
            style={{ filter: 'drop-shadow(0 0 4px #FF00AA)' }}
          >
            💜
          </span>
        </div>

        {/* Sparkle top-right */}
        <motion.div
          className="absolute flex flex-col items-center"
          style={{ top: -2, right: -2, width: dims.sparkle, height: dims.sparkle }}
          animate={{ scale: [1, 1.4, 1], opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
        >
          <svg viewBox="0 0 24 24" fill="none" width="100%" height="100%">
            <path
              d="M12 2 L13.5 9 L20 12 L13.5 15 L12 22 L10.5 15 L4 12 L10.5 9 Z"
              fill="#FF00E6"
              style={{ filter: 'drop-shadow(0 0 4px #C400FF)' }}
            />
          </svg>
        </motion.div>

        {/* Second smaller sparkle */}
        <motion.div
          className="absolute"
          style={{ top: 4, right: dims.sparkle - 2, width: dims.sparkle * 0.6, height: dims.sparkle * 0.6 }}
          animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
          transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
        >
          <svg viewBox="0 0 24 24" fill="none" width="100%" height="100%">
            <path
              d="M12 2 L13.5 9 L20 12 L13.5 15 L12 22 L10.5 15 L4 12 L10.5 9 Z"
              fill="#C400FF"
              style={{ filter: 'drop-shadow(0 0 3px #FF00E6)' }}
            />
          </svg>
        </motion.div>
      </div>

      {/* Optional label */}
      {showLabel && dims.label && (
        <motion.p
          className="text-[9px] font-semibold tracking-widest uppercase"
          style={{
            color: '#E070FF',
            textShadow: '0 0 8px rgba(196,0,255,0.8)',
            letterSpacing: '0.15em',
          }}
          animate={{ opacity: [0.7, 1, 0.7] }}
          transition={{ duration: 2.2, repeat: Infinity, ease: 'easeInOut' }}
        >
          Premium
        </motion.p>
      )}
    </div>
  );
}