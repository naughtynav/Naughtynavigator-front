import React, { useState } from 'react';
import { getMoodResponse } from '../../lib/routingService';
import { speakComment } from './SeductiveComments';

const MOODS = [
  { id: 'happy', emoji: '😄', label: 'Happy' },
  { id: 'focused', emoji: '🎯', label: 'Focused' },
  { id: 'tired', emoji: '😴', label: 'Tired' },
  { id: 'angry', emoji: '😤', label: 'Angry' },
  { id: 'bored', emoji: '😑', label: 'Bored' },
  { id: 'lost', emoji: '😕', label: 'Lost' },
];

export default function MoodCheckIn({ selectedVoice = 'sultry' }) {
  const [activeMood, setActiveMood] = useState(null);
  const [response, setResponse] = useState(null);

  const handleMood = (moodId) => {
    setActiveMood(moodId);
    const { message } = getMoodResponse(moodId);
    setResponse(message);
    speakComment(message, selectedVoice);
  };

  return (
    <div className="space-y-4">
      <div className="text-center space-y-1">
        <h2 className="text-base font-semibold text-zinc-200">How are you feeling?</h2>
        <p className="text-xs text-zinc-500">Your navigator will respond to your mood</p>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {MOODS.map(({ id, emoji, label }) => (
          <button
            key={id}
            onClick={() => handleMood(id)}
            className={`flex flex-col items-center gap-2 py-4 rounded-2xl border transition-all duration-200 active:scale-95
              ${activeMood === id
                ? 'border-pink-500/40 bg-pink-500/10 text-pink-300'
                : 'border-zinc-800 bg-zinc-900 text-zinc-400 hover:border-zinc-700'
              }`}
          >
            <span className="text-2xl">{emoji}</span>
            <span className="text-[11px] font-medium">{label}</span>
          </button>
        ))}
      </div>

      {response && (
        <div className="bg-zinc-900 border border-zinc-700/50 rounded-2xl p-4 relative overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-pink-500/40 to-transparent" />
          <p className="text-sm text-zinc-300 leading-relaxed italic">"{response}"</p>
        </div>
      )}
    </div>
  );
}