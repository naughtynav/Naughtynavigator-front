import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const FEATURES = ['Voice Packs', 'Mood Navigation', 'Personality Boosters', 'Neon Themes', 'No Ads'];

// Neon edge tracer lines
function NeonEdges({ visible }) {
  return (
    <AnimatePresence>
      {visible && (
        <>
          {/* Top */}
          <motion.div
            className="absolute top-0 left-0 h-0.5 pointer-events-none"
            style={{ background: 'linear-gradient(90deg, transparent, #C400FF, #FF00AA, transparent)', zIndex: 50 }}
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: '100%', opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3, ease: 'easeOut' }}
          />
          {/* Bottom */}
          <motion.div
            className="absolute bottom-0 right-0 h-0.5 pointer-events-none"
            style={{ background: 'linear-gradient(270deg, transparent, #C400FF, #FF00AA, transparent)', zIndex: 50 }}
            initial={{ width: 0, opacity: 0 }}
            animate={{ width: '100%', opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3, delay: 0.05, ease: 'easeOut' }}
          />
          {/* Left */}
          <motion.div
            className="absolute left-0 top-0 w-0.5 pointer-events-none"
            style={{ background: 'linear-gradient(180deg, transparent, #C400FF, #FF00AA, transparent)', zIndex: 50 }}
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: '100%', opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3, delay: 0.1, ease: 'easeOut' }}
          />
          {/* Right */}
          <motion.div
            className="absolute right-0 bottom-0 w-0.5 pointer-events-none"
            style={{ background: 'linear-gradient(0deg, transparent, #C400FF, #FF00AA, transparent)', zIndex: 50 }}
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: '100%', opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3, delay: 0.15, ease: 'easeOut' }}
          />
        </>
      )}
    </AnimatePresence>
  );
}

// Radial magenta pulse
function MagentaPulse({ visible }) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          className="absolute inset-0 pointer-events-none flex items-center justify-center"
          style={{ zIndex: 48 }}
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            style={{
              width: 200,
              height: 200,
              borderRadius: '50%',
              background: 'radial-gradient(circle, rgba(196,0,255,0.55) 0%, rgba(255,0,170,0.2) 40%, transparent 70%)',
            }}
            initial={{ scale: 0.2, opacity: 0 }}
            animate={{ scale: [0.2, 2.5], opacity: [0.9, 0] }}
            transition={{ duration: 0.7, ease: 'easeOut' }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default function PaywallAnimation({ onComplete }) {
  const [phase, setPhase] = useState(0);
  // phase 0 = idle, 1 = dim+edges, 2 = crown+pulse, 3 = features, 4 = button pulse, 5 = done

  useEffect(() => {
    const timers = [
      setTimeout(() => setPhase(1), 0),
      setTimeout(() => setPhase(2), 300),
      setTimeout(() => setPhase(3), 700),
      setTimeout(() => setPhase(4), 1200),
      setTimeout(() => { setPhase(5); onComplete?.(); }, 1500),
    ];
    return () => timers.forEach(clearTimeout);
  }, []);

  return (
    <motion.div
      className="absolute inset-0 flex flex-col items-center justify-center overflow-hidden"
      style={{
        background: 'linear-gradient(160deg, #2A0038 0%, #1A0024 55%, #0D0015 100%)',
        zIndex: 40,
      }}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.2 }}
    >
      {/* Dim overlay */}
      <AnimatePresence>
        {phase >= 1 && (
          <motion.div
            className="absolute inset-0 pointer-events-none"
            style={{ background: 'rgba(0,0,0,0.45)', zIndex: 41 }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
          />
        )}
      </AnimatePresence>

      {/* Neon edge tracers */}
      <NeonEdges visible={phase >= 1} />

      {/* Magenta pulse */}
      <MagentaPulse visible={phase === 2} />

      {/* Crown + Heart */}
      <AnimatePresence>
        {phase >= 2 && (
          <motion.div
            className="relative flex flex-col items-center"
            style={{ zIndex: 52 }}
            initial={{ opacity: 0, scale: 0.5 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.35, ease: [0.34, 1.56, 0.64, 1] }}
          >
            {/* Glow halo behind crown */}
            <motion.div
              className="absolute rounded-full"
              style={{
                width: 140,
                height: 140,
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                background: 'radial-gradient(circle, rgba(196,0,255,0.5) 0%, transparent 70%)',
              }}
              animate={{ scale: [1, 1.4, 1], opacity: [0.7, 1, 0.7] }}
              transition={{ duration: 1.5, repeat: Infinity, ease: 'easeInOut' }}
            />
            <motion.div
              className="text-7xl relative"
              style={{ filter: 'drop-shadow(0 0 28px #C400FF)' }}
              animate={{ scale: [1, 1.08, 1], rotate: [-2, 2, -2] }}
              transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            >
              👑
            </motion.div>
            <motion.div
              className="text-4xl -mt-2"
              style={{ filter: 'drop-shadow(0 0 16px #FF00AA)' }}
              animate={{ scale: [1, 1.18, 1] }}
              transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut', delay: 0.3 }}
            >
              💜
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Features list */}
      <AnimatePresence>
        {phase >= 3 && (
          <motion.div
            className="mt-8 space-y-2 w-full px-8"
            style={{ zIndex: 52 }}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, ease: 'easeOut' }}
          >
            {FEATURES.map((f, i) => (
              <motion.div
                key={f}
                className="flex items-center gap-3 rounded-xl px-4 py-2.5"
                style={{
                  background: 'rgba(196,0,255,0.08)',
                  border: '1px solid rgba(196,0,255,0.35)',
                }}
                initial={{ opacity: 0, y: 12, scale: 0.95 }}
                animate={{
                  opacity: 1,
                  y: 0,
                  scale: 1,
                  boxShadow: [
                    '0 0 0px rgba(196,0,255,0)',
                    '0 0 16px rgba(196,0,255,0.6)',
                    '0 0 6px rgba(196,0,255,0.2)',
                  ],
                }}
                transition={{
                  duration: 0.4,
                  delay: i * 0.08,
                  boxShadow: { duration: 0.5, delay: i * 0.08 },
                }}
              >
                <motion.span
                  className="w-2 h-2 rounded-full shrink-0"
                  style={{ background: '#C400FF', boxShadow: '0 0 6px #C400FF' }}
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1.2, repeat: Infinity, delay: i * 0.1 }}
                />
                <span className="text-sm font-medium text-white">{f}</span>
                <span className="ml-auto text-xs font-bold" style={{ color: '#C400FF' }}>✓</span>
              </motion.div>
            ))}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Button pulse + vibration */}
      <AnimatePresence>
        {phase >= 4 && (
          <motion.div
            className="mt-8 px-8 w-full"
            style={{ zIndex: 52 }}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
          >
            <motion.div
              className="w-full rounded-2xl flex items-center justify-center font-bold text-base text-white"
              style={{
                height: 52,
                background: 'linear-gradient(135deg, #8B00CC 0%, #C400FF 60%, #9B00DD 100%)',
              }}
              animate={{
                boxShadow: [
                  '0 0 20px rgba(196,0,255,0.5)',
                  '0 0 50px rgba(196,0,255,1)',
                  '0 0 20px rgba(196,0,255,0.5)',
                ],
                x: [0, -3, 3, -2, 2, 0],
              }}
              transition={{
                boxShadow: { duration: 0.5, ease: 'easeInOut' },
                x: { duration: 0.35, delay: 0.1, ease: 'easeInOut' },
              }}
            >
              ✨ Unlock Premium
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}