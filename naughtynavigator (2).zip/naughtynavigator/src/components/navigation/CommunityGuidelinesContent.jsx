import React from 'react';

const sections = [
  {
    title: '💫 Our Community Values',
    content: 'Naughty Navigator is built on personality, playfulness, and confidence — but never at the expense of safety or respect. We value:',
    items: [
      'Fun, lighthearted interaction',
      'Respect for all users',
      'Safe and responsible use',
      'Inclusivity and dignity',
      'A premium, enjoyable experience for everyone',
    ],
  },
  {
    title: '🚦 1. Safe & Responsible Use',
    content: 'Naughty Navigator includes playful, suggestive, and personality‑driven content, but safety always comes first.\n\nUsers must:',
    items: [
      'Follow all traffic laws',
      'Avoid interacting with the app while driving',
      'Use the app in a way that does not endanger themselves or others',
    ],
    footer: 'We do not tolerate reckless or unsafe behavior.',
  },
  {
    title: '💬 2. Respectful Interaction',
    content: 'While the app may use cheeky or flirty language, user behavior must remain respectful.\n\nUsers may not:',
    items: [
      'Harass, threaten, or abuse others',
      'Use the app to promote hateful or discriminatory content',
      'Engage in bullying or targeted harassment',
    ],
    footer: 'We maintain a zero‑tolerance policy for harmful behavior.',
  },
  {
    title: '🎭 3. Appropriate Content',
    content: 'Naughty Navigator is designed for adults 18+ and includes playful themes.\n\nUsers may not:',
    items: [
      'Upload or share explicit sexual content',
      'Use the app to distribute illegal or harmful material',
      'Attempt to manipulate or misuse personality features for inappropriate purposes',
    ],
  },
  {
    title: '🛠️ 4. No Misuse of Features',
    content: 'To protect the integrity of the app, users may not:',
    items: [
      'Attempt to hack, reverse engineer, or modify the app',
      'Exploit bugs, glitches, or vulnerabilities',
      'Use automated tools or scripts to interfere with the app',
    ],
  },
  {
    title: '🛒 5. Fair Use of Purchases & Upgrades',
    content: 'Users must:',
    items: [
      'Only use purchased content for personal use',
      'Avoid sharing or redistributing paid voice packs or features',
      'Respect intellectual property rights',
    ],
  },
  {
    title: '🧘 6. Be Kind to the Community',
    content: 'If community spaces (forums, chats, groups) are introduced in the future, users must:',
    items: [
      'Engage respectfully',
      'Avoid spam or disruptive behavior',
      'Report harmful content when necessary',
    ],
  },
  {
    title: '🚫 7. Consequences for Violations',
    content: 'Violations of these guidelines may result in:',
    items: [
      'Warnings',
      'Feature restrictions',
      'Temporary suspension',
      'Permanent account termination',
    ],
    footer: 'We reserve the right to enforce these guidelines at our discretion.',
  },
  {
    title: '📩 Reporting Issues',
    content: 'If you encounter harmful behavior, technical issues, or violations of these guidelines, please contact us:',
    footer: 'Email: naughtynav62@gmail.com',
  },
  {
    title: '🔄 Updates to These Guidelines',
    content: 'We may update these guidelines as the app evolves. Updates will be posted within the app or on our website.',
  },
];

export default function CommunityGuidelinesContent() {
  return (
    <div className="overflow-y-auto h-full bg-zinc-950 px-4 py-6 space-y-6 pb-20">
      <div className="space-y-2">
        <h2 className="text-lg font-bold text-zinc-100">Naughty Navigator – Community Guidelines</h2>
        <p className="text-xs text-zinc-500">Last Updated: March 27, 2026</p>
        <p className="text-sm text-zinc-400 leading-relaxed">
          Welcome to the Naughty Navigator community. These guidelines exist to keep the experience fun, safe, respectful, and enjoyable for everyone. By using the app, interacting with its features, or participating in any community spaces we may offer, you agree to follow these standards.
        </p>
      </div>

      <div className="h-px bg-zinc-800" />

      {sections.map((section, i) => (
        <div key={i} className="space-y-3">
          <h2 className="text-sm font-semibold text-zinc-200">{section.title}</h2>
          {section.content && (
            <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{section.content}</p>
          )}
          {section.items && (
            <ul className="space-y-1 pl-4">
              {section.items.map((item, j) => (
                <li key={j} className="text-sm text-zinc-400 list-disc leading-relaxed">{item}</li>
              ))}
            </ul>
          )}
          {section.footer && (
            <p className="text-sm text-zinc-400 leading-relaxed whitespace-pre-line">{section.footer}</p>
          )}
        </div>
      ))}

      <div className="h-px bg-zinc-800" />
      <p className="text-sm text-zinc-400 leading-relaxed text-center italic">
        Thank you for being part of the Naughty Navigator community. Together, we keep the experience fun, confident, and safe for everyone.
      </p>
    </div>
  );
}