import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Key } from 'lucide-react';

const PROVIDERS = [
  { id: 'seductive', label: 'Seductive Route (default)', needsKey: false },
  { id: 'mapbox', label: 'Mapbox', needsKey: true },
  { id: 'google', label: 'Google Maps', needsKey: true },
  { id: 'ors', label: 'OpenRouteService', needsKey: true },
];

export default function ApiKeySettings({ provider, onProviderChange, apiKeys, onApiKeyChange }) {
  const [expanded, setExpanded] = useState(false);
  const current = PROVIDERS.find(p => p.id === provider) || PROVIDERS[0];

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
      <button
        onClick={() => setExpanded(e => !e)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left"
      >
        <Key className="w-4 h-4 text-zinc-500 shrink-0" />
        <div className="flex-1">
          <p className="text-xs font-medium text-zinc-400">Route Provider</p>
          <p className="text-[11px] text-zinc-600">{current.label}</p>
        </div>
        {expanded ? <ChevronUp className="w-4 h-4 text-zinc-600" /> : <ChevronDown className="w-4 h-4 text-zinc-600" />}
      </button>

      {expanded && (
        <div className="border-t border-zinc-800 px-4 py-3 space-y-3">
          <div className="grid grid-cols-2 gap-1.5">
            {PROVIDERS.map(p => (
              <button
                key={p.id}
                onClick={() => onProviderChange(p.id)}
                className={`py-2 px-3 rounded-xl text-[11px] font-medium transition-colors
                  ${provider === p.id ? 'bg-pink-500/10 text-pink-300 border border-pink-500/30' : 'bg-zinc-800 text-zinc-400 border border-transparent hover:border-zinc-700'}`}
              >
                {p.label}
              </button>
            ))}
          </div>
          {current.needsKey && (
            <input
              type="text"
              value={apiKeys[provider] || ''}
              onChange={(e) => onApiKeyChange(provider, e.target.value)}
              placeholder={`${current.label} API key`}
              className="w-full h-10 px-3 rounded-xl bg-zinc-800 border border-zinc-700 text-zinc-300 text-xs placeholder:text-zinc-600 focus:outline-none focus:border-pink-500/50 transition-colors"
            />
          )}
        </div>
      )}
    </div>
  );
}