import React from 'react';
import { Navigation, ArrowLeft, ArrowRight, MapPin } from 'lucide-react';

function StepIcon({ type }) {
  if (type === 'turn-left') return <ArrowLeft className="w-4 h-4 text-pink-400" />;
  if (type === 'turn-right') return <ArrowRight className="w-4 h-4 text-pink-400" />;
  if (type === 'arrived') return <MapPin className="w-4 h-4 text-green-400" />;
  return <Navigation className="w-4 h-4 text-zinc-400" />;
}

function formatDuration(seconds) {
  if (!seconds) return '';
  const m = Math.round(seconds / 60);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)}h ${m % 60}m`;
}

function formatDistance(meters) {
  if (!meters) return '';
  return meters >= 1000 ? `${(meters / 1000).toFixed(1)} km` : `${Math.round(meters)} m`;
}

export default function TurnByTurnSteps({ steps = [], currentStepIndex = 0, totalDistance, totalDuration }) {
  if (!steps.length) return null;

  return (
    <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
      {(totalDistance || totalDuration) && (
        <div className="px-4 py-2.5 border-b border-zinc-800 flex gap-4">
          {totalDistance && <span className="text-xs text-zinc-400">{formatDistance(totalDistance)}</span>}
          {totalDuration && <span className="text-xs text-zinc-400">{formatDuration(totalDuration)}</span>}
        </div>
      )}
      <div className="max-h-48 overflow-y-auto divide-y divide-zinc-800/50">
        {steps.map((step, i) => (
          <div
            key={i}
            className={`flex items-start gap-3 px-4 py-3 transition-colors ${i === currentStepIndex ? 'bg-pink-500/5' : ''}`}
          >
            <div className={`mt-0.5 shrink-0 h-7 w-7 rounded-lg flex items-center justify-center ${i === currentStepIndex ? 'bg-pink-500/10' : 'bg-zinc-800'}`}>
              <StepIcon type={step.type} />
            </div>
            <div className="flex-1 min-w-0">
              <p className={`text-xs leading-relaxed ${i === currentStepIndex ? 'text-zinc-200' : 'text-zinc-500'}`}>
                {step.instruction || step.maneuver || 'Continue'}
              </p>
              {step.distance && (
                <p className="text-[10px] text-zinc-600 mt-0.5">{formatDistance(step.distance)}</p>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}