import { createClientFromRequest } from 'npm:@base44/sdk@0.8.23';
import Stripe from 'npm:stripe@17.0.0';

const stripe = new Stripe(Deno.env.get('STRIPE_SECRET_KEY'));

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();

    if (!user) {
      return Response.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Get or create Stripe customer
    let stripeCustomerId = user.stripeCustomerId;
    
    if (!stripeCustomerId) {
      const customer = await stripe.customers.create({
        email: user.email,
        name: user.full_name,
        metadata: { userId: user.id }
      });
      stripeCustomerId = customer.id;
      
      // Save Stripe customer ID to user
      await base44.auth.updateMe({ stripeCustomerId });
    }

    // Create checkout session
    const session = await stripe.checkout.sessions.create({
      customer: stripeCustomerId,
      payment_method_types: ['card'],
      line_items: [
        {
          price_data: {
            currency: 'usd',
            product_data: {
              name: 'Naughty Navigator Premium',
              description: 'Unlock all voices, themes, and exclusive features',
              images: ['https://media.base44.com/images/public/69b8572fda649af9ebb82bbc/f8b628f68_Copilot_20260326_181419.png'],
            },
            unit_amount: 9_99, // $9.99
          },
          quantity: 1,
        },
      ],
      mode: 'payment',
      success_url: `${req.headers.get('origin') || req.headers.get('referer')?.split('/').slice(0,3).join('/') || 'https://app.base44.com'}/upgrade?success=true`,
      cancel_url: `${req.headers.get('origin') || req.headers.get('referer')?.split('/').slice(0,3).join('/') || 'https://app.base44.com'}/upgrade?canceled=true`,
      metadata: { userId: user.id }
    });

    return Response.json({ sessionId: session.id, publishableKey: Deno.env.get('STRIPE_PUBLISHABLE_KEY') });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
});